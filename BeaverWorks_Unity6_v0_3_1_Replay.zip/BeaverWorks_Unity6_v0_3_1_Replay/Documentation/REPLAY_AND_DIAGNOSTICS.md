# Stress-test replay and diagnostic overlays — revision 0.3.1

## Install

This is a complete overseer package, not just a few replacement scripts. It retains the tutorial, three levels, material choices, terrain tools and asset slots. Keep V2 intact. Start in a fresh Unity 6 Universal 3D project if you have not verified V3 yet.

1. Extract ZIP.
2. Import BeaverWorks_Unity6_v0_3_1_Replay.unitypackage once.
3. Input System + Unity UI/uGUI installed; Active Input Handling New.
4. Beaver Works V3 > Create Overseer Tutorial. Save scene.
5. Beaver Works V3 > Run Simulation Checks. Expect TWO reports: 38 construction/water/level checks and 26 replay/diagnostic checks.
6. Play in landscape. The prototype camera is elevated, centered across the river and orthographic with no diagonal yaw. River travels vertically on screen.

If updating a local V3 project: back up it first, stop Play, import the package overwriting matching source GUIDs and adding the replay scripts. Existing model slots on WorksGame remain. New replay UI is generated at runtime; no need to manually wire a slider. Only one WorksGame instance in scene. WorksDiagnostics is a partial implementation of WorksGame, NOT an extra component to attach.

## A clear review workflow

1. Pick a level, build your dam. For a quick start choose LEVEL 3 > EXAMPLE.
2. Choose the desired erosion PHYSICS setting while in BUILD. It is locked during TEST/replay to avoid changing an experiment halfway through.
3. Press TEST WATER. Recording begins at simulation time zero.
4. Press PAUSE to freeze the live test. Tap terrain/dam for the inspector. RESUME continues the original simulator.
5. Let the trial finish, or press REPLAY while paused/running. Replay pauses the original simulator and opens a separate snapshot viewer at time zero.
6. Press PLAY to review. Default playback speed is .5x simulation time. The existing SPEED button cycles .25x, .5x, 1x, 3x while replaying; in live tests it still cycles 1x, 3x, 6x.
7. Drag the gold timeline handle to scrub. Scrubbing pauses playback. START seeks time zero; PREV/NEXT seek recorded events; WARNING seeks the first warning (zero when there is none).
8. Toggle PRESSURE, WEAR, and LOAD separately. All three can be visible together. They do not change water, terrain rules, fish decisions, or damage.
9. Tap a terrain point or dam segment for local depth, pressure, approximate speed, actual erosion rate and accumulated erosion loss. A segment also shows demand components, estimated capacity, utilization and damage.
10. LIVE leaves replay and restores the untouched original simulator. It returns PAUSED if the original was a live test. RESUME continues it. EDIT / RESET restores your pre-test construction and terrain.
11. After EDIT, the last recording remains available. Starting a new TEST replaces it. Loading/CLEARing a level discards it. Stop Play loses it: there is no replay-file export or persistent save in this revision.

## The three display switches

| Switch | Meaning | Scale / limitations |
|---|---|---|
| PRESSURE | Color on water represents hydrostatic GAUGE pressure at the riverbed under each local water column | Blue 0 kPa, yellow ~15, red 30+; display clips but inspector keeps value. It is NOT nonzero free-surface pressure or full dynamic pressure. |
| WEAR | Ground tint + visible above-water diagnostic triangles show actual ground removal rate from this model; small gold ticks show cumulative removed depth | Neutral 0, amber/red .01+ game metres/s. Loss ticks exaggerated 5x and capped visually at .8; numeric inspector unscaled. Shows zero when no erosion occurred. |
| LOAD | Dam tint shows demand / estimated capacity | Green low, red near/above 100%; dark = broken. Damage is separately reported. Numeric readings remain useful when custom material shaders do not support tint. |

Pressure and force differ: pressure is local kPa; segment demand integrates pressure along wetted faces and includes game velocity/stack terms; animal demand has a deliberately amplified gameplay multiplier. Estimated capacity is game balancing, NOT certified wood/stone strength. Mass, geometry, support and soil scour are highly simplified.

## Recorded events

TEST START; spring surge begins/ends; animal enters; animal completes or loses footing; fish reaches correct/wrong outlet; dam breach; habitat complete; test timeout. Events are tagged with exact simulation-step timestamps. These trigger extra snapshots between periodic samples so breaches are not skipped merely because sampling is every .25 seconds.

The log does NOT claim a measured real-world failure diagnosis or individually classify every scour/overturning/bending cause. Read the fields before and after a breach, then revise.

## Replay accuracy and bounded memory

- Simulator fixed step: 1/30 simulated second; not Unity Rigidbody simulation.
- Recorded surfaces/motion: float snapshots every .25 simulated second, plus event steps and final state. No interpolation between them: slow playback can look stepped.
- Fish parcels and segment state are deep copied. Viewer uses an independent WorksModel. No Tick calls during replay.
- Cosmetic beaver pose is recorded at simulation sampling. No animation clips/rig pose recording.
- Terrain/water/velocity use float storage, so tiny rounding changes in the VIEWER are expected; original simulation remains double precision and unchanged.
- Captures are for viewing only, not a save-state for resuming/recomputing the solver. Flux-memory/random/timer internals need not be restored because viewer never simulates.
- 1,800-frame limit and approximately 48 MiB tracked capture-data budget. Actual CLR/Unity overhead can add memory; this is not a measured process-memory ceiling. The replay panel explicitly warns if capped; later unrecorded time is not silently shown as available.
- Peak pressure/load summaries are gathered at each recorded simulation step, not only periodic frames. A peak can be reported without an exact non-event peak snapshot.

## Useful tests

- LEVEL 3 + EXAMPLE: passing spring pulse with three deer and nursery routing.
- Overload example: draw a long BRUSHWOOD barrier across the river, test it, inspect whether pressure exceeds its capacity; the model unit tests separately execute a deliberately high-head breach fixture. Do not assume every natural trial of that construction will break.
- Turn erosion physics OFF in build, test, then turn WEAR display ON: wear rates should remain zero.
- Scrub backward from a breach: intact pre-breach state must return; LIVE must restore the untouched final/live test.
- Change BUILD after EDIT, open last replay, LIVE: new build must remain intact.

## Verification

64 checks were executed against compiled actual pure-C# code: 38 original model and 26 replay/diagnostic tests. Nine C# source files passed syntax parsing. These verify snapshot independence, beginning/end seeks, outcome preservation, failure events, bounded storage, wear accounting, and the four example solutions.

NOT executed here: Unity API compilation, prefab deserialization, shader compilation, camera framing, overlay visibility, uGUI pointer input, slider behavior, rendering, Windows player or iPad build/performance. Run the engine checklist. Prototypes still need device profiling; renderer caching does not certify sustained tablet speed.

## Research references

- Unity Slider: SetValueWithoutNotify prevents a code-driven slider update from firing the seek callback. https://docs.unity3d.com/Packages/com.unity.ugui@2.7/api/UnityEngine.UI.Slider.html
- Unity fixed timesteps and CPU/backlog tradeoffs: https://docs.unity3d.com/6000.0/Documentation/Manual/fixed-updates.html
- OpenStax: hydrostatic pressure depends on fluid depth/density; integrated face force differs from reservoir water weight: https://openstax.org/books/college-physics-2e/pages/11-4-variation-of-pressure-with-depth-in-a-fluid

This is original educational code, not a purchased replay-plugin dependency or an engineering prediction tool.
