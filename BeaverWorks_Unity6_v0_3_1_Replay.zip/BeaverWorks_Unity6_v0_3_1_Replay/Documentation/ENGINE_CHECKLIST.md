# Beaver Works V3 — engine/device acceptance

All engine and device steps here are NOT EXECUTED in the authoring environment. Record exact Unity, Input System, uGUI, pipeline, OS and device versions.

## Import
- [ ] Clean Unity 6 URP project; import one method only.
- [ ] Input System + uGUI present; Active Input Handling New.
- [ ] No red Console errors or missing prefab scripts.
- [ ] Run Simulation Checks: two reports, 38 original + 26 replay/diagnostic actual C# checks.
- [ ] SurfaceShader serialized and works in Editor AND built player.
- [ ] No pink/black mesh or hidden UI.

## View
- [ ] River runs vertically, upstream at top/downstream at bottom.
- [ ] Front/top view, no diagonal isometric orientation.
- [ ] Screen-left nursery label agrees with branch.
- [ ] 1280×800 and iPad 4:3 landscape controls readable.
- [ ] Terrain fully visible in reserved camera viewport, not behind notebook/shelf.
- [ ] Grid toggles; height ticks visible; hiding grid does not disable snapping.
- [ ] Gold endpoints align with true pointer-intersection locations.
- [ ] Gray pond/channel indicators and load diagnostic visible.

## Placement
- [ ] Mouse/finger drag measures 1–6 units and consumes cost×length.
- [ ] Click without drag / >6 drag rejects without debit.
- [ ] Dominant drag axis sets orientation; no diagonal segment claim.
- [ ] Partial overlap/crossing rejected; exact matching endpoints stack up to 3.
- [ ] Remove top piece; supporting layers cannot be removed first.
- [ ] Release over UI cancels and refunds/restores unfinished action.
- [ ] Second touch does not steal construction gesture.
- [ ] Undo restores one whole terrain stroke or construction action + supplies.
- [ ] Focus/app pause cancellation restores trial/design safely.

## Terrain and props
- [ ] Dig/mud change mesh height, not just paint.
- [ ] Layer colors change and bedrock stops excavation.
- [ ] Player rocks protect nodes; removable with refund; natural rocks permanent.
- [ ] Trees disappear on excavation/return with undo.
- [ ] Beaver follows dragging and visits successful edits/crest heights.
- [ ] Buddy shortcuts clearly treated as cosmetic, not physical navigation.

## Test lifecycle
- [ ] TEST locks editing; EDIT restores pre-test terrain and segments.
- [ ] Starting next trial clears old fish display models/counts.
- [ ] Erosion ON wears eligible soil; OFF does not change ground.
- [ ] Failure darkens/removes hydraulic dam barrier; supporting layer failure affects stack.
- [ ] Load >100% can damage segment; custom shaders support tint or use numeric HUD.
- [ ] Fish models visible above opaque water; movement follows actual parcel cells.
- [ ] Animals traverse only designated dry row; failures prevent win.
- [ ] Trial speed 1/3/6×; bounded update steps; no runaway backlog.
- [ ] Example design wins tutorial plus all three levels.
- [ ] Wrong exits: zero for nursery fork, at most three for surge.
- [ ] Full tutorial controls NEXT conditions and final transition.
- [ ] CLEAR resets current level; source draft settings aren't modified.

## Replay and diagnostics — all engine checks NOT EXECUTED here
- [ ] TEST begins recording time zero; terminal and event-step snapshots retained.
- [ ] PAUSE freezes live physics; RESUME does not restart trial.
- [ ] REPLAY opens independent viewer; no simulation Tick during replay.
- [ ] PLAY/PAUSE, START, PREV/NEXT, WARNING and scrubber work with mouse and touch.
- [ ] Scrubber seeks without recursively triggering itself; scrubbing pauses playback.
- [ ] SPEED cycles replay .25/.5/1/3x independently of live speed.
- [ ] Backward seek restores intact pre-breach dam, fish and crossing counts.
- [ ] LIVE restores exact live/design data; live trial returns paused.
- [ ] Replay survives EDIT; new TEST or level load discards old replay.
- [ ] PRESSURE, WEAR, LOAD separate and combinable without changing physics.
- [ ] Pressure legend describes bed gauge pressure, not free-surface pressure.
- [ ] Wear triangles visible above water; loss ticks and numeric rate/loss match data.
- [ ] Inspector shows water/animal demand, capacity estimate, damage and utilization.
- [ ] New panels do not occlude river, controls or gold endpoints on iPad 4:3.
- [ ] Custom segment tint compatible or numeric HUD remains useful.
- [ ] Focus/app pause freezes recording/replay rather than destroying test.
- [ ] Long recording cap warning explicit; peak summary/readout clear.
- [ ] No replay-file persistence/export claim; Stop Play clears recording.

## Native/device
- [ ] Unity Remote USB/iTunes prerequisites and correct device setting on Windows.
- [ ] Touch drag accuracy tested at actual iPad resolution.
- [ ] Metal shader/native build works; don't equate Remote with native performance.
- [ ] Unity Profiler checks visual regeneration/allocations and simulation CPU.
- [ ] Replace timer regeneration with pooling/cached renderers if device spikes.
- [ ] Sustained device frame time, thermal behavior and safe area inspected.
- [ ] Stop Play loses runtime edits (expected; no save/load advertised).

If any step fails, capture the full first red Console error and exact repro. Source/model checks do not certify engine integration.
