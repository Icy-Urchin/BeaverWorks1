# Replacing the generated art — Beaver Works V3

## 1. Make a visual prefab wrapper

1. Import FBX/OBJ/models/textures into an `Assets/YourArt` folder.
2. In an empty scene, create an empty GameObject. Position=(0,0,0), Rotation=(0,0,0), Scale=(1,1,1).
3. Drag your model underneath it as a CHILD.
4. Scale/rotate/offset the CHILD to meet the conventions below. Keep the wrapper at unit transform.
5. Drag the wrapper into `Assets/YourArt/Prefabs` to create a prefab.
6. Stop Play. Select the game object containing WorksGame. Drag the prefab into the matching field. Save scene.
7. Play again. References are read during level generation, not live swapped.

Do not assign the raw imported model if its axes/pivot are wrong. Wrappers let you correct the visual without changing code.

## 2. Slot conventions

| WorksGame field | Wrapper convention | Suggested size |
|---|---|---|
| BeaverPrefab | feet at Y=0, facing +Z | roughly .7 units long |
| RabbitPrefab | feet at Y=0, facing +Z | .5–.7 units |
| DeerPrefab | feet at Y=0, facing +Z | about 1–1.4 units |
| FishPrefab | center pivot, facing +Z | about .4–.6 units |
| RockPrefab | base centered at origin | approximately one-unit obstacle |
| TreePrefab | trunk base Y=0 | about 1.5–2.5 units tall |
| BrushwoodPrefab | center pivot, long axis +X | one-unit-long template |
| TimberPrefab | center pivot, long axis +X | one-unit-long template |
| MudPrefab | center pivot, long axis +X | one-unit-long template |
| StonePrefab | center pivot, long axis +X | one-unit-long template |
| FishPassPrefab | center pivot, long axis +X | one-unit-long template |

Segment code scales the wrapper X by drawn length, Y by the material's height, and rotates it 90° for along-river placement. Author template bounds around 1×1×.46, centered. Nonuniform stretching is a prototype choice: later instantiate repeating unit sections to avoid stretched textures.

The game positions custom rock visuals with a .5-unit vertical offset. Adjust your rock child's pivot/offset accordingly so it fits the physical node's 1.15-unit obstacle rather than hovering.

Built-in transforms animate location/heading, not a rig. An Animator can animate the child, but root motion should be OFF so it doesn't fight position code. No custom idle/walk/build clips are included.

Runtime code disables collider components on generated replacements and sets rigidbodies kinematic. The simulation doesn't use those colliders. Avoid scripts on art prefabs that create their own controllers, physics forces, camera or HUD.

LOAD applies _BaseColor and _Color via a MaterialPropertyBlock to custom segment renderers. This works only if the artist's shader exposes a compatible property; otherwise keep the numeric load HUD or adapt your shader. Tinting is a prototype diagnostic, not a finished material treatment.

## 3. Add your existing river landscape

The editable river is a procedurally generated heightfield. Dropping a mesh into the scene DOES NOT make it erode or alter water routing.

**Safe first option:** use your existing landscape for outer scenery behind/beside the generated patch. Align it outside the playable rectangle world X=0..23, Z=0..35. Keep the water bed visibly owned by WorksView. Avoid an opaque imported riverbed covering the generated terrain or water; it will hide deformation.

**Integrating the exact landscape later:**

1. Decide a world-space origin and scale matching the simulation rectangle.
2. Sample your riverbed model onto the 24×36 `Ground` nodes (Editor-time mesh raycasts or baked height data).
3. Copy those starting values into `Original`, define `Bedrock` beneath them and explicitly map layer/material data.
4. Place natural obstacles into `Rocks` and `Permanent` data, not merely scenery.
5. Adapt `WorksModel` pond region, crossing row, fork outlets and source/drain placement.
6. Regenerate visible terrain from this data; or deform your own dense/regular mesh using its mapped vertices.
7. Re-run all model checks and author new level-specific examples. The included examples only verify included presets.

Arbitrary rock/tree prefab geometry does not change hydraulic shape. The simulation obstacle shape is one raised node and the terrain interpolation surrounding it. Art and data must be deliberately kept consistent.

## 4. Camera/art direction

The fixed camera sees terrain from above and straight across its front, without a 45° diagonal yaw. Trees should be compact enough not to conceal endpoint placement. Keep riverbank edges readable, use different silhouettes for materials, and reduce large transparent foliage overlays on tablet.

For a finished mid-poly aesthetic: faceted banks, three/four log surfaces, pale stream arrows, a small beaver with a broad dark tail, and chunky dam material silhouettes. No finished mesh art is included; Unity primitives are stand-ins.

## 5. Where each behavior lives

- WorksModel.cs — terrain, material definitions, four level presets, water, erosion, pressure, fish/animal rules.
- WorksGame.cs — camera, input, preview, undo/test UI, NPC visuals, asset slots, tutorial.
- WorksView.cs — generated ground/water meshes, heightfield picking, placement grid/cutaway.
- WorksPointer.cs — UI mouse/touch drag forwarding.
- WorksChecks.cs — repeatable actual-C# simulation checks.
- WorksMenu.cs — Unity Editor scene/check menu.
- WorksSurface.shader — prototype vertex-color/tint rendering.

There is no animator/network/cloud dependency and no CAD/model importer pretending to infer simulation geometry from a visual asset.
