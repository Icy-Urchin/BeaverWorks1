# Beaver Works V3 — Design and research notes

Research October 14, 2026. Revision 0.3.1 adds separate snapshot playback and three independent diagnostic displays; see REPLAY_AND_DIAGNOSTICS.md for the authoritative replay behavior and 64-check verification scope. Original AI-assisted school prototype; cited work informs design but its code is not redistributed here.

## Player promise

"I design a small river habitat, test it, and understand why it succeeds or fails."

The beaver is a supporting visual actor, not a controllable avatar. The game is about construction constraints, river routing, load and erosion. The loop is inspect → draw/material/shape → test → diagnose → edit/undo → succeed. One tutorial and three escalating challenge presets establish the scope.

## Camera

A front-centered overhead view provides readable bank geometry while the river projects vertically. Orthographic projection preserves construction scale; isometric is a specific orientation, not a synonym for every orthographic camera. This camera uses about 49° elevation without 45° yaw. Upstream at world Z=0 projects above downstream at Z=35; world +X appears screen-left. The nursery branch is therefore screen-left and labeled by target rather than relying on a world-direction name.

Unity defines perspective and orthographic independently of camera transform.
https://docs.unity3d.com/6000.0/Documentation/Manual/CamerasOverview.html
https://docs.unity3d.com/6000.0/Documentation/Manual/UnderstandingFrustum.html

## Construction

Draw constrained segments, not physically carry arbitrary logs. Horizontal/vertical snapping is deliberately easy to understand on touch; length 1–6 units is measured by snapped endpoint distance. Matching endpoints allow stacking. Partial overlap and crossing boxes are rejected.

Materials differ in permeability, height, walkability, cost, weight and capacity. The fish-pass weave is a fictional gameplay element, not an engineering fish ladder specification. Rock placements modify terrain resistance, while mud fill uses a budgeted supply. GRID visibility can be disabled but the underlying grid remains; a genuinely grid-free spline system is later work.

## Water amounts and velocity

Each 1×1 game-unit cell stores terrain height and depth. Edge flows are signed volume/second. Proposed flow derives from water head above terrain/crest with a damped memory; outgoing rates are scaled so a cell cannot donate more water than it holds. Paired transfers cancel and open-boundary drainage is accounted for separately. Total volume minus initial volume minus sources plus drainage is checked.

Velocity is estimated from neighboring flux divided by local water depth and unit face width, clamped to ±3 per component. This proxy drives erosion and display arrows. It is NOT a full shallow-water conservation-of-momentum solution, Navier–Stokes, voxel fluid or SPH.

Virtual-pipes heightfield work describes useful grid representations, donor scaling and limitations. A 3D column model cannot represent underwater tunnels, free-falling disconnected water sheets, or multiple water surfaces per column. Our implementation is simpler than the researched solver.
https://lisyarus.github.io/blog/posts/simulating-water-over-terrain.html
https://github.com/lisyarus/webgpu-shallow-water

## Pressure and failure

Hydrostatic gauge pressure rises with depth. Integrating a fully wetted vertical wall gives F=0.5*rho*g*width*h². For partially submerged segment faces the code integrates only the wetted vertical height; an actual reference check gives 4.905 kN for a one-metre-wide, one-metre-deep face using freshwater density.

The hydraulic force basis is physics-inspired. Material capacities, friction terms, support multiplier, span penalty, velocity term, animal-load multiplier and damage rate are GAME BALANCING TERMS. This is not finite-element beam simulation or safe real-dam design. Joint mechanics, overturning, buoyancy, detailed bending/shear, debris impact and foundation seepage are not solved.

Different stack layers have different bottom heights. Upper-layer weight adds a small simplified load to lower layers; if a lower segment fails, matching upper segments fail rather than hover. Foundation lowering by erosion reduces support. Failures remove hydraulic blockage and show a tilted dark segment; debris isn't physically advected.

Reference (use the general pressure integration, not this source's worked-example arithmetic):
http://adaptivemap.ma.psu.edu/websites/fluidstatics/hydrostaticflat.html
https://www.ecoursesbook.com/cgi-bin/ebook.cgi?chap_sec=02.3&page=theory&topic=fl

## Soil erosion

Layers are intentionally readable, not site-specific geology: topsoil .20; dirt to .48; loose mud to .73; sand/gravel to 1.03; clay to 1.44; bedrock below, in excavated game depth.

For wet cells, stress proxy = 6*speed². Erosion occurs only above material-specific thresholds and uses material-specific rates. Clay has a larger threshold and slower rate. Rocks protect their node, bedrock protects the floor. Excavated fill is removed before natural ground. Trees disappear when their shallow support is removed.

USGS describes the importance of cohesion and mud fraction: clay/silt-rich material can erode less readily under similar stresses. We intentionally distinguish loose deposited construction mud from compacted packed-mud cores and clay. There is no universal natural "topsoil/dirt/mud/sand/clay" sequence.
https://www.usgs.gov/publications/erosion-properties-cohesive-sediments-colorado-river-grand-canyon

No suspended-sediment mass transport, grain sorting, deposition, bank collapse, soil saturation, lateral undercutting or root mechanics are modeled. Brown water is a cosmetic total-erosion tint. Ground loss tracks an erosion tally, not a sediment conservation ledger.

## Fish

NOAA describes the ecological importance of fish passage and how dams, steep/perched passages and poor hydraulic conditions form barriers. Our fish are passive, deterministic-seeded flux-weighted parcels: they move among wet neighboring cells according to positive outgoing flow and barrier permeability. Solid barriers are impassable unless sufficiently overtopped; fish-pass weave explicitly allows wet passage.

They do not goal-seek, swim upstream, have burst/endurance limits or represent salmonid passage criteria. The nursery is scored at the outlet. The fork level requires no wrong exits; the surge level allows up to three because overflow may carry some parcels down the main drain during the pulse. Display models are at the surface for visibility rather than correct submerged fish rendering.
https://www.fisheries.noaa.gov/insight/barriers-fish-migration

## Animals

Animal position progresses across one designated dam row. A dry continuous crest, ground, and bank access ramps are necessary. Models are visual passengers, not physics bodies. Deer add greater game load than rabbits. Generic AI/pathfinding or rerouting isn't claimed. A failed animal crossing prevents victory even if later animals pass.

## Mobile and Unity

Input is uGUI pointer down/drag/up with pointer ownership and UI cancellation. InputSystemUIInputModule supplies default input actions. No player joystick exists in overseer mode.

No dynamic terrain MeshCollider recooking is required: pointer picking and NPC height sample the same triangle-defined heightfield. This avoids a major runtime deforming-collider cost, though visual rebuilding still needs pooling/cached renderers for production.

Unity guidance recommends profiling rather than assuming mobile performance. The CPU model has small bounded grids; no native iPad performance is inferred from this.
https://docs.unity3d.com/6/Documentation/Manual/urp/configure-for-better-performance.html
https://docs.unity3d.com/Packages/com.unity.inputsystem@1.11/api/UnityEngine.InputSystem.UI.InputSystemUIInputModule.html

Unity Remote executes on the desktop, not the iPad. It is input/readability testing; the native app must be installed and profiled for performance claims.
https://docs.unity3d.com/6/Documentation/Manual/UnityRemote5.html

## Testing and honesty

Actual WorksModel + WorksChecks were compiled with Roslyn and executed under .NET in the sandbox. 38 checks pass, including solvability for the tutorial and three challenges. C# source syntax parsing covers the Unity-facing files, but not Unity-engine APIs/rendering. Unity import, shader compilation, camera framing, touch precision, prefab deserialization and platform builds remain to be checked locally.

Generated assets are Unity primitives; no beaver/landscape uploads were used or claimed. Scripts are a prototype source drop, not a full tested Windows/iOS installation. Follow ENGINE_CHECKLIST.md and disclose AI assistance as your school requires.
