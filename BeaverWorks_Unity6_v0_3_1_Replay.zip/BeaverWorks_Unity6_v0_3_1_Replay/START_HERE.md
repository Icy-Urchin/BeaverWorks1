# Beaver Works V3 — Overseer Dam Lab

Unity 6 / Windows authoring / touch-ready school prototype / alternate version 0.3.1 REPLAY.

**NEW: recorded stress-test replay + pressure / erosion / structural load displays.** Start with `Documentation/REPLAY_AND_DIAGNOSTICS.md` for controls, scales, exact verification scope and replay limits. Complete tutorial + three levels are retained.

## Start here

This is a SEPARATE overseer-mode prototype. It does not overwrite the direct-control V2 application. Use a clean Unity project first. It contains one tutorial and three challenge presets, original C# source, generated primitive placeholder art, a shader and a prefab.

**Verification boundary:** 64 checks passed against the compiled actual C# data model and snapshot replay (38 original + 26 replay); all nine supplied C# files passed syntax parsing. Unity-engine compilation, prefab loading, rendering, UI interaction and native iPad performance have NOT been executed in this environment. Source syntax parsing is not Unity API verification.

## 1. Install and run

1. Extract the ZIP to a normal local folder. Open FIELD_GUIDE.html for the visual introduction.
2. Unity Hub → create a new **Unity 6 Universal 3D** project.
3. Unity → Assets → Import Package → Custom Package → choose `BeaverWorks_Unity6_v0_3_1_Replay.unitypackage` → Import all items.
4. Window → Package Management → Package Manager → Unity Registry. Ensure **Input System** (`com.unity.inputsystem`) and **Unity UI/uGUI** (`com.unity.ugui`) are installed. Use package versions compatible with YOUR Unity 6 editor; no particular newest version is required.
5. Edit → Project Settings → Player → Other Settings → Configuration → Active Input Handling → **Input System Package (New)**. Restart if Unity asks.
6. Choose **Beaver Works V3 → Create Overseer Tutorial**. Save the new scene as `OverseerTutorial` in your project.
7. Select the game object. Its SurfaceShader should be `BeaverWorksV3/Surface`. The prefab and menu assign it explicitly so the shader is referenced in builds.
8. Choose **Beaver Works V3 → Run Simulation Checks**. Expect two successful reports: **38 original actual C# checks** and **26 replay/diagnostic actual C# checks**.
9. Choose landscape Game view, preferably 1280×800 or iPad landscape. Press Play. Confirm no red Console errors before troubleshooting controls.
10. Alternative: drag `Assets/BeaverWorksV3/Prefabs/BeaverWorksOverseer.prefab` into an empty scene. Keep its world position zero, rotation zero and scale one. Do not add a second controller or camera.

Do NOT import both the unitypackage AND the raw Assets folder; they are the same assets. The raw Assets copy is included for source review/manual installation. Keep Documentation and Validation outside Assets.

## 2. View and coordinates

The camera is centered across the width of the river. It looks from above and the front at about 49° elevation, with no diagonal 45° yaw/isometric diamond view. Orthographic projection is used for reliable construction scale; orthographic is NOT automatically isometric.

Upstream appears at the TOP; downstream at the BOTTOM. World +Z travels downstream and world +X appears screen-left in this camera. The marked nursery branch therefore appears on the **LEFT side of the screen**. This is explicitly a coordinate convention, not an extra goal.

The camera is generated and reserves space for the notebook/toolbar. Camera mode pans; +/− or mouse wheel zoom. The fixed view is intentionally not player-controlled orbiting. Controls are designed for landscape, not phone portrait.

## 3. Tutorial — do these actions in order

### Step 1: see the stage
Toggle GRID off, then on. Press NEXT STEP. The gray pond ring is a target-area guide, not an exact predicted shoreline. Gold identifies the dam/crossing row.

### Step 2: first segment
TIMBER is selected. Press/hold at the LEFT gold endpoint, drag horizontally to the middle marker, then release. The preview should read **3 units / cost 9**. Valid is gold, invalid is red.

This screen-left segment is world `(X=12, Z=23, Length=3)` because of the front-facing camera. Press NEXT STEP after release.

### Step 3: join the dam
Press the middle marker, drag to the RIGHT endpoint, and release. This second segment is world `(X=9, Z=23, Length=3)`. Both span the six-unit river. Press NEXT.

### Step 4: safe revision
UNDO or keyboard Z removes the latest action and refunds its construction budget. Redraw that missing segment. Press NEXT. New segments are drawn on the ground; there is no log tray in this alternate mode.

### Step 5: terrain
Choose DIG or ADD MUD. Hold/drag on a bank AWAY from the gold dam line, the access ramps and the boulders. Try the topsoil near world `(5,10)` or `(21,10)`. Release to commit the stroke, then NEXT. Undo can restore the full stroke. Digging under the dam can undermine it; that is intentionally not a harmless visual edit.

### Step 6: effects
Press TEST WATER. Every test is recorded automatically. PAUSE freezes the live trial; REPLAY opens the last snapshots; PLAY, START, PREV/NEXT, WARNING and the scrubber review them. PRESSURE, WEAR and LOAD can be toggled separately; tapping terrain/dam opens numeric inspection. Build tools are locked while testing or replaying. The simulation begins from dry ground; water enters upstream and fills the pond. Toggle LOAD for colored segment utilization. Arrows show approximate flow; erosion changes wet soil. A rabbit crosses the designated dam row after about 72 simulation seconds. The example tutorial completes at about 86 simulation seconds, roughly 29 real seconds at 3× before overhead.

If your design fails, press EDIT / RESET to restore the exact pre-test terrain and construction, revise, then test again. You don't have to rebuild after each failure.

### Step 7: finish
The goal is pond depth + one animal crossing + no broken segments, held for 3 SIMULATION seconds. Complete it, press NEXT STEP, then NEXT LEVEL. Three seconds of simulation hold are one real second at 3×. This differs from V2's real-time hold.

For assistance use EXAMPLE in build mode. It loads a tested design and is undoable, but doesn't fake the tutorial's individual action requirements. You still need the GRID, UNDO and terrain actions if completing the guided sequence.

## 4. Controls

| Action | Mouse | iPad touch |
|---|---|---|
| New segment | Select material, left-press, drag, release | Select material, finger-press, drag, release |
| Segment length | Drag 1–6 world units | Same; preview displays units/cost |
| Stack | Repeat exact endpoints, up to 3 layers | Same |
| Orientation | Dominant horizontal/vertical drag axis | Same |
| Dig or add mud | Select tool, hold/drag terrain | Same |
| Place rock | ROCK then click | ROCK then tap |
| Remove top segment/player rock | REMOVE then click footprint | REMOVE then tap footprint |
| Undo | Z or UNDO | UNDO |
| Test / edit | Space or TEST / EDIT | TEST / EDIT |
| Grid | G or GRID | GRID |
| Load colors | LOAD | LOAD |
| Pan | CAMERA then drag | CAMERA then drag |
| Zoom | Wheel or +/− | +/− |
| Cancel unfinished work | Escape | Switch tool / app focus loss |
| Trial speed | SPEED cycles 1× / 3× / 6× | Same |

Segment drawing is axis-snapped, not arbitrary 3D splines. Hiding GRID changes its visibility, **not** the cell-based simulation or endpoint snap. 0-unit clicks and >6-unit drags are rejected. Existing segments are revised using remove/redraw + undo; existing-piece dragging is not included in this version.

A release onto the notebook/tool shelf cancels an unfinished action. One pointer owns a construction gesture. UI buttons use the Unity Input System UI module; a second finger isn't interpreted as another independent construction stroke.

## 5. Materials

| Material | Budget/unit | Height/unit layer | Leakage | Walkable | Role |
|---|---:|---:|---:|---|---|
| Brushwood | 1 | 0.75 | 7.5% | No | Cheap, weak, porous starter material |
| Timber | 3 | 0.90 | 1.2% | Yes | General crossing and dam bundle |
| Packed mud | 2 | 0.80 | 0.3% | No | Tight seal but weak structural crest |
| Stone core | 5 | 1.05 | 0.8% | Yes | Strong, heavy core for surge loads |
| Fish-pass weave | 4 | 0.60 | 65% | Yes | Deliberately porous, fish-permeable section |

Numbers are game balancing parameters, not measured material properties or engineering specifications. Added terrain mud is a different tool from packed-mud dam segments.

## 6. Tutorial + three levels

1. **Tutorial / First pond:** two 3-unit timber segments, pond ≥0.35, one rabbit, no broken dam. Budget 90.
2. **Woodland Crossing:** pond ≥0.45 and two rabbits crossing. Budget 66. Test short connected pieces versus long unsupported ones.
3. **Nursery Fork:** pond ≥0.35, one rabbit, at least four fish delivered to the marked nursery outlet, **zero wrong exits**. Budget 100. Blocking the main channel redirects water into the pre-existing side branch. Digging and material choice remain available.
4. **Spring Surge:** pond ≥0.45, three heavier deer, at least four nursery fish, **at most three wrong exits**, no broken dam. Budget 138. A 1.6× source pulse occurs from simulation second 85 to 115. The example uses three layers of two 3-unit stone segments (budget cost 90).

The three challenges are four presets including the tutorial, using a shared base terrain with fork/surge variations, not four hand-sculpted environments. Level buttons let you inspect them without campaign locks. EXAMPLE is a teaching aid, not a score-achievement system.

## 7. What the simulation does

- 24×36 grid storing terrain height and water depth; each unit cell represents one unit of area.
- Signed neighboring water-volume rates plus damped memory, donor outflow scaling, open downstream drainage and a volume ledger.
- Derived approximate velocity from flux/depth, capped for game stability. These are not full shallow-water momentum equations.
- Dam crest/permeability edges: water accumulates, leaks and overtops.
- Integrated hydrostatic pressure estimate plus simplified speed, animal load, material self-weight, span penalty, adjacent support and erosion-undermining terms.
- Utilization above 100% accumulates damage. Failed pieces stop blocking water; upper layers on a failed lower piece fail too. No full rigidbody fracture or elastic beam solver.
- Animals cross only the designated horizontal row using dry ground/walkable crests and short bank ramps. They are not generic pathfinding agents and do not search for another bridge elsewhere.
- Fish are deterministic-seeded flux-weighted cell parcels. They only move through wet permitted edges; they do not seek the goal, teleport or simulate swimming ecology. Display models sit near the surface for visibility.
- Soil thresholds and erosion coefficients differ: topsoil, dirt, loose mud, sand/gravel, clay, bedrock. Clay resists until greater stress; bedrock does not erode. Rocks protect their own nodes. No suspended sediment mass advection or deposition; brown water is cosmetic tint based on total erosion.

"Volumetric" here means conserved water amount as height columns, NOT full 3D voxels/SPH, tunnels, waterfalls with air gaps, or overturning fluid.

## 8. Replace assets

Full directions are in `Documentation/ASSET_REPLACEMENT.md`. Stop Play, select `Beaver Works V3 - Overseer Tutorial` and assign the visual prefabs under its WorksGame component. All slots can stay empty and generated primitives appear.

Use zero-position, zero-rotation, unit-scale WRAPPER prefabs with your FBX/model as a child. Rotate/scale the child inside the wrapper. Do not change the top-level game object transform. No uploaded models were required or claimed to have been used.

## 9. iPad testing

Unity Remote streams Editor output and touch through USB to/from the iPad. It is not a native iPad app and does not measure iPad CPU/GPU performance. On Windows follow Unity's iTunes/USB/device prerequisites and select Remote in Editor settings. New Input System touch uses the UI module.

A real local iOS build ultimately requires macOS/Xcode plus signing, or an appropriately configured cloud build service. Test actual device graphics, touch accuracy, thermal behavior and frame timing; a passing model test cannot validate those.

## 10. Known limits / next steps

- No playable beaver, navigation mesh, swimming, animation rig, inventory harvesting, sound pack or save/load menu.
- Beaver is a cosmetic buddy. It moves toward drag targets and visits placed segments, sampling crest/terrain height; it can take straight-line shortcuts across water. No claim of a physically reachable construction route.
- Generated art is simple Unity primitives, not finished mid-poly modeling. Replace with your school assets.
- Heightfield supports pits/channels, not caves or overhangs; layer colors are readable game abstractions.
- Test results/erosion roll back on EDIT. Stop Play discards runtime design. No persistent saved levels yet.
- A single front-stage camera and landscape HUD are designed first for iPad. Portrait UI not provided.
- Prototype refreshes props/segments by rebuilding visuals on a timer. Object pooling/cached renderers are needed before larger/mobile production levels; no measured native performance claims.
- Shader is a lightweight prototype shader. URP/iOS Metal compatibility must be verified in your engine build; no Unity shader compiler is present here.
- No dynamic terrain MeshCollider cooking: pointer picking and NPC height queries use the model. Imported scenery colliders do not affect the water model.
- Persistent standards, safer generic pathfinding, sediment transport, truly free-angle segments, artist-authored levels and physics-driven failure animation are later work.

Use `Documentation/ENGINE_CHECKLIST.md` before presenting the project as a working Unity/iPad build. If a test fails record your exact Unity version, package versions and full first red Console error. Check your school's AI-assistance disclosure requirements.
