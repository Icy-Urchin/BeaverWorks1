"""Source checks only: pip install tree-sitter tree-sitter-c-sharp. Actual model checks run separately in Unity."""
from pathlib import Path
import json
import tree_sitter,tree_sitter_c_sharp
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
folder=ROOT/'Assets'/'BeaverWorksV3'
files=sorted(folder.rglob('*.cs')) if folder.exists() else sorted(HERE.glob('Works*.cs'))
parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()))
results=[]
for f in files:
    ok=not parser.parse(f.read_bytes()).root_node.has_error
    results.append({'file':f.name,'syntax_passed':ok})
    print(('PASS ' if ok else 'FAIL ')+f.name)
assert len(files)==9 and all(r['syntax_passed'] for r in results)
(HERE/'source_checks.json').write_text(json.dumps({'scope':'Tree-sitter syntax only, NOT Unity API compilation','checks':results},indent=2))
print('9 C# source syntax checks passed. Run Simulation Checks in Unity for model and replay tests.')
