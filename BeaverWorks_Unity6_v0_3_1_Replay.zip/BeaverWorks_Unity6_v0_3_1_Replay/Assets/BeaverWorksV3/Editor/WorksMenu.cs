#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using BeaverWorksV3;
public static class WorksMenu
{
    [MenuItem("Beaver Works V3/Create Overseer Tutorial")]
    public static void Create()
    {
        if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var root=new GameObject("Beaver Works V3 — Overseer Tutorial");
        var game=root.AddComponent<WorksGame>();game.SurfaceShader=Shader.Find("BeaverWorksV3/Surface");
        game.StartingLevel=0;game.ErosionEnabled=true;game.TestSpeed=3;
        Selection.activeGameObject=root;EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
        Debug.Log("Save this scene, run model checks, then Play. See START_HERE.md; Input System and uGUI required.");
    }
    [MenuItem("Beaver Works V3/Run Simulation Checks")]
    public static void Checks(){try{Debug.Log(WorksChecks.Run());Debug.Log(WorksReplayChecks.Run());}catch(System.Exception e){Debug.LogException(e);}}
}
#endif
