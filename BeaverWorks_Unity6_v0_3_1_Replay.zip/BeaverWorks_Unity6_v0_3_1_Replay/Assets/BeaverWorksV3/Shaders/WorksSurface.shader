Shader "BeaverWorksV3/Surface"
{
 Properties{_BaseColor("Base Color",Color)=(1,1,1,1)}
 SubShader
 {
  Tags{"RenderType"="Opaque" "Queue"="Geometry"}
  Pass
  {
   Cull Off
   HLSLPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   struct appdata{float4 vertex:POSITION;float3 normal:NORMAL;float4 color:COLOR;};
   struct v2f{float4 position:SV_POSITION;float4 color:COLOR;float light:TEXCOORD0;};
   float4 _BaseColor;
   v2f vert(appdata i)
   {
    v2f o;o.position=UnityObjectToClipPos(i.vertex);float4 vc=i.color;
    if(dot(vc.rgb,vc.rgb)<.00001)vc=float4(1,1,1,1);o.color=vc*_BaseColor;
    float3 n=normalize(UnityObjectToWorldNormal(i.normal));o.light=.7+.3*saturate(dot(n,normalize(float3(-.3,.8,-.5))));return o;
   }
   float4 frag(v2f i):SV_Target{return float4(i.color.rgb*i.light,1);}
   ENDHLSL
  }
 }
 Fallback "Unlit/Color"
}
