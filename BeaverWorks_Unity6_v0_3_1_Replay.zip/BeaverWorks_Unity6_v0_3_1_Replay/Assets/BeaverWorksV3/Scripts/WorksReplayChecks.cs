using System;
using System.Text;
namespace BeaverWorksV3
{
 public static class WorksReplayChecks
 {
  public static string Run()
  {
   int count=0;var b=new StringBuilder();Action<bool,string> check=(ok,label)=>{if(!ok)throw new Exception("FAIL: "+label);count++;b.AppendLine("PASS: "+label);};
   var m=new WorksModel(3);m.ExampleDesign();m.StartTrial();var tape=new WorksReplay();tape.Begin(m);tape.Record(m,8,2,22,10,true);
   var start=tape.Frames[0];m.Depth[10]=4;check(start.Depth[10]==0,"Captured depth independent of live array");m.Depth[10]=0;
   while(!m.Won&&!m.Ended){m.Tick();tape.Record(m,8,2,22,10);}
   tape.Record(m,8,2,22,10,true);double endTime=m.Time,endGround=m.Ground[m.I(10,10)];int result=m.FishCorrect;bool win=m.Won;
   var viewer=tape.CreateViewer();var frame=tape.Seek(viewer,0);
   check(frame.Time==0&&viewer.Time==0,"Seek beginning restores timestamp zero");
   check(viewer.FishCorrect==0&&!viewer.Won,"Seek beginning restores pre-outcome state");
   check(m.Time==endTime&&m.Won==win&&m.Ground[m.I(10,10)]==endGround,"Replay does not mutate live trial");
   viewer.Depth[10]=123;check(start.Depth[10]==0,"Viewer edits cannot mutate saved snapshot");
   frame=tape.Seek(viewer,endTime);check(viewer.Won==win&&viewer.FishCorrect==result&&viewer.AnimalsPassed==m.AnimalsPassed,"Final replay preserves animal/fish/win outcomes");
   check(Math.Abs(viewer.Ground[m.I(10,10)]-endGround)<1e-6,"Replay preserves eroded terrain within float precision");
   check(frame.BuddyX==8&&frame.BuddyYaw==10,"Buddy pose recorded");
   check(tape.Count>100&&tape.Count<WorksReplay.FrameLimit,"Snapshot sampling bounded");
   check(tape.ApproximateBytes<WorksReplay.ByteLimit&&!tape.Full,"Standard surge recording within memory budget");
   check(tape.IndexAt(-9)==0&&tape.IndexAt(999)==tape.Count-1,"Seek endpoints clamp safely");
   check(tape.PeakPressure>0&&tape.PeakLoad>0,"Peak pressure and load summary recorded");
   bool pulse=false,crossing=false;foreach(var e in tape.Events){pulse|=e.Label=="SPRING SURGE BEGINS";crossing|=e.Label.StartsWith("ANIMAL CROSSING COMPLETE");}
   check(pulse&&crossing,"Replay logs surge and crossings");
   double next=tape.EventTime(0,true);check(next>0&&next<=tape.Duration,"Next event seek bounded");
   check(tape.EventTime(next,false)<next,"Previous event seek");
   check(tape.EventLabel(endTime).Contains("COMPLETE"),"End event label preserved");
   int node=m.I(10,10);check(viewer.ErosionLoss[node]>=0&&viewer.ErosionRate[node]>=0,"Replay carries wear and loss fields");
   foreach(var f in tape.Frames){checkOrderDummy(f);}
   m=new WorksModel(0);m.Place(new DamSegment{X=9,Z=23,Length=6,Material=DamMaterial.Brushwood});m.StartTrial();
   var failureTape=new WorksReplay();failureTape.Begin(m);failureTape.Record(m,force:true);
   for(int z=0;z<23;z++)for(int x=9;x<=14;x++)m.Depth[m.I(x,z)]=3;
   for(int j=0;j<3000&&m.BrokenCount==0;j++){m.Time+=WorksModel.Dt;m.LoadStep(WorksModel.Dt);failureTape.Record(m);}
   failureTape.Record(m,force:true);viewer=failureTape.CreateViewer();failureTape.Seek(viewer,failureTape.Duration);
   check(viewer.BrokenCount>0,"Replay preserves structural breach");
   check(failureTape.FirstWarning>0&&failureTape.EventLabel(failureTape.FirstWarning).Contains("BREACH"),"First warning jumps to breach");
   m=new WorksModel(0);m.Depth[node]=.5;m.VX[node]=1;double g=m.Ground[node];m.ErodeStep(.1);
   check(m.ErosionRate[node]>0&&m.ErosionLoss[node]>0&&m.Ground[node]<g,"Actual wear/loss tracking");
   m.StartTrial();check(m.ErosionLoss[node]==0&&m.ErosionRate[node]==0,"Trial restart clears diagnostic wear");
   double[] baseline={m.Volume,m.Time};tape.Begin(m);tape.Record(m,force:true);tape.Seek(tape.CreateViewer(),0);
   check(m.Volume==baseline[0]&&m.Time==baseline[1],"Read-only replay cannot advance simulator");
   double last=-1;bool ordered=true;foreach(var f in failureTape.Frames){ordered&=f.Time>=last;last=f.Time;}check(ordered,"Event frame timestamps monotonic");
   m=new WorksModel(0);m.Place(new DamSegment{X=9,Z=23,Length=3,Material=DamMaterial.Timber});m.StartTrial();tape.Begin(m);tape.Record(m,force:true);m.Segments[0].Damage=.8;viewer=tape.CreateViewer();tape.Seek(viewer,0);check(viewer.Segments[0].Damage==0&&m.Segments[0].Damage==.8,"Segment snapshots deep copied");
   m=new WorksModel(0);tape.Begin(m);tape.Record(m,force:true);
   for(int j=1;j<2100;j++){m.Time=j*.25;tape.Record(m);}
   check(tape.Full&&tape.Count<=WorksReplay.FrameLimit&&tape.ApproximateBytes<=WorksReplay.ByteLimit,"Long recording cap enforced explicitly");
   check(tape.EventLabel(9999).Contains("CAP REACHED"),"Truncation not silent");
   b.AppendLine("TOTAL: "+count+" replay/diagnostic actual C# checks. Unity integration NOT tested.");return b.ToString();
  }
  static void checkOrderDummy(ReplayFrame f){if(double.IsNaN(f.Time))throw new Exception("Invalid replay timestamp");}
 }
}
