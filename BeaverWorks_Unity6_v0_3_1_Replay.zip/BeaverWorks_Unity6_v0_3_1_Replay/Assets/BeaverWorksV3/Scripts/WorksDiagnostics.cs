using System;
using UnityEngine;
using UnityEngine.UI;
namespace BeaverWorksV3
{
    public sealed partial class WorksGame
    {
        WorksReplay replayTape=new WorksReplay();
        WorksModel retainedLive;
        bool replaying,replayPlaying,replayWasRunning,livePaused;
        double replayTime;
        float playbackSpeed=.5f;
        Vector3 retainedBuddyPosition;Quaternion retainedBuddyRotation;
        int shownFrame=-1;
        bool pressureVisible,erosionVisible;
        int inspectX=11,inspectZ=16;
        Text replayClock,legend,inspector;
        Button replayButton,pauseButton,pressureButton,wearButton;
        Slider replaySlider;
        public bool Replaying{get{return replaying;}}
        void RecordTrial(bool force=false)
        {
            if(!replaying&&Model!=null&&replayTape!=null&&beaver!=null)
                replayTape.Record(Model,beaver.position.x,beaver.position.y,beaver.position.z,beaver.eulerAngles.y,force);
        }
        void ResetReplayForLevel()
        {
            replaying=replayPlaying=livePaused=false;retainedLive=null;shownFrame=-1;replayTime=0;replayTape=new WorksReplay();
        }
        void EnterReplay()
        {
            if(replaying){ExitReplay();return;}
            if(replayTape.Count<2){Say("Run TEST first; a replay needs two recorded frames.");return;}
            Cancel();retainedLive=Model;replayWasRunning=running;retainedBuddyPosition=beaver.position;retainedBuddyRotation=beaver.rotation;
            ClearChildren(segmentsRoot);segmentVisuals.Clear();segmentRenderers.Clear();
            Model=replayTape.CreateViewer();View.Model=Model;replaying=true;replayPlaying=false;replayTime=0;shownFrame=-1;
            beaverJobs.Clear();working=0;accumulator=0;ShowReplay(true);
            Say("REPLAY is read-only. Scrub or play; LIVE returns to your unchanged trial/design.");
        }
        void ExitReplay()
        {
            if(!replaying)return;ClearChildren(segmentsRoot);segmentVisuals.Clear();segmentRenderers.Clear();Model=retainedLive;View.Model=Model;retainedLive=null;replaying=replayPlaying=false;
            running=replayWasRunning;livePaused=running;shownFrame=-1;
            if(beaver!=null){beaver.position=retainedBuddyPosition;beaver.rotation=retainedBuddyRotation;beaverTarget=beaver.position;beaverJobs.Clear();working=0;}
            RefreshAll();Actors();Say(running?"Live test restored, PAUSED. RESUME continues it.":"Your build is unchanged. TEST starts a new recording.");
        }
        void TogglePause()
        {
            if(replaying){if(replayTime>=replayTape.Duration)replayTime=0;replayPlaying=!replayPlaying;ShowReplay(true);}
            else if(running&&!Model.Won&&!Model.Ended){livePaused=!livePaused;accumulator=0;}
            else Say("Start TEST or open REPLAY first.");RefreshDiagnosticUI();
        }
        void SeekReplay(double time)
        {
            if(replayTape.Count<2)return;if(!replaying)EnterReplay();if(!replaying)return;
            replayPlaying=false;replayTime=Math.Max(0,Math.Min(replayTape.Duration,time));ShowReplay(true);
        }
        void JumpEvent(bool next)
        {if(replayTape.Count<2)return;if(!replaying)EnterReplay();SeekReplay(replayTape.EventTime(replayTime,next));}
        void ShowReplay(bool force=false)
        {
            if(!replaying)return;int index=replayTape.IndexAt(replayTime);if(index<0||(!force&&index==shownFrame))return;
            ReplayFrame frame=replayTape.Seek(Model,replayTime);shownFrame=index;
            if(beaver!=null){beaver.position=new Vector3(frame.BuddyX,frame.BuddyY,frame.BuddyZ);beaver.rotation=Quaternion.Euler(0,frame.BuddyYaw,0);beaver.localScale=Vector3.one;}
            View.PressureVisible=pressureVisible;View.ErosionVisible=erosionVisible;
            View.RefreshGround();View.RefreshWater();RefreshProps();RefreshSegments();RefreshMarkers();Actors();
            if(gridVisible)View.BuildGrid(lineMaterial,true);RefreshUI();
        }
        void UpdateReplay(float dt)
        {
            if(replaying&&replayPlaying){replayTime=Math.Min(replayTape.Duration,replayTime+dt*playbackSpeed);if(replayTime>=replayTape.Duration)replayPlaying=false;ShowReplay();}
        }
        void TogglePressure(){pressureVisible=!pressureVisible;ApplyDiagnosticViews();}
        void ToggleWear(){erosionVisible=!erosionVisible;ApplyDiagnosticViews();}
        void ApplyDiagnosticViews()
        {
            if(View==null)return;View.PressureVisible=pressureVisible;View.ErosionVisible=erosionVisible;
            View.RefreshGround();View.RefreshWater();RefreshSegments();RefreshDiagnosticUI();
        }
        void InspectAt(Vector3 point)
        {inspectX=Mathf.Clamp(Mathf.RoundToInt(point.x),0,WorksModel.W-1);inspectZ=Mathf.Clamp(Mathf.RoundToInt(point.z),0,WorksModel.H-1);RefreshDiagnosticUI();}
        void RefreshDiagnosticUI()
        {
            if(Model==null||replayClock==null)return;
            replayButton.interactable=replayTape.Count>=2;replayButton.GetComponentInChildren<Text>().text=replaying?"LIVE":"REPLAY";
            pauseButton.interactable=replaying||(running&&!Model.Won&&!Model.Ended);
            pauseButton.GetComponentInChildren<Text>().text=replaying?(replayPlaying?"PAUSE":"PLAY"):(livePaused?"RESUME":"PAUSE");
            pressureButton.GetComponentInChildren<Text>().text=pressureVisible?"PRESSURE ON":"PRESSURE OFF";
            wearButton.GetComponentInChildren<Text>().text=erosionVisible?"WEAR ON":"WEAR OFF";
            replaySlider.interactable=replayTape.Count>=2;
            replaySlider.SetValueWithoutNotify((float)(replayTape.Duration>0?(replaying?replayTime:replayTape.Duration)/replayTape.Duration:0));
            string mode=replaying?"REPLAY ":running?(livePaused?"PAUSED ":"LIVE "):"BUILD ";
            replayClock.text=mode+(replaying?replayTime:Model.Time).ToString("F2")+" / "+replayTape.Duration.ToString("F2")+" s  · "+replayTape.Count+" frames"+(replaying?" · "+playbackSpeed+"x":"");
            legend.text="PRESSURE: bed gauge 0 blue → 30+ kPa red  |  WEAR: 0 → .01+ m/s amber; ticks = loss  |  LOAD: 0–100% green→red; broken dark\n"+
                (replaying?replayTape.EventLabel(replayTime):"Peak pressure "+replayTape.PeakPressure.ToString("F1")+" kPa · peak load "+replayTape.PeakLoad.ToString("P0"))+
                (replayTape.Full?" · RECORDING CAPPED":"");
            int i=Model.I(inspectX,inspectZ);double speed=Math.Sqrt(Model.VX[i]*Model.VX[i]+Model.VZ[i]*Model.VZ[i]);
            string info="CELL "+inspectX+", "+inspectZ+" · "+Model.Kind(i)+"\nDepth "+Model.Depth[i].ToString("F2")+" m · p "+(9.81*Model.Depth[i]).ToString("F1")+" kPa\nSpeed~ "+speed.ToString("F2")+" m/s\nWear "+Model.ErosionRate[i].ToString("F4")+" m/s\nLoss "+Model.ErosionLoss[i].ToString("F3")+" m";
            var s=PickSegment(new Vector3(inspectX,0,inspectZ));
            if(s!=null)info+="\nSEG #"+s.Id+" · "+s.Ratio.ToString("P0")+" load\nWater~ "+s.WaterDemand.ToString("F1")+" + animal~ "+s.AnimalDemand.ToString("F1")+"\nCapacity~ "+s.EstimatedCapacity.ToString("F1")+" · damage "+s.Damage.ToString("P0");
            else info+="\nTap dam to inspect demand.\nReplay never changes design.";
            inspector.text=info;
        }
        void BuildDiagnosticUI()
        {
            var strip=Panel("Diagnostic switches",safe,new Vector2(0,0),new Vector2(1,0),new Vector2(0,288),new Vector2(-24,62),new Color(.10f,.20f,.16f,.97f),true);
            pressureButton=Button("PRESSURE OFF",strip,new Vector2(0,.5f),new Vector2(97,0),new Vector2(170,42),TogglePressure);
            wearButton=Button("WEAR OFF",strip,new Vector2(0,.5f),new Vector2(275,0),new Vector2(166,42),ToggleWear);
            legend=Label("",strip,new Vector2(0,0),new Vector2(1,1),new Vector2(182,0),new Vector2(-396,-8),12,TextAnchor.MiddleLeft);
            var bar=Panel("Stress replay controls",safe,new Vector2(0,0),new Vector2(1,0),new Vector2(0,227),new Vector2(-24,62),new Color(.10f,.20f,.16f,.97f),true);
            replayButton=Button("REPLAY",bar,new Vector2(0,.5f),new Vector2(65,0),new Vector2(104,42),EnterReplay);
            pauseButton=Button("PAUSE",bar,new Vector2(0,.5f),new Vector2(174,0),new Vector2(100,42),TogglePause);
            Button("START",bar,new Vector2(0,.5f),new Vector2(281,0),new Vector2(100,42),()=>SeekReplay(0));
            Button("PREV",bar,new Vector2(0,.5f),new Vector2(388,0),new Vector2(100,42),()=>JumpEvent(false));
            Button("NEXT",bar,new Vector2(0,.5f),new Vector2(495,0),new Vector2(100,42),()=>JumpEvent(true));
            Button("WARNING",bar,new Vector2(0,.5f),new Vector2(612,0),new Vector2(120,42),()=>SeekReplay(replayTape.FirstWarning));
            replayClock=Label("",bar,new Vector2(1,.5f),new Vector2(1,.5f),new Vector2(-183,19),new Vector2(345,22),13,TextAnchor.MiddleCenter);
            var sliderRect=Panel("Replay timeline",bar,new Vector2(1,.5f),new Vector2(1,.5f),new Vector2(-182,-13),new Vector2(340,22),new Color(.34f,.44f,.37f),true);
            replaySlider=sliderRect.gameObject.AddComponent<Slider>();replaySlider.minValue=0;replaySlider.maxValue=1;
            var handle=Panel("Timeline handle",sliderRect,Vector2.zero,Vector2.one,Vector2.zero,new Vector2(16,0),new Color(.96f,.72f,.28f),true);
            replaySlider.handleRect=handle;replaySlider.targetGraphic=handle.GetComponent<Image>();replaySlider.direction=Slider.Direction.LeftToRight;
            replaySlider.onValueChanged.AddListener(value=>SeekReplay(value*replayTape.Duration));
            var box=Panel("Cell and segment inspector",safe,new Vector2(0,.5f),new Vector2(0,.5f),new Vector2(123,0),new Vector2(222,182),new Color(.10f,.20f,.16f,.93f),true);
            inspector=Label("Tap terrain or dam",box,Vector2.zero,Vector2.one,Vector2.zero,new Vector2(-16,-10),13,TextAnchor.MiddleLeft);
        }
    }
}
