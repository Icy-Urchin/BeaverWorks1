# 08 — Function index generated from final source

Line numbers refer to the active .cs files and byte-identical CopyPasteSource copies. The index is documentation only; line numbers are NOT in code.

## Core/WorksChecks.cs

| Function | Start–end line |
|---|---|
| `Run` | 8–132 |

## Core/WorksModel.cs

| Function | Start–end line |
|---|---|
| `MaterialRule` | 33–43 |
| `Copy` | 53–56 |
| `LevelRule` | 81–95 |
| `WorksModel` | 186–221 |
| `I` | 223–226 |
| `Inside` | 228–231 |
| `Bed` | 233–237 |
| `Sample` | 240–249 |
| `Kind` | 251–257 |
| `Capture` | 260–275 |
| `Restore` | 277–289 |
| `Commit` | 291–302 |
| `Undo` | 304–310 |
| `CanPlace` | 313–387 |
| `Place` | 389–400 |
| `Remove` | 402–413 |
| `Foundation` | 415–425 |
| `Bottom` | 427–434 |
| `Top` | 436–439 |
| `BedAtSegment` | 441–444 |
| `Brush` | 446–480 |
| `PlaceRock` | 482–494 |
| `SyncEdges` | 496–535 |
| `StartTrial` | 597–622 |
| `Proposed` | 624–635 |
| `WaterStep` | 638–701 |
| `PressureKN` | 703–707 |
| `LoadStep` | 710–777 |
| `ErodeStep` | 780–802 |
| `Random` | 804–810 |
| `FishEdge` | 813–825 |
| `FishStep` | 827–880 |
| `WalkHeight` | 882–905 |
| `AnimalStep` | 907–933 |
| `Tick` | 936–969 |
| `ExampleDesign` | 972–985 |
| `ClearDesign` | 987–999 |
| `RemoveRock` | 1001–1009 |

## Core/WorksReplay.cs

| Function | Start–end line |
|---|---|
| `Compact` | 25–31 |
| `Expand` | 33–37 |
| `Capture` | 39–91 |
| `Apply` | 93–125 |
| `Begin` | 185–198 |
| `Record` | 200–264 |
| `CreateViewer` | 266–273 |
| `IndexAt` | 275–290 |
| `Seek` | 292–300 |
| `EventTime` | 302–316 |
| `EventLabel` | 329–340 |

## Core/WorksReplayChecks.cs

| Function | Start–end line |
|---|---|
| `Run` | 8–142 |
| `checkOrderDummy` | 144–148 |

## Editor/BeaverWorksSetup.cs

| Function | Start–end line |
|---|---|
| `ConfigureAndCreate` | 16–66 |
| `Check` | 69–80 |
| `EnvironmentReport` | 83–97 |

## Scripts/WorksGame.cs

| Function | Start–end line |
|---|---|
| `Start` | 79–116 |
| `Mat` | 118–124 |
| `LoadLevel` | 126–176 |
| `Spawn` | 178–208 |
| `DisableColliders` | 210–216 |
| `Primitive` | 218–234 |
| `Block` | 236–241 |
| `MaterialColor` | 243–253 |
| `SegmentPrefab` | 255–265 |
| `ClearChildren` | 267–275 |
| `RefreshSegments` | 277–349 |
| `RefreshProps` | 351–394 |
| `BuildMarkers` | 396–412 |
| `RefreshMarkers` | 414–427 |
| `PointerDown` | 430–482 |
| `PickSegment` | 484–495 |
| `Candidate` | 497–510 |
| `PointerDrag` | 513–545 |
| `OverUI` | 547–560 |
| `PointerUp` | 563–600 |
| `Preview` | 602–611 |
| `Cancel` | 613–623 |
| `ChooseTool` | 625–637 |
| `Undo` | 639–654 |
| `ToggleTest` | 657–686 |
| `RefreshAll` | 688–708 |
| `Visit` | 710–716 |
| `Buddy` | 719–744 |
| `BuddyHeight` | 746–758 |
| `Actors` | 760–785 |
| `Update` | 788–863 |
| `CameraUpdate` | 865–873 |
| `TutorialReady` | 875–896 |
| `Advance` | 898–918 |
| `ToggleGrid` | 920–926 |
| `Say` | 928–933 |
| `RefreshUI` | 935–950 |
| `Panel` | 952–965 |
| `Label` | 967–984 |
| `Button` | 986–994 |
| `BuildUI` | 997–1115 |
| `SafeArea` | 1117–1125 |
| `Suspend` | 1127–1137 |
| `OnApplicationFocus` | 1139–1143 |
| `OnApplicationPause` | 1145–1149 |
| `OnDestroy` | 1151–1156 |
| `RecordTrial` | 1180–1184 |
| `ResetReplayForLevel` | 1186–1193 |
| `EnterReplay` | 1196–1229 |
| `ExitReplay` | 1231–1257 |
| `TogglePause` | 1259–1276 |
| `SeekReplay` | 1278–1289 |
| `JumpEvent` | 1291–1298 |
| `ShowReplay` | 1301–1328 |
| `UpdateReplay` | 1330–1339 |
| `TogglePressure` | 1341–1345 |
| `ToggleWear` | 1347–1351 |
| `ApplyDiagnosticViews` | 1353–1363 |
| `InspectAt` | 1365–1370 |
| `RefreshDiagnosticUI` | 1372–1396 |
| `BuildDiagnosticUI` | 1398–1423 |

## Scripts/WorksPointer.cs

| Function | Start–end line |
|---|---|
| `OnInitializePotentialDrag` | 9–12 |
| `OnPointerDown` | 14–18 |
| `OnDrag` | 20–24 |
| `OnPointerUp` | 26–30 |

## Scripts/WorksView.cs

| Function | Start–end line |
|---|---|
| `SoilColor` | 29–32 |
| `MeshObject` | 34–47 |
| `Initialize` | 49–59 |
| `Tri` | 61–73 |
| `Apply` | 75–83 |
| `P` | 85–88 |
| `RefreshGround` | 90–126 |
| `RefreshWater` | 129–166 |
| `RefreshWearOverlay` | 168–196 |
| `Pick` | 200–239 |
| `BuildGrid` | 241–282 |
| `Line` | 284–295 |
| `OnDestroy` | 297–307 |

## Tests/Editor/BeaverWorksEngineSmokeTests.cs

| Function | Start–end line |
|---|---|
| `StartupAndMouseDragPlacement` | 19–50 |

## Tests/Editor/BeaverWorksModelTests.cs

| Function | Start–end line |
|---|---|
| `OriginalModelAndFourLevelSolutions` | 8–11 |
| `SnapshotReplayAndDiagnosticFields` | 14–17 |
| `FishQueriesRejectInvalidAndNonAdjacentCells` | 20–26 |
| `ExampleLoadCanBeUndoneWithoutDeletingEarlierHistory` | 29–44 |
