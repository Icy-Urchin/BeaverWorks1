# 01 — Install and open the refined overseer project

## Exact software target

| Item | Exact baseline | How to get it |
|---|---|---|
| Unity Hub | Current stable Hub | https://unity.com/download |
| Unity Editor | **Unity 6.3 LTS — 6000.3.26f1** | https://unity.com/releases/editor/whats-new/6000.3.26f1 — use Install in Unity Hub |
| Input System | **1.17.0** / `com.unity.inputsystem` | Supplied manifest resolves from Unity Package Manager |
| Universal Render Pipeline | **17.3.0** / `com.unity.render-pipelines.universal` | Supplied manifest; Editor-aligned core package |
| Unity UI (uGUI) | **2.0.0** / `com.unity.ugui` | Supplied manifest; Editor-aligned core package |
| Test Framework | **1.6.0** / `com.unity.test-framework` | Supplied manifest; tests optional for play, included for checking |
| Optional GLB importer | Unity glTFast **6.20.0** / `com.unity.cloud.gltfast` | Install ONLY if you use GLB/glTF; asset guide explains |
| Optional source editor | Visual Studio 2022 Community or another C# editor | Useful for reading/editing; no need to paste code to use this package |
| iPad input test | Unity Remote 5 | iPad App Store; USB + Windows Apple device/iTunes support |

No Cinemachine, DOTS, PolySpatial, physics-water asset, paid Asset Store pack, GLB, model or external AI service is required. A valid Unity sign-in/license is required by Unity itself.

**Why not 6000.3.2f1?** It was the earlier baseline, not a guarantee of optimality. That release lists iOS/Metal issues. The newer 6000.3.26f1 is the chosen repeatable LTS maintenance target. Do not use Unity 7, a beta, HDRP, or a 2D template for the first acceptance run. “Targeted” is not the same as “executed in Unity”; see test evidence.

Unity core packages are Editor-aligned. If Unity reports a different required core version, do NOT force random downgrades: collect Environment Report and the resolution error. The manifest is a chosen baseline, not evidence that package resolution was run here.

## A. Download only what you need

1. Install Unity Hub.
2. On the exact Editor release page click **Install in Unity Hub**. Confirm **6000.3.26f1** in Hub's Installs list.
3. Windows desktop Play needs the Editor itself. For iPad Remote/native iOS work, also select **iOS Build Support** in that Editor's Add Modules menu.
4. Android Build Support is only for an Android phone/tablet. Windows IL2CPP tooling is not needed for Editor Play.
5. Extract this ZIP into a short writable local folder, for example `C:\UnitySchool\BeaverWorksRefined`. Initially avoid OneDrive-synced project folders; generated Library files can be large and actively changing.

## B. Open the project — do not import it as an asset

1. In File Explorer, open the extracted outer folder. You should see `BeaverWorksProject`, `Documentation`, `CopyPasteSource`, `Validation` and `README_FIRST.txt`.
2. Unity Hub → **Projects → Add → Add project from disk**.
3. Choose **BeaverWorksProject**, the folder containing **Assets, Packages and ProjectSettings**. NOT the outer folder; NOT Assets.
4. Open with **6000.3.26f1**.
5. Wait for package resolution and compilation. Internet is required for the first Unity package downloads. This ZIP does not bundle Unity's package binaries or an offline Library cache.
6. Open **Window → General → Console**. If there are red errors, stop and follow `05_TROUBLESHOOTING.md`, beginning with the FIRST error. Later errors may just be consequences.

No pre-serialized hand-written scene is required. Setup generates a native scene and render-pipeline assets using Unity's own APIs. This avoids relying on manually authored scene/prefab YAML.

## C. Create the scene and enable input

1. Choose **Beaver Works → 1 - Configure Project and Create Tutorial**.
2. It generates a single controller, a native saved tutorial scene and URP configuration. It adds that scene to the build list. It only edits the currently open project; use the supplied fresh one first.
3. Set **Edit → Project Settings → Player → Other Settings → Configuration → Active Input Handling → Input System Package (New)**. Restart the Editor if prompted. The setup script intentionally does not use an unsupported settings API to change this for you.
4. Reopen `Assets/BeaverWorks/Scenes/OverseerTutorial.unity` if needed.
5. In Hierarchy select **Beaver Works - Overseer Controller**. The Inspector should show **Works Game** and **Surface Shader = BeaverWorksV3/Surface**.
6. **Beaver Works → 3 - Environment Report** prints Editor, packages, pipeline and input-backend details to the Console.
7. If automatic URP generation fails, use Assets → Create → Rendering → URP Asset (with Universal Renderer), then assign it under Project Settings → Graphics and the active Quality level. Do not use the 2D Renderer.

The setup script uses the documented `UniversalRenderPipelineAsset.Create(renderer)` factory. Shader compilation and pipeline creation still require acceptance in your Editor.

## D. Check before playing

1. Choose **Beaver Works → 2 - Model and Replay Checks**.
2. Expect **38 original checks** and **26 replay checks** in two reports. These are the same model tests executed here.
3. Optional stronger Unity check: **Window → General → Test Runner → EditMode → Run All**. Four model tests and one engine smoke test are supplied. The engine test enters Play temporarily and checks startup plus a programmatically simulated mouse drag/undo. It does not verify physical iPad touch.
4. Tests may take time because they run multiple complete simulations. Do not treat a pause in output as a frozen Editor immediately.
5. The engine smoke test replaces the open scene: save your scene before running it.

## E. Play the game

1. Select **Game** tab, not Scene. Select landscape **1280 × 800**, **16:10**, or iPad **4:3**.
2. Press Play. Runtime code creates the UI, cameras, terrain, beaver markers and level objects.
3. Start with `02_PLAY_AND_TUTORIAL.md`. No custom model is needed yet.
4. Stop Play before assigning asset prefabs. Changes made while playing usually disappear when you stop.
5. Save the scene after assigning your models.

## F. Test actual iPad input

1. Install **Unity Remote 5** on the iPad.
2. Install Windows Apple device/iTunes support as required by Unity and ensure Windows recognizes the iPad. Use a data-capable USB cable and accept Trust prompts.
3. Unity → Edit → Project Settings → Editor → Unity Remote → Device → select the connected iPad (or appropriate Any iOS option if displayed).
4. Open Remote, connect USB, then Play in Unity. Verify finger press → drag → release, buttons, scrubber and cancellation over UI.
5. Remote runs the game on Windows and streams it to iPad: it cannot prove native iPad frame rate, thermal performance or Metal shader compatibility.
6. A native installed iOS/iPadOS build needs Apple signing and macOS/Xcode for final local compilation, or a configured Unity Build Automation route. Windows alone does not finish the local Xcode build.

## Existing project / manual source route

Do not overlay this project on your working V3. Archive it first. Prefer a new project to avoid duplicate namespaces/scripts. An expert can copy `Assets/BeaverWorks` into a clean Unity 6.3 URP project with the exact package list, then run setup. **Do not also copy CopyPasteSource**. No `.unitypackage` is required for this revised delivery.

See `07_COPY_PASTE.md` for exact script destinations and why some files cannot be attached to GameObjects.
