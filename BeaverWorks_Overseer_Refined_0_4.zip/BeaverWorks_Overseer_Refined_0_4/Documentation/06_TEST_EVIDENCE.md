# 06 — Test evidence and limits

## What was actually executed

- Compiled final **Core C# source** with Microsoft Roslyn loaded through a .NET 10 runtime in the Linux authoring sandbox.
- Executed `WorksChecks.Run`: **38 checks**. Includes volume accounting, placement, terrain/rock behavior, force reference, failure behavior and example solutions for tutorial plus all three levels.
- Executed `WorksReplayChecks.Run`: **26 checks**. Includes snapshot independence, seeking, breaches, animal/fish outcomes, memory cap and non-silent truncation.
- Executed `Validation/refinement_checks.cs`: **13 checks**. Includes invalid fish queries, restored example undo history and timestep validation.
- **Total executed pure-C# checks: 77.** These are real source-code execution, not a Python rewrite of game math.
- Parsed all final project .cs files for C# syntax; source and copy/paste equality, unique GUIDs, package JSON, archive CRC and hash checks run during packaging.
- Rendered the offline HTML documentation locally in Chromium and checked its text layout and source links.

`Validation/actual_csharp_checks.txt` is the saved execution result. The final source hashes identify exactly which files were tested/delivered.

## What was NOT executed

| Item | Status |
|---|---|
| Unity 6000.3.26f1 project package resolution | NOT EXECUTED |
| Unity compilation of runtime/editor/test API calls | NOT EXECUTED |
| URP asset factory execution and shader compilation | NOT EXECUTED |
| Scene generation/persistence and Inspector assignment | NOT EXECUTED |
| Unity Test Runner model/engine wrappers | NOT EXECUTED |
| Mouse/finger events through Unity EventSystem | NOT EXECUTED |
| Native iOS/Metal build or iPad input | NOT EXECUTED |
| Native frame rate, thermal performance | NOT EXECUTED |
| Compatibility with an arbitrary Asset Store pack/GLB | NOT EXECUTED |

There is no Unity Editor/license in this sandbox. Roslyn core compilation is **not** Unity-engine compilation; C# parsing is **not** API/type verification. Documentation HTML rendering is **not** game rendering. Corrected targeted files should be validated in your exact Editor before you rely on them for a school demonstration.

## Unity checks provided for you

1. Setup and Environment Report menus.
2. Same two model/replay check suites inside Unity.
3. Four NUnit EditMode model tests.
4. One Unity engine smoke test: enters Play, creates controller, checks camera/canvas/slider, projects gold-marker endpoints, performs pointer drag/release, checks three-unit placement, undoes it.
5. This smoke test calls the controller methods programmatically, not physical touch; iPad gesture testing is still necessary.
6. Engine smoke tests use reflection to access default Assembly-CSharp from an independent test assembly. Moving runtime scripts into a new asmdef will require updating that reflection assembly name.

## Identified corrections

- Ready-to-open project skeleton with pinned manifest instead of relying only on import notes.
- Native Unity scene/pipeline generation rather than trusting handwritten prefab YAML.
- Single `WorksGame.cs` MonoBehaviour instead of a replay partial-file attachment ambiguity.
- Independent Core assembly without Unity references.
- Correct URP shader include/tags/constant-buffer pattern; no legacy-only UnityCG shader guidance.
- Missing-normal guard for line rendering; core simulation independent of graphics.
- Pointer viewport boundary and bounds/adjacency checks for fish queries.
- Example loading preserves previous undo history.
- Beaver's height resampled along its travel; scale restored after cosmetic construction motion.
- Full-screen background camera plus explicit stage viewport.
- Current package versions and exact component/file destinations documented.
- Source formatting normalized with Roslyn, method comments and generated line-index documentation.

These are verified source changes. **The user's specific import failure is not diagnosed**, because its original Console error and local files were not supplied. Do not describe every source weakness as the confirmed cause of that failure.

## Architecture/performance caveats

The small CPU grid avoids expensive full-volume fluid simulation and runtime terrain MeshCollider cooking. The UI is generated, model uses fixed steps, replay has a bounded cap. Some visual props and placement previews still regenerate; this is a prototype, not a fully optimized mobile product. Profile native hardware before making performance claims. Existing animal walking and passive fish rules are teaching approximations.

Replay stores float samples at four snapshots/sec plus event frames; small rounding is expected. Eroded soil is removed, not transported/deposited. No persistence after Stop Play. A Unity scene is generated only after setup; there is no prebuilt executable.
