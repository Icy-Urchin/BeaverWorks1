# 03 — What the code does, in beginner language

## The few Unity/C# terms you need

- **C# script (.cs):** plain text code. Unity compiles it. Markdown notes are not scripts.
- **Class:** a named container of information and functions.
- **Method/function:** a named block that performs a task, such as `WaterStep`.
- **Variable/field:** stored information, such as water depth or a prefab reference.
- **MonoBehaviour:** a class Unity can put on a GameObject as a component. Not every C# class is one.
- **GameObject:** an item in the Hierarchy. Components tell it what to do.
- **Prefab:** a reusable object asset; here your art is a visual attached to a generated logical object.
- **Inspector:** where you assign the optional prefab references.
- **Scene:** the saved collection of objects. Setup creates one natively inside Unity.
- **Start:** Unity calls once when an active component starts playing.
- **Update:** Unity calls every frame. This prototype then accumulates fixed 1/30-second simulation steps.
- **Core assembly:** independent simulation rules without Unity types, making the real code testable elsewhere.
- **.meta:** Unity asset identifier. Preserve supplied .meta files when copying active assets.
- **.asmdef:** assembly definition. It groups code and specifies dependencies; do not attach it to an object.

## Read the files in this order

| File | Role | Attach manually? |
|---|---|---|
| `Core/WorksModel.cs` | Terrain, placement, volume transfer, erosion, loads, wildlife outcomes | No |
| `Core/WorksReplay.cs` | Captures and reads snapshots; no resimulation during playback | No |
| `Scripts/WorksPointer.cs` | Receives pointer press/drag/release and calls controller | No; runtime UI creates it |
| `Scripts/WorksGame.cs` | Controller, camera, input, UI, beaver visuals, model stepping and replay lifecycle | Setup attaches it automatically |
| `Scripts/WorksView.cs` | Draws model terrain/water/grid/diagnostics and pointer intersections | No; controller creates it |
| `Editor/BeaverWorksSetup.cs` | Creates native scene/URP assets and menu checks | Never; Editor-only |
| `Core/WorksChecks.cs` / `WorksReplayChecks.cs` | Executable model assertions | Never |
| `Tests/Editor/*.cs` | Unity Test Runner checks | Never |
| `Shaders/WorksSurfaceURP.shader` | Colors the generated meshes through URP | Not a C# script |

Only three runtime files are components. The other code is not “missing” from the scene—it is called by those components.

## How one log drag becomes a dam

1. Unity's Input System UI module receives your finger/mouse.
2. `WorksPointer.OnPointerDown` calls `WorksGame.PointerDown` with the pointer ID and screen position.
3. `WorksView.Pick` finds where the pointer hits the model heightfield. No dynamic MeshCollider cooking is required.
4. `WorksGame.Candidate` rounds endpoints and determines horizontal versus vertical placement and length.
5. `WorksModel.CanPlace` checks 1–6 length, bounds, budget, rocks, overlap and stack limits.
6. `WorksGame.Preview` displays gold/red feedback. It does not spend budget.
7. `PointerUp` captures the prior design, calls `Place`, then `Commit`. The material cost is length × unit cost.
8. `SyncEdges` updates which water-grid edges have a barrier, leakage or fish pass.
9. `RefreshSegments` draws the logical member using a generated marker or your prefab.
10. UNDO restores the pre-edit `DesignState`, including inventory. Art position is rebuilt from that state.

## How one test step works

`WorksGame.Update` uses an accumulator. When enough time has passed it calls `WorksModel.Tick` with a fixed step:

1. Add upstream water; the surge level increases source during its pulse.
2. `WaterStep` compares neighboring water-surface heights, calculates volume rates, scales outflow to available volume, transfers water and drains the downstream boundary.
3. Derive capped approximate velocity from flux and depth.
4. `ErodeStep` removes eligible natural/fill material according to local velocity-derived stress and soil resistance. It records actual local wear and accumulated loss.
5. `LoadStep` estimates pressure difference, extra stack demand, animal demand and support/span effects. Overload accumulates damage; a broken member stops blocking water.
6. `FishStep` moves passive fish parcels through actual wet neighboring connections. `AnimalStep` checks the designated crest row.
7. Score pond depth, fish destinations, animal crossings and broken pieces. Goals must persist for the hold time.
8. Record periodic/event snapshots.
9. `WorksView` redraws graphics less often than model stepping. Graphics do not compute the physics.

## What “pressure” and “stress” mean here

- Pressure display: riverbed gauge pressure approximated as 9.81 × depth in kPa, assuming metres and freshwater density.
- Integrated water force: `PressureKN` estimates force per unit-width vertical wetted face.
- Structural utilization: approximate demand divided by approximate capacity. 100% is the game threshold, not an engineering allowable stress.
- Erosion stress: velocity-dependent gameplay proxy, with soil-specific threshold and rate. It is not validated river-bed shear stress.
- Packed-mud segments and loose added soil are intentionally different game concepts.

## How replay avoids changing your game

`WorksReplay.Record` deep-copies changing values. `CreateViewer` makes a separate model. `Seek` applies a saved frame only to that viewer. `ShowReplay` redraws it but never calls Tick. `ExitReplay` restores the retained live model, paused. Compact float data means tiny display rounding is possible.

## Art is not collision/physics

A detailed stone prefab does not become stronger because its mesh looks larger. The material's logical rule decides strength. A visual tree is root-supported by the sampled terrain but is not a deformable physical tree. Animals are display companions to model paths, not Rigidbody wildlife. Prefab colliders are disabled so they do not secretly change the model results.

## Reading/copying code

All active code is ordinary UTF-8 .cs text with braces and four-space indentation, normalized using Roslyn. No markdown fences, line-number prefixes, ellipses or omitted sections are inside .cs files. Core method comments explain intent. `CopyPasteSource` contains identical complete files; use `07_COPY_PASTE.md` to put them in the correct destinations.

`08_FUNCTION_INDEX.md` is generated from the final source and lists exact file/line locations. `09_SOURCE_TRACEABILITY.md` says where each function family came from, what was retained from V3 and which public API patterns informed changes.
