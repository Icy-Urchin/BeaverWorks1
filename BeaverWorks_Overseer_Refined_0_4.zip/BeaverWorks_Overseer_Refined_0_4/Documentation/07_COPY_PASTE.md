# 07 — Complete source for reading or copy/paste

## Easiest route: do not paste anything

Open the supplied BeaverWorksProject in Unity Hub. Its active source is already in the correct folders. Read the copies in `CopyPasteSource` or the linked source pages in `START_HERE.html` outside Unity.

## Expert reconstruction route

Use this ONLY instead of the supplied source, not in addition to it. Duplicate classes break compilation.

1. Create a clean Unity 6000.3.26f1 Universal 3D project.
2. Ensure Input System 1.17.0, URP 17.3.0, uGUI 2.0.0, Test Framework 1.6.0.
3. Create the destination folders below in Assets.
4. Copy each whole raw .cs file, retaining its exact filename. No markdown fences, leading line numbers, ellipses or shortened examples.
5. If manually pasting, create an empty text file in your C# editor, replace all default Unity template text with the complete source, and save with the exact name/extension.
6. Use `.shader` for shader source; `.asmdef` for JSON assembly definitions. Never paste HLSL or JSON into a C# class.
7. Set Active Input Handling New, run setup menu, save scene, run checks.

| Source copy | Destination in Unity project |
|---|---|
| Core/WorksModel.cs | Assets/BeaverWorks/Core/WorksModel.cs |
| Core/WorksReplay.cs | Assets/BeaverWorks/Core/WorksReplay.cs |
| Core/WorksChecks.cs | Assets/BeaverWorks/Core/WorksChecks.cs |
| Core/WorksReplayChecks.cs | Assets/BeaverWorks/Core/WorksReplayChecks.cs |
| Core/BeaverWorks.Core.asmdef | Assets/BeaverWorks/Core/BeaverWorks.Core.asmdef |
| Scripts/WorksGame.cs | Assets/BeaverWorks/Scripts/WorksGame.cs |
| Scripts/WorksView.cs | Assets/BeaverWorks/Scripts/WorksView.cs |
| Scripts/WorksPointer.cs | Assets/BeaverWorks/Scripts/WorksPointer.cs |
| Editor/BeaverWorksSetup.cs | Assets/BeaverWorks/Editor/BeaverWorksSetup.cs |
| Shaders/WorksSurfaceURP.shader | Assets/BeaverWorks/Shaders/WorksSurfaceURP.shader |
| Tests/Editor/* | Assets/BeaverWorks/Tests/Editor/* |

Files in Editor stay Editor-only. Core is not attachable. Only WorksGame needs an initial scene component; setup adds it, and that code creates WorksView/WorksPointer. Do not add the three components yourself in addition to setup.

`CopyPasteSource` files are byte-identical to active source. If you edit one copy, update only the active source for Unity to use it; the browser copy is not a live linked asset. Full source is also displayed as plain text in the generated offline browser guide, without formatting characters inside the copied code.

## Before importing an older branch

The namespace remains BeaverWorksV3 to preserve V3 model behavior, even though package revision is 0.4. Do not import old BeaverWorksV3 alongside this same namespace. Keep your old project as an archive; a fresh project is safer than trying to delete individual old partial classes after every error.
