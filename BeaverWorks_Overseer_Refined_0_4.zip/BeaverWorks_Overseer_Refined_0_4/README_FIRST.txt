BEAVER WORKS - REFINED OVERSEER PROJECT (revision 0.4)

THIS IS THE THIRD GAME STYLE, NOT THE PLAYABLE-BEAVER VERSION.
Target: Unity 6.3 LTS, exact Editor 6000.3.26f1, Windows authoring.

1. Read Documentation/01_SETUP.md (or START_HERE.html in your browser).
2. Extract the entire ZIP. Do NOT import the whole ZIP into Unity.
3. Unity Hub > Projects > Add > Add project from disk.
4. Select BeaverWorksProject: the folder containing Assets, Packages and ProjectSettings.
5. Open with Unity 6000.3.26f1. First package download needs internet.
6. In Unity: Beaver Works > 1 - Configure Project and Create Tutorial.
7. Set Player > Active Input Handling to Input System Package (New) and restart if prompted.
8. Beaver Works > 2 - Model and Replay Checks.
9. Press Play in GAME view (not Scene view).

NO MODEL DOWNLOAD IS REQUIRED TO TEST THE LOGIC.
Generated simple markers remain only as optional fallbacks. Add your own prefabs using Documentation/04_ASSETS.md.

Folders:
BeaverWorksProject = working Unity project. Only its Assets contains active code.
Documentation = guides and readable explanations; NEVER paste these into a script.
CopyPasteSource = byte-identical code copies for inspection/manual reconstruction.
Validation = executed Core tests, source/package checks, and honest engine acceptance checklist.

IMPORTANT:
Only WorksGame, WorksView and WorksPointer are runtime components.
WorksGame is attached automatically by the setup menu.
WorksView and WorksPointer are created by code; do not attach them yourself.
Core code is plain C# data/rules, not components to drag into the scene.
Do NOT copy CopyPasteSource into Assets along with the project scripts: that creates duplicates.
Do NOT rename .md or .txt documentation to .cs.

VERIFICATION:
77 checks were compiled and executed against actual pure C# model/replay/refinement source.
Unity-engine compilation, shader compilation, startup, mouse/touch UI and iPad builds were NOT executed here.
Included Unity Test Runner smoke tests are NOT yet a passing Unity test report.
No Unity license/editor is available in the authoring sandbox.

This package corrects identified source/setup weaknesses. It is not certified as a tested native iPad game.
