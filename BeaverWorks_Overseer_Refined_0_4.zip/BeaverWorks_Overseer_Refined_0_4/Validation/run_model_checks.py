"""Maintainer check. Requires pythonnet + the Roslyn/.NET runtime paths described in TEST_EVIDENCE.md.
End users should use Beaver Works > 2 - Model and Replay Checks inside Unity instead.
"""
import os
from pathlib import Path
from pythonnet import load
root=Path('/tmp/roslyn_runtime/package')
os.environ['DOTNET_SYSTEM_GLOBALIZATION_INVARIANT']='1'
load('coreclr',runtime_config='/tmp/works_validation.runtimeconfig.json',dotnet_root='/tmp/works_netroot')
import clr
for name in ['System.Collections.Immutable','System.Reflection.Metadata','Microsoft.CodeAnalysis','Microsoft.CodeAnalysis.CSharp']:
    clr.AddReference(str(root/(name+'.dll')))
import System
from System import Array
from System.IO import MemoryStream
from Microsoft.CodeAnalysis import MetadataReference,SyntaxTree,OutputKind
from Microsoft.CodeAnalysis.CSharp import CSharpSyntaxTree,CSharpCompilation,CSharpCompilationOptions
folder=Path(__file__).resolve().parents[1]/'BeaverWorksProject/Assets/BeaverWorks/Core'
refs=Array[MetadataReference]([MetadataReference.CreateFromFile(str(p)) for p in root.glob('*.dll') if p.name.startswith('System.') or p.name in ['mscorlib.dll','netstandard.dll']])
trees=Array[SyntaxTree]([CSharpSyntaxTree.ParseText(p.read_text()) for p in list(folder.glob('*.cs'))+[Path(__file__).parent/'refinement_checks.cs']])
comp=CSharpCompilation.Create('WorksChecked',trees,refs,CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));stream=MemoryStream();result=comp.Emit(stream)
for d in result.Diagnostics:print(d)
assert result.Success
asm=System.Reflection.Assembly.Load(stream.ToArray());reports=[]
for name in ['WorksChecks','WorksReplayChecks']:
    text=str(asm.GetType('BeaverWorksV3.'+name).GetMethod('Run').Invoke(None,None));reports.append(text);print(text)
text=str(asm.GetType('RefinementChecks').GetMethod('Run').Invoke(None,None));reports.append(text);print(text)
(Path(__file__).parent/'actual_csharp_checks.txt').write_text('\n'.join(reports))
print('Compiled actual Core C# and executed 77 model/replay/refinement checks; NOT Unity API runtime.')
