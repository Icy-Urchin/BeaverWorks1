"""Validate file structure, syntax and copy/paste equality. Does not run Unity.
Requires: pip install tree-sitter tree-sitter-c-sharp
"""
from pathlib import Path
import json,re,hashlib
import tree_sitter,tree_sitter_c_sharp
base=Path(__file__).resolve().parents[1];assets=base/'BeaverWorksProject/Assets/BeaverWorks';parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()))
checks=[]
def check(label,ok):
 checks.append({'check':label,'passed':bool(ok)})
 if not ok:raise AssertionError(label)
 print('PASS',label)
for p in assets.rglob('*.cs'):
 check('Syntax '+str(p.relative_to(assets)),not parser.parse(p.read_bytes()).root_node.has_error)
 check('No markdown fences '+p.name,'```' not in p.read_text())
for p in assets.rglob('*'):
 if p.is_file() and p.suffix in ['.cs','.shader','.asmdef']:
  copy=base/'CopyPasteSource'/p.relative_to(assets)
  check('Source copy identical '+p.name,copy.exists() and copy.read_bytes()==p.read_bytes())
for p in (base/'BeaverWorksProject').rglob('*.json'):json.loads(p.read_text())
for p in assets.rglob('*.asmdef'):json.loads(p.read_text())
check('Package JSON parse',True)
check('No docs active in Assets',not any(p.suffix in ['.md','.txt','.html'] for p in assets.rglob('*') if p.is_file()))
check('Only one WorksGame implementation',len(list(assets.rglob('WorksGame.cs')))==1 and 'partial class WorksGame' not in (assets/'Scripts/WorksGame.cs').read_text())
guids=[]
for p in assets.rglob('*.meta'):
 g=re.search(r'^guid: ([0-9a-f]{32})$',p.read_text(),re.M);check('Valid meta '+p.name,bool(g));guids.append(g[1])
check('Unique meta GUIDs',len(guids)==len(set(guids)))
(base/'Validation/package_checks.json').write_text(json.dumps({'scope':'Package/source checks, NOT Unity execution','checks':checks},indent=2))
print(len(checks),'package/source checks passed')
