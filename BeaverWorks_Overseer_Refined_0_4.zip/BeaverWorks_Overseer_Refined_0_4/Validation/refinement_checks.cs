using System;
using BeaverWorksV3;
public static class RefinementChecks
{
    public static string Run()
    {
        int n=0;Action<bool,string> check=(ok,label)=>{if(!ok)throw new Exception(label);n++;Console.WriteLine("PASS refinement: "+label);};
        var m=new WorksModel(2);
        check(!m.FishEdge(-1,1,0,1),"Fish source outside patch rejected");
        check(!m.FishEdge(1,1,3,1),"Nonadjacent fish move rejected");
        check(!m.FishEdge(1,1,1,1),"Same-cell fish query rejected");
        m.Depth[m.I(11,2)]=m.Depth[m.I(11,3)]=.3;
        check(m.FishEdge(11,2,11,3),"Adjacent wet cells accepted");
        m.Depth[m.I(11,2)]=0;check(!m.FishEdge(11,2,11,3),"Dry source rejected");
        m=new WorksModel(0);var old=m.Capture();m.Place(new DamSegment{X=9,Z=23,Length=2,Material=DamMaterial.Timber});m.Commit(old);
        var before=m.Capture();m.ClearDesign(false);m.ExampleDesign();m.Commit(before);
        check(m.Undo()&&m.Segments.Count==1&&m.Segments[0].Length==2,"Example undo restores prior design");
        check(m.Undo()&&m.Segments.Count==0,"Example preserves earlier history");
        m=new WorksModel(0);m.Depth[m.I(11,15)]=2;m.Initial=m.Volume;var tape=new WorksReplay();tape.Begin(m);tape.Record(m,force:true);var viewer=tape.CreateViewer();tape.Seek(viewer,0);
        check(Math.Abs(viewer.Depth[m.I(11,15)]-2)<1e-6,"Replay depth survives copy");
        check(Math.Abs(viewer.MassError)<1e-7,"Simple copied replay mass balance");
        foreach(double dt in new[]{0.0,-.01,double.NaN,double.PositiveInfinity}){bool rejected=false;try{m.WaterStep(dt);}catch(ArgumentOutOfRangeException){rejected=true;}check(rejected,"Invalid timestep rejected: "+dt);}
        return "TOTAL: "+n+" refinement checks passed. Core only; Unity unexecuted.";
    }
}
