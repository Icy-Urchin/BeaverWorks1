using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
#endif
namespace BeaverWorksV3
{
    // Overseer-mode prototype: no playable character, no navigation/physics dependencies.
    [DisallowMultipleComponent]
    public sealed class WorksGame : MonoBehaviour
    {
        [Header("Visual replacements: wrappers at unit scale; animals face +Z")]
        public GameObject BeaverPrefab, RabbitPrefab, DeerPrefab, FishPrefab, RockPrefab, TreePrefab;
        public GameObject BrushwoodPrefab, TimberPrefab, MudPrefab, StonePrefab, FishPassPrefab;
        public Shader SurfaceShader;
        [Range(0, 3)]
        public int StartingLevel;
        public bool ErosionEnabled = true;
        [Range(1, 6)]
        public float TestSpeed = 3;
        public WorksModel Model { get; private set; }
        public WorksView View { get; private set; }
        public Camera StageCamera { get; private set; }

        enum Tool
        {
            Segment,
            Dig,
            Mud,
            Rock,
            Remove,
            Camera
        }

        Tool tool = Tool.Segment;
        DamMaterial selected = DamMaterial.Timber;
        Transform root, segmentsRoot, propsRoot, previewRoot, beaver, animal;
        readonly List<Transform> fishVisuals = new List<Transform>();
        readonly Dictionary<int, Transform> segmentVisuals = new Dictionary<int, Transform>();
        readonly Dictionary<int, Renderer[]> segmentRenderers = new Dictionary<int, Renderer[]>();
        readonly List<int> obsoleteVisuals = new List<int>();
        readonly List<Material> materials = new List<Material>();
        Material surface, lineMaterial, gold, red, gray, green;
        Canvas canvas;
        RectTransform safe;
        Text title, guide, stats, message, materialInfo;
        Button nextButton, testButton, gridButton, stressButton;
        bool gridVisible = true, stressVisible, running, brushing, strokeChanged;
        int tutorialStep, owner = int.MinValue;
        Vector3 anchor, beaverTarget;
        Vector2 lastPointer;
        DesignState preStroke, trialDesign;
        DamSegment candidate;
        float accumulator, visualTimer, groundTimer, noticeTimer;
        float zoom = 15.2f;
        Vector3 pan;
        LineRenderer pondRing, crossLine, channelLine;
        readonly List<LineRenderer> targetLines = new List<LineRenderer>();
        readonly Queue<Vector3> beaverJobs = new Queue<Vector3>();
        float working;
        readonly string[] tutorial =
        {
            "1 / LOOK · The river runs from the TOP of your screen to the BOTTOM. Toggle GRID off/on, then NEXT.",
            "2 / DRAW · TIMBER selected. Press at the LEFT gold marker and drag RIGHT to the middle marker: 3 units. Release to place.",
            "3 / JOIN · Draw another 3-unit TIMBER segment from the middle to the RIGHT marker. Gold = valid; red = rejected.",
            "4 / UNDO · Press UNDO or Z. Then redraw the missing 3-unit segment. Each drag is one action.",
            "5 / SHAPE · Select DIG or MUD and hold/drag on a bank. Watch the surface move and the soil color change. UNDO restores a whole stroke.",
            "6 / TEST · Press TEST. Watch pond depth, load colors, erosion arrows, and a rabbit crossing. EDIT restores the pre-test terrain.",
            "7 / COMPLETE · Pond + dry animal crossing + no broken segments. NEXT opens Woodland Crossing. You can also select any level."
        };
        int tutorialUndoBase;
        bool gridTouched, terrainTouched;
        // Unity calls this once on entering Play. Create camera, runtime UI and initial level.
        void Start()
        {
            Application.targetFrameRate = 60;
            Shader s = SurfaceShader != null ? SurfaceShader : Shader.Find("BeaverWorksV3/Surface");
            if (s == null)
            {
                Debug.LogError("Assign BeaverWorksV3/Surface shader before Play.");
                enabled = false;
                return;
            }

            surface = Mat(s, Color.white);
            lineMaterial = Mat(s, new Color(.43f, .52f, .42f));
            gold = Mat(s, new Color(.95f, .68f, .24f));
            red = Mat(s, new Color(.83f, .26f, .18f));
            gray = Mat(s, new Color(.63f, .65f, .58f));
            green = Mat(s, new Color(.26f, .78f, .54f));
            var cg = new GameObject("Centered front-and-top camera", typeof(Camera), typeof(AudioListener));
            cg.transform.SetParent(transform, false);
            StageCamera = cg.GetComponent<Camera>();
            StageCamera.orthographic = true;
            StageCamera.rect = new Rect(.20f, .40f, .70f, .36f);
            StageCamera.depth = 1;
            var backgroundObject = new GameObject("Full-screen background", typeof(Camera));
            backgroundObject.transform.SetParent(transform, false);
            var background = backgroundObject.GetComponent<Camera>();
            background.cullingMask = 0;
            background.depth = 0;
            background.clearFlags = CameraClearFlags.SolidColor;
            background.backgroundColor = new Color(.12f, .20f, .16f);
            StageCamera.nearClipPlane = .1f;
            StageCamera.farClipPlane = 180;
            StageCamera.clearFlags = CameraClearFlags.SolidColor;
            StageCamera.backgroundColor = new Color(.77f, .84f, .74f);
            cg.tag = "MainCamera";
            BuildUI();
            LoadLevel(StartingLevel);
        }

        Material Mat(Shader s, Color color)
        {
            var m = new Material(s);
            m.SetColor("_BaseColor", color);
            materials.Add(m);
            return m;
        }

        public void LoadLevel(int index)
        {
            Cancel();
            ResetReplayForLevel();
            running = false;
            trialDesign = null;
            accumulator = 0;
            tutorialStep = 0;
            gridTouched = terrainTouched = false;
            tutorialUndoBase = 0;
            pan = Vector3.zero;
            beaverJobs.Clear();
            fishVisuals.Clear();
            segmentVisuals.Clear();
            segmentRenderers.Clear();
            working = visualTimer = groundTimer = 0;
            if (root != null)
            {
                root.gameObject.SetActive(false);
                Destroy(root.gameObject);
            }

            Model = new WorksModel(index)
            {
                Erosion = ErosionEnabled
            };
            root = new GameObject("Generated level world").transform;
            root.SetParent(transform, false);
            View = root.gameObject.AddComponent<WorksView>();
            View.Initialize(Model, surface);
            segmentsRoot = new GameObject("Dam segments").transform;
            segmentsRoot.SetParent(root, false);
            propsRoot = new GameObject("Scenery props").transform;
            propsRoot.SetParent(root, false);
            previewRoot = new GameObject("Placement preview").transform;
            previewRoot.SetParent(root, false);
            beaver = Spawn(BeaverPrefab, "Beaver buddy", root);
            beaver.position = new Vector3(8, (float)Model.Sample(8, 22) + .1f, 22);
            beaverTarget = beaver.position;
            animal = Spawn(Model.Level == 3 ? DeerPrefab : RabbitPrefab, Model.Level == 3 ? "Deer" : "Rabbit", root);
            animal.gameObject.SetActive(false);
            BuildMarkers();
            RefreshProps();
            RefreshSegments();
            View.BuildGrid(lineMaterial, gridVisible);
            tool = Tool.Segment;
            selected = DamMaterial.Timber;
            Say("Draw segments from one endpoint to the next. No character movement required.");
            CameraUpdate();
            RefreshUI();
        }

        Transform Spawn(GameObject prefab, string label, Transform parent)
        {
            if (prefab != null)
            {
                var go = Instantiate(prefab, parent);
                go.name = label;
                DisableColliders(go);
                return go.transform;
            }

            var holder = new GameObject(label).transform;
            holder.SetParent(parent, false);
            if (label.Contains("Fish"))
            {
                Primitive(holder, PrimitiveType.Capsule, new Vector3(0, 0, 0), new Vector3(.2f, .2f, .5f), new Color(.84f, .55f, .23f));
                return holder;
            }

            bool deer = label.Contains("Deer"), rabbit = label.Contains("Rabbit");
            float size = deer ? 1.05f : rabbit ? .58f : .7f;
            Primitive(holder, PrimitiveType.Sphere, new Vector3(0, size * .35f, 0), new Vector3(size * .72f, size * .55f, size), new Color(.44f, .29f, .17f));
            Primitive(holder, PrimitiveType.Sphere, new Vector3(0, size * .48f, size * .48f), Vector3.one * size * .45f, new Color(.51f, .35f, .20f));
            if (rabbit)
            {
                Primitive(holder, PrimitiveType.Capsule, new Vector3(-.11f, .7f, .22f), new Vector3(.1f, .35f, .1f), new Color(.53f, .39f, .26f));
                Primitive(holder, PrimitiveType.Capsule, new Vector3(.11f, .7f, .22f), new Vector3(.1f, .35f, .1f), new Color(.53f, .39f, .26f));
            }
            else if (!deer)
                Primitive(holder, PrimitiveType.Cube, new Vector3(0, .12f, -.55f), new Vector3(.35f, .1f, .5f), new Color(.24f, .18f, .12f));
            return holder;
        }

        void DisableColliders(GameObject go)
        {
            foreach (var c in go.GetComponentsInChildren<Collider>())
                c.enabled = false;
            foreach (var r in go.GetComponentsInChildren<Rigidbody>())
                r.isKinematic = true;
        }

        Transform Primitive(Transform parent, PrimitiveType type, Vector3 position, Vector3 scale, Color color)
        {
            var go = GameObject.CreatePrimitive(type);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = surface;
            go.GetComponent<Renderer>().SetPropertyBlock(Block(color));
            var c = go.GetComponent<Collider>();
            if (c != null)
            {
                c.enabled = false;
                Destroy(c);
            }

            return go.transform;
        }

        MaterialPropertyBlock Block(Color color)
        {
            var b = new MaterialPropertyBlock();
            b.SetColor("_BaseColor", color);
            return b;
        }

        Color MaterialColor(DamMaterial m)
        {
            return new[]
            {
                new Color(.57f, .44f, .25f),
                new Color(.43f, .26f, .13f),
                new Color(.37f, .27f, .17f),
                new Color(.49f, .54f, .52f),
                new Color(.34f, .65f, .61f)
            }[(int)m];
        }

        GameObject SegmentPrefab(DamMaterial m)
        {
            return new[]
            {
                BrushwoodPrefab,
                TimberPrefab,
                MudPrefab,
                StonePrefab,
                FishPassPrefab
            }[(int)m];
        }

        void ClearChildren(Transform p)
        {
            for (int i = p.childCount - 1; i >= 0; i--)
            {
                var c = p.GetChild(i);
                c.gameObject.SetActive(false);
                Destroy(c.gameObject);
            }
        }

        void RefreshSegments()
        {
            obsoleteVisuals.Clear();
            foreach (var item in segmentVisuals)
                if (!Model.Segments.Exists(s => s.Id == item.Key))
                    obsoleteVisuals.Add(item.Key);
            foreach (int id in obsoleteVisuals)
            {
                segmentVisuals[id].gameObject.SetActive(false);
                Destroy(segmentVisuals[id].gameObject);
                segmentVisuals.Remove(id);
                segmentRenderers.Remove(id);
            }

            foreach (var p in Model.Segments)
            {
                Transform h;
                bool create = !segmentVisuals.TryGetValue(p.Id, out h);
                if (create)
                {
                    h = new GameObject("Segment #" + p.Id + " " + WorksModel.Materials[(int)p.Material].Name).transform;
                    h.SetParent(segmentsRoot, false);
                    segmentVisuals[p.Id] = h;
                }

                h.position = new Vector3(p.X + (p.AlongX ? p.Length * .5f : 0), (float)(Model.Bottom(p) + WorksModel.Materials[(int)p.Material].Height * .5), p.Z + (p.AlongX ? 0 : p.Length * .5f));
                h.rotation = Quaternion.Euler(0, p.AlongX ? 0 : 90, 0);
                var prefab = SegmentPrefab(p.Material);
                Color color = p.Broken ? new Color(.30f, .17f, .14f) : stressVisible ? Color.Lerp(new Color(.25f, .75f, .45f), new Color(.9f, .23f, .15f), Mathf.Clamp01((float)p.Ratio)) : MaterialColor(p.Material);
                if (create)
                {
                    if (prefab != null)
                    {
                        var g = Instantiate(prefab, h);
                        DisableColliders(g);
                        g.transform.localScale = new Vector3(p.Length, (float)WorksModel.Materials[(int)p.Material].Height, 1);
                        if (stressVisible || p.Broken)
                            foreach (var renderer in g.GetComponentsInChildren<Renderer>())
                            {
                                var block = Block(color);
                                block.SetColor("_Color", color);
                                renderer.SetPropertyBlock(block);
                            }
                    }
                    else
                    {
                        Primitive(h, PrimitiveType.Cube, Vector3.zero, new Vector3(p.Length, (float)WorksModel.Materials[(int)p.Material].Height, .46f), color);
                        if (p.Material == DamMaterial.Timber || p.Material == DamMaterial.Brushwood)
                            for (int j = 0; j < 3; j++)
                            {
                                var l = Primitive(h, PrimitiveType.Cylinder, new Vector3(0, (j - 1) * .18f, 0), new Vector3(.16f, p.Length * .5f, .16f), color * .88f);
                                l.localRotation = Quaternion.Euler(0, 0, 90);
                            }
                    }

                    segmentRenderers[p.Id] = h.GetComponentsInChildren<Renderer>();
                }

                Color current = p.Broken ? new Color(.30f, .17f, .14f) : stressVisible ? Color.Lerp(new Color(.25f, .75f, .45f), new Color(.9f, .23f, .15f), Mathf.Clamp01((float)p.Ratio)) : MaterialColor(p.Material);
                foreach (var renderer in segmentRenderers[p.Id])
                {
                    var tint = Block(current);
                    tint.SetColor("_Color", current);
                    renderer.SetPropertyBlock(tint);
                }

                if (p.Broken)
                {
                    h.position += Vector3.down * .25f;
                    h.Rotate(0, 0, 12);
                }
            }
        }

        void RefreshProps()
        {
            ClearChildren(propsRoot);
            for (int z = 1; z < WorksModel.H - 1; z++)
                for (int x = 1; x < WorksModel.W - 1; x++)
                    if (Model.Rocks[Model.I(x, z)])
                    {
                        Transform r;
                        if (RockPrefab != null)
                        {
                            r = Instantiate(RockPrefab, propsRoot).transform;
                            DisableColliders(r.gameObject);
                        }
                        else
                            r = Primitive(propsRoot, PrimitiveType.Sphere, Vector3.zero, new Vector3(1, 1.1f, 1), new Color(.52f, .55f, .50f));
                        r.position = new Vector3(x, (float)(Model.Ground[Model.I(x, z)] + Model.Fill[Model.I(x, z)]) + .5f, z);
                    }

            for (int z = 5; z < WorksModel.H - 3; z += 7)
                foreach (int x in new[]
                {
                    3,
                    5,
                    21
                }

                )
                    if (Model.Original[Model.I(x, z)] - Model.Ground[Model.I(x, z)] < .25)
                    {
                        var h = new GameObject("Root-supported tree").transform;
                        h.SetParent(propsRoot, false);
                        h.position = new Vector3(x, (float)Model.Sample(x, z), z);
                        if (TreePrefab != null)
                        {
                            var t = Instantiate(TreePrefab, h);
                            DisableColliders(t);
                        }
                        else
                        {
                            Primitive(h, PrimitiveType.Cylinder, new Vector3(0, .65f, 0), new Vector3(.18f, .65f, .18f), new Color(.38f, .25f, .14f));
                            Primitive(h, PrimitiveType.Sphere, new Vector3(0, 1.55f, 0), new Vector3(1, 1.4f, 1), new Color(.24f, .43f, .26f));
                        }
                    }
        }

        void BuildMarkers()
        {
            targetLines.Clear();
            float row = Model.Rule.CrossRow;
            pondRing = WorksView.Line(root, new Vector3[49], gray, .07f);
            crossLine = WorksView.Line(root, new[] { new Vector3(9, (float)Model.Sample(9, row) + .08f, row), new Vector3(15, (float)Model.Sample(15, row) + .08f, row) }, gold, .07f);
            for (int x = 9; x <= 15; x += 3)
            {
                float y = (float)Model.Sample(x, row) + .08f;
                var l = WorksView.Line(root, new[] { new Vector3(x - .22f, y, row), new Vector3(x + .22f, y, row) }, gold, .19f);
                targetLines.Add(l);
            }

            channelLine = WorksView.Line(root, new[] { new Vector3(15, 2.4f, 15), new Vector3(19, 2.4f, 15), new Vector3(19, 2.4f, 34) }, gray, .09f);
            channelLine.gameObject.SetActive(Model.Rule.Fork);
            RefreshMarkers();
        }

        void RefreshMarkers()
        {
            var points = new Vector3[49];
            for (int i = 0; i < points.Length; i++)
            {
                float a = i * Mathf.PI * 2 / 48, x = 11.5f + 3.15f * Mathf.Cos(a), z = (10 + Model.Rule.CrossRow) * .5f + (Model.Rule.CrossRow - 10) * .45f * Mathf.Sin(a);
                int xx = Mathf.Clamp(Mathf.RoundToInt(x), 0, WorksModel.W - 1), zz = Mathf.Clamp(Mathf.RoundToInt(z), 0, WorksModel.H - 1);
                points[i] = new Vector3(x, Mathf.Max((float)Model.Sample(x, z) + .06f, (float)(Model.Bed(xx, zz) + Model.Depth[Model.I(xx, zz)]) + .08f), z);
            }

            pondRing.SetPositions(points);
            pondRing.sharedMaterial = Model.PondDepth >= Model.Rule.PondGoal ? green : gray;
            channelLine.sharedMaterial = Model.FishCorrect >= Model.Rule.FishGoal && Model.Rule.FishGoal > 0 ? green : gray;
        }

        // Mouse/finger press: claim one pointer, pick terrain, then start a design action.
        public void PointerDown(int id, Vector2 screen)
        {
            if (owner != int.MinValue)
                return;
            // A drag must begin inside the visible river viewport, not behind a toolbar.
            if (!StageCamera.pixelRect.Contains(screen))
                return;
            Vector3 p;
            if (!View.Pick(StageCamera, screen, out p))
                return;
            InspectAt(p);
            if ((running || replaying) && tool != Tool.Camera)
                return;
            owner = id;
            lastPointer = screen;
            anchor = p;
            beaverTarget = p;
            beaverTarget.y = BuddyHeight(p.x, p.z);
            if (tool == Tool.Segment)
            {
                candidate = Candidate(anchor, anchor);
                Preview();
            }
            else if (tool == Tool.Dig || tool == Tool.Mud)
            {
                preStroke = Model.Capture();
                brushing = true;
                strokeChanged = false;
                Say("Sculpting " + Model.Kind(Model.I(Mathf.Clamp(Mathf.RoundToInt(p.x), 0, WorksModel.W - 1), Mathf.Clamp(Mathf.RoundToInt(p.z), 0, WorksModel.H - 1))) + " · release to commit the stroke");
            }
            else if (tool == Tool.Rock || tool == Tool.Remove)
            {
                var before = Model.Capture();
                bool changed = false;
                if (tool == Tool.Rock)
                    changed = Model.PlaceRock(Mathf.RoundToInt(p.x), Mathf.RoundToInt(p.z));
                else
                {
                    var s = PickSegment(p);
                    changed = s != null ? Model.Remove(s.Id) : Model.RemoveRock(Mathf.RoundToInt(p.x), Mathf.RoundToInt(p.z));
                }

                if (changed)
                {
                    Model.Commit(before);
                    Visit(p);
                    RefreshAll();
                }
                else
                    Say("Nothing changed: check budget, support, or permanent rocks.");
                owner = int.MinValue;
            }
        }

        DamSegment PickSegment(Vector3 p)
        {
            DamSegment best = null;
            foreach (var s in Model.Segments)
            {
                float along = s.AlongX ? p.x - s.X : p.z - s.Z, across = s.AlongX ? Mathf.Abs(p.z - s.Z) : Mathf.Abs(p.x - s.X);
                if (along >= -.3f && along <= s.Length + .3f && across < .7f && (best == null || s.Layer > best.Layer))
                    best = s;
            }

            return best;
        }

        DamSegment Candidate(Vector3 a, Vector3 b)
        {
            int ax = Mathf.RoundToInt(a.x), az = Mathf.RoundToInt(a.z), bx = Mathf.RoundToInt(b.x), bz = Mathf.RoundToInt(b.z);
            bool along = Mathf.Abs(b.x - a.x) >= Mathf.Abs(b.z - a.z);
            int length = along ? Mathf.Abs(bx - ax) : Mathf.Abs(bz - az);
            return new DamSegment
            {
                X = along ? Mathf.Min(ax, bx) : ax,
                Z = along ? az : Mathf.Min(az, bz),
                AlongX = along,
                Length = Mathf.Clamp(length, 0, 7),
                Material = selected
            };
        }

        // The owning pointer updates segment length or brush position; other fingers cannot steal it.
        public void PointerDrag(int id, Vector2 screen)
        {
            if (id != owner)
                return;
            if (tool == Tool.Camera)
            {
                Vector2 delta = screen - lastPointer;
                pan += new Vector3(delta.x, 0, -delta.y) * zoom / Mathf.Max(100, Screen.height);
                pan.x = Mathf.Clamp(pan.x, -7, 7);
                pan.z = Mathf.Clamp(pan.z, -8, 8);
                CameraUpdate();
            }
            else
            {
                Vector3 p;
                if (View.Pick(StageCamera, screen, out p))
                {
                    if (candidate != null)
                    {
                        candidate = Candidate(anchor, p);
                        beaverTarget = p;
                        Preview();
                    }
                    else
                    {
                        anchor = p;
                        beaverTarget = p;
                    }
                }
            }

            lastPointer = screen;
        }

        bool OverUI(Vector2 screen)
        {
            if (EventSystem.current == null)
                return false;
            var e = new PointerEventData(EventSystem.current)
            {
                position = screen
            };
            var hits = new List<RaycastResult>();
            EventSystem.current.RaycastAll(e, hits);
            foreach (var h in hits)
                return h.gameObject.GetComponent<WorksPointer>() == null;
            return false;
        }

        // Release commits a valid edit; release over UI cancels it. One gesture is one undo.
        public void PointerUp(int id, Vector2 screen)
        {
            if (id != owner)
                return;
            bool ui = OverUI(screen);
            if (candidate != null && !ui)
            {
                var before = Model.Capture();
                string why;
                if (Model.CanPlace(candidate, out why) && Model.Place(candidate))
                {
                    Model.Commit(before);
                    Visit(new Vector3(candidate.X + (candidate.AlongX ? candidate.Length * .5f : 0), 0, candidate.Z + (candidate.AlongX ? 0 : candidate.Length * .5f)));
                    Say("Placed " + candidate.Length + "-unit " + WorksModel.Materials[(int)candidate.Material].Name + " segment.");
                }
                else
                    Say(why);
            }

            if (brushing)
            {
                if (strokeChanged && !ui)
                {
                    Model.Commit(preStroke);
                    terrainTouched = true;
                    Visit(anchor);
                }
                else
                    Model.Restore(preStroke);
            }

            owner = int.MinValue;
            brushing = false;
            preStroke = null;
            candidate = null;
            ClearChildren(previewRoot);
            RefreshAll();
        }

        void Preview()
        {
            ClearChildren(previewRoot);
            string why;
            bool valid = Model.CanPlace(candidate, out why);
            float y = valid ? (float)Model.Bottom(candidate) + .5f : (float)Model.Sample(Mathf.Clamp(candidate.X, 0, 22), Mathf.Clamp(candidate.Z, 0, 34)) + .5f;
            var h = Primitive(previewRoot, PrimitiveType.Cube, new Vector3(candidate.X + (candidate.AlongX ? candidate.Length * .5f : 0), y, candidate.Z + (candidate.AlongX ? 0 : candidate.Length * .5f)), new Vector3(candidate.Length, .22f, .5f), valid ? new Color(.96f, .69f, .23f) : new Color(.85f, .22f, .15f));
            h.rotation = Quaternion.Euler(0, candidate.AlongX ? 0 : 90, 0);
            Say(candidate.Length + " units · cost " + candidate.Length * WorksModel.Materials[(int)selected].Cost + (valid ? " · release to place" : " · " + why));
        }

        void Cancel()
        {
            if (brushing && preStroke != null && Model != null)
                Model.Restore(preStroke);
            owner = int.MinValue;
            brushing = false;
            preStroke = null;
            candidate = null;
            if (previewRoot != null)
                ClearChildren(previewRoot);
        }

        void ChooseTool(Tool t)
        {
            if (replaying && t != Tool.Camera)
            {
                Say("Return LIVE and EDIT before building.");
                return;
            }

            Cancel();
            tool = t;
            RefreshAll();
            Say(t == Tool.Segment ? "Drag on terrain from one endpoint to the other." : "Selected " + t + ". Hold/drag terrain to sculpt; one stroke = one undo.");
        }

        void Undo()
        {
            if (running || replaying)
            {
                Say("Press EDIT before undoing your design.");
                return;
            }

            Cancel();
            if (Model.Undo())
            {
                tutorialUndoBase++;
                RefreshAll();
                Say("Restored the previous design action.");
            }
        }

        // Start a recorded trial, or restore the pre-trial design for the next edit.
        void ToggleTest()
        {
            if (replaying)
                ExitReplay();
            Cancel();
            livePaused = false;
            if (!running)
            {
                trialDesign = Model.Capture();
                Model.StartTrial();
                Model.Erosion = ErosionEnabled;
                replayTape.Begin(Model);
                RecordTrial(true);
                running = true;
                Say("Recording water test. PAUSE inspects; REPLAY reviews without rerunning.");
            }
            else
            {
                RecordTrial(true);
                running = false;
                if (trialDesign != null)
                    Model.Restore(trialDesign);
                Model.StartTrial();
                Say("Build restored. REPLAY still keeps the last test; TEST replaces its recording.");
            }

            accumulator = 0;
            RefreshAll();
            Actors();
        }

        void RefreshAll()
        {
            if (View == null)
                return;
            if (segmentsRoot != null)
            {
                ClearChildren(segmentsRoot);
                segmentVisuals.Clear();
                segmentRenderers.Clear();
            }

            View.PressureVisible = pressureVisible;
            View.ErosionVisible = erosionVisible;
            View.RefreshGround();
            View.RefreshWater();
            RefreshProps();
            RefreshSegments();
            View.BuildGrid(lineMaterial, gridVisible);
            RefreshMarkers();
            RefreshUI();
        }

        void Visit(Vector3 p)
        {
            p.x = Mathf.Clamp(p.x, 1, WorksModel.W - 2);
            p.z = Mathf.Clamp(p.z, 1, WorksModel.H - 2);
            if (beaverJobs.Count < 12)
                beaverJobs.Enqueue(p);
        }

        // Cosmetic NPC follows editing; it is not a pathfinding or physics-controlled character.
        void Buddy(float dt)
        {
            if (working > 0)
            {
                working -= dt;
                beaver.localScale = Vector3.one * (1 + .025f * Mathf.Sin(working * 18));
                return;
            }

            beaver.localScale = Vector3.one;
            if (new Vector2(beaver.position.x - beaverTarget.x, beaver.position.z - beaverTarget.z).sqrMagnitude < .12f && beaverJobs.Count > 0)
            {
                beaverTarget = beaverJobs.Dequeue();
                working = .6f;
            }

            Vector3 target = beaverTarget;
            target.y = BuddyHeight(target.x, target.z);
            Vector3 direction = target - beaver.position;
            Vector3 next = Vector3.MoveTowards(beaver.position, target, dt * 4);
            next.y = BuddyHeight(next.x, next.z);
            beaver.position = next;
            direction.y = 0;
            if (direction.sqrMagnitude > .02f)
                beaver.rotation = Quaternion.Slerp(beaver.rotation, Quaternion.LookRotation(direction), dt * 10);
        }

        float BuddyHeight(float x, float z)
        {
            float h = (float)Model.Sample(x, z) + .13f;
            foreach (var p in Model.Segments)
                if (!p.Broken)
                {
                    float along = p.AlongX ? x - p.X : z - p.Z, across = p.AlongX ? Mathf.Abs(z - p.Z) : Mathf.Abs(x - p.X);
                    if (along >= 0 && along <= p.Length && across < .65f)
                        h = Mathf.Max(h, (float)Model.Top(p) + .1f);
                }

            return h;
        }

        void Actors()
        {
            animal.gameObject.SetActive((running || replaying) && Model.AnimalActive);
            if (Model.AnimalActive)
            {
                double y = Model.WalkHeight(Model.AnimalX, Model.Rule.CrossRow);
                if (!double.IsNaN(y))
                    animal.position = new Vector3((float)Model.AnimalX, (float)y + .1f, Model.Rule.CrossRow);
                animal.rotation = Quaternion.Euler(0, 90, 0);
            }

            while (fishVisuals.Count < Model.Fish.Count)
                fishVisuals.Add(Spawn(FishPrefab, "Fish parcel", root));
            for (int i = 0; i < fishVisuals.Count; i++)
            {
                bool active = (running || replaying) && i < Model.Fish.Count && !Model.Fish[i].Finished;
                fishVisuals[i].gameObject.SetActive(active);
                if (!active)
                    continue;
                var f = Model.Fish[i];
                fishVisuals[i].position = new Vector3(f.X + .5f, (float)(Model.Bed(f.X, f.Z) + Model.Depth[Model.I(f.X, f.Z)]) + .08f, f.Z + .5f);
                var d = new Vector3((float)Model.VX[Model.I(f.X, f.Z)], 0, (float)Model.VZ[Model.I(f.X, f.Z)]);
                if (d.sqrMagnitude > .0001f)
                    fishVisuals[i].rotation = Quaternion.LookRotation(d);
            }
        }

        // Unity calls this each frame. Accumulate fixed model steps and refresh graphics at a lower rate.
        void Update()
        {
            if (Model == null)
                return;
            float dt = Mathf.Min(Time.deltaTime, .08f);
            if (!replaying && !livePaused)
                Buddy(dt);
            UpdateReplay(dt);
#if ENABLE_INPUT_SYSTEM
            var k=Keyboard.current;if(k!=null){if(k.zKey.wasPressedThisFrame)Undo();if(k.spaceKey.wasPressedThisFrame)ToggleTest();if(k.gKey.wasPressedThisFrame)ToggleGrid();if(k.escapeKey.wasPressedThisFrame){Cancel();RefreshAll();}}
            if(Mouse.current!=null&&Mathf.Abs(Mouse.current.scroll.ReadValue().y)>0){zoom=Mathf.Clamp(zoom-Mouse.current.scroll.ReadValue().y*.012f,11,25);CameraUpdate();}
#endif
            if (brushing && !running && !replaying)
            {
                if (Model.Brush(anchor.x, anchor.z, tool == Tool.Mud, dt) > 0)
                    strokeChanged = true;
                groundTimer += dt;
                if (groundTimer > .12f)
                {
                    groundTimer = 0;
                    View.RefreshGround();
                    RefreshProps();
                    View.BuildGrid(lineMaterial, gridVisible);
                }
            }

            if (running && !replaying && !livePaused && !Model.Won && !Model.Ended)
            {
                accumulator += dt * TestSpeed;
                int n = 0;
                while (accumulator >= WorksModel.Dt && n++ < 18)
                {
                    Model.Tick();
                    RecordTrial();
                    accumulator -= (float)WorksModel.Dt;
                    if (Model.Won || Model.Ended)
                    {
                        RecordTrial(true);
                        break;
                    }
                }

                if (n >= 18)
                    accumulator = 0;
            }

            visualTimer += dt;
            if (visualTimer > .12f)
            {
                visualTimer = 0;
                if (!replaying)
                {
                    View.RefreshWater();
                    RefreshSegments();
                    if (running && Model.Erosion)
                    {
                        View.RefreshGround();
                        RefreshProps();
                    }

                    Actors();
                    RefreshMarkers();
                }

                RefreshUI();
            }

            if (noticeTimer > 0)
            {
                noticeTimer -= dt;
                if (noticeTimer <= 0)
                    message.text = "";
            }

            SafeArea();
        }

        void CameraUpdate()
        {
            if (StageCamera == null)
                return;
            Vector3 target = new Vector3(11.5f, 0, 18) + pan;
            StageCamera.transform.position = target + new Vector3(0, 31, 27);
            StageCamera.transform.LookAt(target);
            StageCamera.orthographicSize = zoom;
        }

        bool TutorialReady()
        {
            if (owner != int.MinValue || replaying)
                return false;
            switch (tutorialStep)
            {
                case 0:
                    return gridTouched;
                case 1:
                    return Model.Segments.Exists(p => p.X == 12 && p.Z == 23 && p.Length == 3 && p.Material == DamMaterial.Timber);
                case 2:
                    return Model.Segments.Exists(p => p.X == 9 && p.Z == 23 && p.Length == 3 && p.Material == DamMaterial.Timber);
                case 3:
                    return tutorialUndoBase > 0 && Model.Segments.Exists(p => p.X == 9 && p.Z == 23 && p.Length == 3) && Model.Segments.Exists(p => p.X == 12 && p.Z == 23 && p.Length == 3);
                case 4:
                    return terrainTouched;
                case 5:
                    return Model.Won;
                default:
                    return true;
            }
        }

        void Advance()
        {
            if (replaying)
            {
                Say("Return LIVE before advancing levels.");
                return;
            }

            if (Model.Level == 0 && tutorialStep < 6)
            {
                if (TutorialReady())
                {
                    tutorialStep++;
                    tool = Tool.Segment;
                    selected = DamMaterial.Timber;
                    RefreshUI();
                }
            }
            else if (!running || Model.Won || Model.Ended)
                LoadLevel((Model.Level + 1) % 4);
        }

        void ToggleGrid()
        {
            gridVisible = !gridVisible;
            gridTouched = true;
            View.GridRoot.gameObject.SetActive(gridVisible);
            RefreshUI();
        }

        void Say(string text)
        {
            if (message != null)
                message.text = text;
            noticeTimer = 4;
        }

        void RefreshUI()
        {
            if (Model == null || title == null)
                return;
            title.text = "BEAVER WORKS / " + Model.Rule.Name;
            guide.text = Model.Level == 0 ? tutorial[Mathf.Min(tutorialStep, 6)] : Model.Rule.Brief;
            stats.text = "BUDGET " + Model.Budget + "    POND " + Model.PondDepth.ToString("F2") + " / " + Model.Rule.PondGoal.ToString("F2") + "    ANIMALS " + Model.AnimalsPassed + " / " + Model.Rule.AnimalCount + "\nFISH NURSERY " + Model.FishCorrect + " / " + Model.Rule.FishGoal + "    WRONG " + Model.FishWrong + " / " + (Model.Level == 3 ? 3 : 0) + "    LOAD " + Model.MaxLoad.ToString("P0") + "    BROKEN " + Model.BrokenCount + "    " + Model.Time.ToString("F0") + " s";
            var r = WorksModel.Materials[(int)selected];
            materialInfo.text = r.Name + " · " + r.Cost + " budget/unit · height " + r.Height.ToString("F2") + " · leak " + r.Leak.ToString("P0") + " · " + (r.Walkable ? "walkable" : "not walkable") + "\n" + (Model.Won ? "HABITAT COMPLETE" : Model.Ended ? "TEST ENDED — " + Model.Failure : running ? "SIMULATING — EDIT restores the design" : "BUILD — drag 1–6 units; grid display is optional");
            nextButton.interactable = Model.Level == 0 ? TutorialReady() : !running || Model.Won || Model.Ended;
            nextButton.GetComponentInChildren<Text>().text = Model.Level == 0 && tutorialStep < 6 ? "NEXT STEP" : "NEXT LEVEL";
            testButton.GetComponentInChildren<Text>().text = running ? "EDIT / RESET" : "TEST WATER";
            gridButton.GetComponentInChildren<Text>().text = gridVisible ? "GRID ON" : "GRID OFF";
            stressButton.GetComponentInChildren<Text>().text = stressVisible ? "LOAD ON" : "LOAD OFF";
            RefreshDiagnosticUI();
        }

        RectTransform Panel(string label, Transform parent, Vector2 min, Vector2 max, Vector2 pos, Vector2 size, Color color, bool raycast)
        {
            var go = new GameObject(label, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = min;
            rt.anchorMax = max;
            rt.pivot = new Vector2(.5f, .5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            go.GetComponent<Image>().color = color;
            go.GetComponent<Image>().raycastTarget = raycast;
            return rt;
        }

        Text Label(string text, Transform parent, Vector2 min, Vector2 max, Vector2 pos, Vector2 size, int fontSize, TextAnchor align)
        {
            var go = new GameObject("Text", typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = min;
            rt.anchorMax = max;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            var t = go.GetComponent<Text>();
            t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            t.fontSize = fontSize;
            t.text = text;
            t.color = new Color(.92f, .92f, .82f);
            t.alignment = align;
            t.raycastTarget = false;
            return t;
        }

        Button Button(string label, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Action action)
        {
            var rt = Panel(label, parent, anchor, anchor, pos, size, new Color(.24f, .36f, .29f), true);
            var b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = rt.GetComponent<Image>();
            b.onClick.AddListener(() => action());
            Label(label, rt, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, 16, TextAnchor.MiddleCenter);
            return b;
        }

        // Create the runtime buttons, labels and gesture surface. Documentation files are not UI assets.
        void BuildUI()
        {
            var go = new GameObject("Overseer interface", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            go.transform.SetParent(transform, false);
            canvas = go.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var sc = go.GetComponent<CanvasScaler>();
            sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            sc.referenceResolution = new Vector2(1280, 800);
            sc.matchWidthOrHeight = 0;
            safe = new GameObject("Safe area", typeof(RectTransform)).GetComponent<RectTransform>();
            safe.SetParent(go.transform, false);
            safe.offsetMin = safe.offsetMax = Vector2.zero;
            var hit = Panel("World gesture surface", safe, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0, 0, 0, 0), true);
            hit.gameObject.AddComponent<WorksPointer>().Game = this;
            var top = Panel("Field notebook", safe, new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, -96), new Vector2(-24, 180), new Color(.10f, .20f, .16f, .97f), true);
            title = Label("BEAVER WORKS", top, Vector2.zero, Vector2.one, new Vector2(0, 62), new Vector2(-30, -145), 24, TextAnchor.MiddleLeft);
            guide = Label("", top, Vector2.zero, Vector2.one, new Vector2(0, 17), new Vector2(-30, -125), 18, TextAnchor.MiddleLeft);
            stats = Label("", top, Vector2.zero, Vector2.one, new Vector2(0, -45), new Vector2(-30, -120), 16, TextAnchor.MiddleLeft);
            var bottom = Panel("Construction shelf", safe, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 82), new Vector2(-24, 150), new Color(.10f, .20f, .16f, .97f), true);
            for (int i = 0; i < 5; i++)
            {
                int j = i;
                Button(new[] { "BRUSH", "TIMBER", "MUD CORE", "STONE", "FISH PASS" }[i], bottom, new Vector2(0, 1), new Vector2(83 + i * 130, -25), new Vector2(120, 38), () =>
                {
                    selected = (DamMaterial)j;
                    ChooseTool(Tool.Segment);
                });
            }

            Button("DIG", bottom, new Vector2(0, 1), new Vector2(737, -25), new Vector2(84, 38), () => ChooseTool(Tool.Dig));
            Button("ADD MUD", bottom, new Vector2(0, 1), new Vector2(841, -25), new Vector2(104, 38), () => ChooseTool(Tool.Mud));
            Button("ROCK", bottom, new Vector2(0, 1), new Vector2(953, -25), new Vector2(100, 38), () => ChooseTool(Tool.Rock));
            Button("REMOVE", bottom, new Vector2(0, 1), new Vector2(1070, -25), new Vector2(112, 38), () => ChooseTool(Tool.Remove));
            Button("UNDO / Z", bottom, new Vector2(0, 1), new Vector2(81, -76), new Vector2(116, 40), Undo);
            testButton = Button("TEST WATER", bottom, new Vector2(0, 1), new Vector2(226, -76), new Vector2(158, 40), ToggleTest);
            gridButton = Button("GRID ON", bottom, new Vector2(0, 1), new Vector2(373, -76), new Vector2(116, 40), ToggleGrid);
            stressButton = Button("LOAD OFF", bottom, new Vector2(0, 1), new Vector2(501, -76), new Vector2(116, 40), () =>
            {
                stressVisible = !stressVisible;
                RefreshSegments();
                RefreshUI();
            });
            Button("CAMERA", bottom, new Vector2(0, 1), new Vector2(629, -76), new Vector2(116, 40), () => ChooseTool(Tool.Camera));
            Button("−", bottom, new Vector2(0, 1), new Vector2(722, -76), new Vector2(48, 40), () =>
            {
                zoom = Mathf.Clamp(zoom + 1, 11, 25);
                CameraUpdate();
            });
            Button("+", bottom, new Vector2(0, 1), new Vector2(780, -76), new Vector2(48, 40), () =>
            {
                zoom = Mathf.Clamp(zoom - 1, 11, 25);
                CameraUpdate();
            });
            nextButton = Button("NEXT STEP", bottom, new Vector2(0, 1), new Vector2(907, -76), new Vector2(168, 40), Advance);
            Button("CLEAR", bottom, new Vector2(0, 1), new Vector2(1078, -76), new Vector2(146, 40), () => LoadLevel(Model.Level));
            materialInfo = Label("", bottom, Vector2.zero, Vector2.one, new Vector2(0, -54), new Vector2(-30, -102), 14, TextAnchor.MiddleLeft);
            message = Label("", safe, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 181), new Vector2(-40, 32), 17, TextAnchor.MiddleCenter);
            for (int i = 0; i < 4; i++)
            {
                int j = i;
                Button(i == 0 ? "TUTORIAL" : "LEVEL " + i, safe, new Vector2(1, .5f), new Vector2(-63, 83 - i * 44), new Vector2(116, 36), () => LoadLevel(j));
            }

            Button("EROSION", safe, new Vector2(1, .5f), new Vector2(-63, -109), new Vector2(116, 36), () =>
            {
                if (running || replaying)
                {
                    Say("EDIT first to change physics; WEAR only changes display.");
                    return;
                }

                ErosionEnabled = !ErosionEnabled;
                Model.Erosion = ErosionEnabled;
                Say("Erosion physics " + (ErosionEnabled ? "ON" : "OFF"));
            });
            Button("SPEED", safe, new Vector2(1, .5f), new Vector2(-63, -153), new Vector2(116, 36), () =>
            {
                if (replaying)
                {
                    playbackSpeed = playbackSpeed == .25f ? .5f : playbackSpeed == .5f ? 1 : playbackSpeed == 1 ? 3 : .25f;
                    Say("Replay speed " + playbackSpeed + "x");
                }
                else
                {
                    TestSpeed = TestSpeed == 1 ? 3 : TestSpeed == 3 ? 6 : 1;
                    Say("Simulation speed " + TestSpeed + "x");
                }
            });
            Button("EXAMPLE", safe, new Vector2(1, .5f), new Vector2(-63, -197), new Vector2(116, 36), () =>
            {
                if (running || replaying)
                {
                    Say("Press LIVE then EDIT first.");
                    return;
                }

                Cancel();
                var before = Model.Capture();
                Model.ClearDesign(false);
                Model.ExampleDesign();
                Model.Commit(before);
                RefreshAll();
                Say("Example design loaded; undo restores the old design. This is a teaching aid.");
            });
            if (EventSystem.current == null)
            {
                var es = new GameObject("Event System", typeof(EventSystem));
                es.transform.SetParent(transform, false);
#if ENABLE_INPUT_SYSTEM
                var module=es.AddComponent<InputSystemUIInputModule>();module.AssignDefaultActions();
#else
                es.AddComponent<StandaloneInputModule>();
#endif
            }

            BuildDiagnosticUI();
            SafeArea();
        }

        void SafeArea()
        {
            if (safe == null || Screen.width == 0 || Screen.height == 0)
                return;
            Rect r = Screen.safeArea;
            safe.anchorMin = new Vector2(r.x / Screen.width, r.y / Screen.height);
            safe.anchorMax = new Vector2(r.xMax / Screen.width, r.yMax / Screen.height);
            safe.offsetMin = safe.offsetMax = Vector2.zero;
        }

        void Suspend()
        {
            if (Model == null)
                return;
            Cancel();
            livePaused = running;
            replayPlaying = false;
            accumulator = 0;
            RefreshAll();
            Say("Paused safely; recording and live trial retained.");
        }

        void OnApplicationFocus(bool f)
        {
            if (!f)
                Suspend();
        }

        void OnApplicationPause(bool p)
        {
            if (p)
                Suspend();
        }

        void OnDestroy()
        {
            foreach (var m in materials)
                if (m != null)
                    Destroy(m);
        }

        // REPLAY AND DIAGNOSTICS: formerly WorksDiagnostics.cs, now one attachable script.
        WorksReplay replayTape = new WorksReplay();
        WorksModel retainedLive;
        bool replaying, replayPlaying, replayWasRunning, livePaused;
        double replayTime;
        float playbackSpeed = .5f;
        Vector3 retainedBuddyPosition;
        Quaternion retainedBuddyRotation;
        int shownFrame = -1;
        bool pressureVisible, erosionVisible;
        int inspectX = 11, inspectZ = 16;
        Text replayClock, legend, inspector;
        Button replayButton, pauseButton, pressureButton, wearButton;
        Slider replaySlider;
        public bool Replaying
        {
            get
            {
                return replaying;
            }
        }

        void RecordTrial(bool force = false)
        {
            if (!replaying && Model != null && replayTape != null && beaver != null)
                replayTape.Record(Model, beaver.position.x, beaver.position.y, beaver.position.z, beaver.eulerAngles.y, force);
        }

        void ResetReplayForLevel()
        {
            replaying = replayPlaying = livePaused = false;
            retainedLive = null;
            shownFrame = -1;
            replayTime = 0;
            replayTape = new WorksReplay();
        }

        // Use a separate model for playback; retain the live trial untouched.
        void EnterReplay()
        {
            if (replaying)
            {
                ExitReplay();
                return;
            }

            if (replayTape.Count < 2)
            {
                Say("Run TEST first; a replay needs two recorded frames.");
                return;
            }

            Cancel();
            retainedLive = Model;
            replayWasRunning = running;
            retainedBuddyPosition = beaver.position;
            retainedBuddyRotation = beaver.rotation;
            ClearChildren(segmentsRoot);
            segmentVisuals.Clear();
            segmentRenderers.Clear();
            Model = replayTape.CreateViewer();
            View.Model = Model;
            replaying = true;
            replayPlaying = false;
            replayTime = 0;
            shownFrame = -1;
            beaverJobs.Clear();
            working = 0;
            accumulator = 0;
            ShowReplay(true);
            Say("REPLAY is read-only. Scrub or play; LIVE returns to your unchanged trial/design.");
        }

        void ExitReplay()
        {
            if (!replaying)
                return;
            ClearChildren(segmentsRoot);
            segmentVisuals.Clear();
            segmentRenderers.Clear();
            Model = retainedLive;
            View.Model = Model;
            retainedLive = null;
            replaying = replayPlaying = false;
            running = replayWasRunning;
            livePaused = running;
            shownFrame = -1;
            if (beaver != null)
            {
                beaver.position = retainedBuddyPosition;
                beaver.rotation = retainedBuddyRotation;
                beaverTarget = beaver.position;
                beaverJobs.Clear();
                working = 0;
            }

            RefreshAll();
            Actors();
            Say(running ? "Live test restored, PAUSED. RESUME continues it." : "Your build is unchanged. TEST starts a new recording.");
        }

        void TogglePause()
        {
            if (replaying)
            {
                if (replayTime >= replayTape.Duration)
                    replayTime = 0;
                replayPlaying = !replayPlaying;
                ShowReplay(true);
            }
            else if (running && !Model.Won && !Model.Ended)
            {
                livePaused = !livePaused;
                accumulator = 0;
            }
            else
                Say("Start TEST or open REPLAY first.");
            RefreshDiagnosticUI();
        }

        void SeekReplay(double time)
        {
            if (replayTape.Count < 2)
                return;
            if (!replaying)
                EnterReplay();
            if (!replaying)
                return;
            replayPlaying = false;
            replayTime = Math.Max(0, Math.Min(replayTape.Duration, time));
            ShowReplay(true);
        }

        void JumpEvent(bool next)
        {
            if (replayTape.Count < 2)
                return;
            if (!replaying)
                EnterReplay();
            SeekReplay(replayTape.EventTime(replayTime, next));
        }

        // Apply the recorded frame to the viewer. Never call Tick here.
        void ShowReplay(bool force = false)
        {
            if (!replaying)
                return;
            int index = replayTape.IndexAt(replayTime);
            if (index < 0 || (!force && index == shownFrame))
                return;
            ReplayFrame frame = replayTape.Seek(Model, replayTime);
            shownFrame = index;
            if (beaver != null)
            {
                beaver.position = new Vector3(frame.BuddyX, frame.BuddyY, frame.BuddyZ);
                beaver.rotation = Quaternion.Euler(0, frame.BuddyYaw, 0);
                beaver.localScale = Vector3.one;
            }

            View.PressureVisible = pressureVisible;
            View.ErosionVisible = erosionVisible;
            View.RefreshGround();
            View.RefreshWater();
            RefreshProps();
            RefreshSegments();
            RefreshMarkers();
            Actors();
            if (gridVisible)
                View.BuildGrid(lineMaterial, true);
            RefreshUI();
        }

        void UpdateReplay(float dt)
        {
            if (replaying && replayPlaying)
            {
                replayTime = Math.Min(replayTape.Duration, replayTime + dt * playbackSpeed);
                if (replayTime >= replayTape.Duration)
                    replayPlaying = false;
                ShowReplay();
            }
        }

        void TogglePressure()
        {
            pressureVisible = !pressureVisible;
            ApplyDiagnosticViews();
        }

        void ToggleWear()
        {
            erosionVisible = !erosionVisible;
            ApplyDiagnosticViews();
        }

        void ApplyDiagnosticViews()
        {
            if (View == null)
                return;
            View.PressureVisible = pressureVisible;
            View.ErosionVisible = erosionVisible;
            View.RefreshGround();
            View.RefreshWater();
            RefreshSegments();
            RefreshDiagnosticUI();
        }

        void InspectAt(Vector3 point)
        {
            inspectX = Mathf.Clamp(Mathf.RoundToInt(point.x), 0, WorksModel.W - 1);
            inspectZ = Mathf.Clamp(Mathf.RoundToInt(point.z), 0, WorksModel.H - 1);
            RefreshDiagnosticUI();
        }

        void RefreshDiagnosticUI()
        {
            if (Model == null || replayClock == null)
                return;
            replayButton.interactable = replayTape.Count >= 2;
            replayButton.GetComponentInChildren<Text>().text = replaying ? "LIVE" : "REPLAY";
            pauseButton.interactable = replaying || (running && !Model.Won && !Model.Ended);
            pauseButton.GetComponentInChildren<Text>().text = replaying ? (replayPlaying ? "PAUSE" : "PLAY") : (livePaused ? "RESUME" : "PAUSE");
            pressureButton.GetComponentInChildren<Text>().text = pressureVisible ? "PRESSURE ON" : "PRESSURE OFF";
            wearButton.GetComponentInChildren<Text>().text = erosionVisible ? "WEAR ON" : "WEAR OFF";
            replaySlider.interactable = replayTape.Count >= 2;
            replaySlider.SetValueWithoutNotify((float)(replayTape.Duration > 0 ? (replaying ? replayTime : replayTape.Duration) / replayTape.Duration : 0));
            string mode = replaying ? "REPLAY " : running ? (livePaused ? "PAUSED " : "LIVE ") : "BUILD ";
            replayClock.text = mode + (replaying ? replayTime : Model.Time).ToString("F2") + " / " + replayTape.Duration.ToString("F2") + " s  · " + replayTape.Count + " frames" + (replaying ? " · " + playbackSpeed + "x" : "");
            legend.text = "PRESSURE: bed gauge 0 blue → 30+ kPa red  |  WEAR: 0 → .01+ m/s amber; ticks = loss  |  LOAD: 0–100% green→red; broken dark\n" + (replaying ? replayTape.EventLabel(replayTime) : "Peak pressure " + replayTape.PeakPressure.ToString("F1") + " kPa · peak load " + replayTape.PeakLoad.ToString("P0")) + (replayTape.Full ? " · RECORDING CAPPED" : "");
            int i = Model.I(inspectX, inspectZ);
            double speed = Math.Sqrt(Model.VX[i] * Model.VX[i] + Model.VZ[i] * Model.VZ[i]);
            string info = "CELL " + inspectX + ", " + inspectZ + " · " + Model.Kind(i) + "\nDepth " + Model.Depth[i].ToString("F2") + " m · p " + (9.81 * Model.Depth[i]).ToString("F1") + " kPa\nSpeed~ " + speed.ToString("F2") + " m/s\nWear " + Model.ErosionRate[i].ToString("F4") + " m/s\nLoss " + Model.ErosionLoss[i].ToString("F3") + " m";
            var s = PickSegment(new Vector3(inspectX, 0, inspectZ));
            if (s != null)
                info += "\nSEG #" + s.Id + " · " + s.Ratio.ToString("P0") + " load\nWater~ " + s.WaterDemand.ToString("F1") + " + animal~ " + s.AnimalDemand.ToString("F1") + "\nCapacity~ " + s.EstimatedCapacity.ToString("F1") + " · damage " + s.Damage.ToString("P0");
            else
                info += "\nTap dam to inspect demand.\nReplay never changes design.";
            inspector.text = info;
        }

        void BuildDiagnosticUI()
        {
            var strip = Panel("Diagnostic switches", safe, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 288), new Vector2(-24, 62), new Color(.10f, .20f, .16f, .97f), true);
            pressureButton = Button("PRESSURE OFF", strip, new Vector2(0, .5f), new Vector2(97, 0), new Vector2(170, 42), TogglePressure);
            wearButton = Button("WEAR OFF", strip, new Vector2(0, .5f), new Vector2(275, 0), new Vector2(166, 42), ToggleWear);
            legend = Label("", strip, new Vector2(0, 0), new Vector2(1, 1), new Vector2(182, 0), new Vector2(-396, -8), 12, TextAnchor.MiddleLeft);
            var bar = Panel("Stress replay controls", safe, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 227), new Vector2(-24, 62), new Color(.10f, .20f, .16f, .97f), true);
            replayButton = Button("REPLAY", bar, new Vector2(0, .5f), new Vector2(65, 0), new Vector2(104, 42), EnterReplay);
            pauseButton = Button("PAUSE", bar, new Vector2(0, .5f), new Vector2(174, 0), new Vector2(100, 42), TogglePause);
            Button("START", bar, new Vector2(0, .5f), new Vector2(281, 0), new Vector2(100, 42), () => SeekReplay(0));
            Button("PREV", bar, new Vector2(0, .5f), new Vector2(388, 0), new Vector2(100, 42), () => JumpEvent(false));
            Button("NEXT", bar, new Vector2(0, .5f), new Vector2(495, 0), new Vector2(100, 42), () => JumpEvent(true));
            Button("WARNING", bar, new Vector2(0, .5f), new Vector2(612, 0), new Vector2(120, 42), () => SeekReplay(replayTape.FirstWarning));
            replayClock = Label("", bar, new Vector2(1, .5f), new Vector2(1, .5f), new Vector2(-183, 19), new Vector2(345, 22), 13, TextAnchor.MiddleCenter);
            var sliderRect = Panel("Replay timeline", bar, new Vector2(1, .5f), new Vector2(1, .5f), new Vector2(-182, -13), new Vector2(340, 22), new Color(.34f, .44f, .37f), true);
            replaySlider = sliderRect.gameObject.AddComponent<Slider>();
            replaySlider.minValue = 0;
            replaySlider.maxValue = 1;
            var handle = Panel("Timeline handle", sliderRect, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(16, 0), new Color(.96f, .72f, .28f), true);
            replaySlider.handleRect = handle;
            replaySlider.targetGraphic = handle.GetComponent<Image>();
            replaySlider.direction = Slider.Direction.LeftToRight;
            replaySlider.onValueChanged.AddListener(value => SeekReplay(value * replayTape.Duration));
            var box = Panel("Cell and segment inspector", safe, new Vector2(0, .5f), new Vector2(0, .5f), new Vector2(123, 0), new Vector2(222, 182), new Color(.10f, .20f, .16f, .93f), true);
            inspector = Label("Tap terrain or dam", box, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(-16, -10), 13, TextAnchor.MiddleLeft);
        }
    }
}
