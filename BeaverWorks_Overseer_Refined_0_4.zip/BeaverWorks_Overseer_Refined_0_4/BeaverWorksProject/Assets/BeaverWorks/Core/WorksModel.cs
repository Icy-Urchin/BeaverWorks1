// Original educational prototype, not engineering or ecological prediction.
// Unity-independent model: one unit cell area, fixed timesteps, deterministic trials.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public enum DamMaterial
    {
        Brushwood,
        Timber,
        PackedMud,
        Stone,
        FishPass
    }

    public enum Soil
    {
        Topsoil,
        Dirt,
        LooseMud,
        SandGravel,
        Clay,
        Bedrock
    }

    public sealed class MaterialRule
    {
        public string Name;
        public int Cost;
        public double Height, Leak, Capacity, Mass;
        public bool Walkable, Fish;
        public MaterialRule(string n, int c, double h, double leak, double cap, double mass, bool walk, bool fish = false)
        {
            Name = n;
            Cost = c;
            Height = h;
            Leak = leak;
            Capacity = cap;
            Mass = mass;
            Walkable = walk;
            Fish = fish;
        }
    }

    public sealed class DamSegment
    {
        public int Id, X, Z, Length, Layer;
        public bool AlongX = true;
        public DamMaterial Material;
        public double Foundation, Damage, Ratio, WaterDemand, AnimalDemand, EstimatedCapacity;
        public bool Broken;
        public DamSegment Copy()
        {
            return (DamSegment)MemberwiseClone();
        }
    }

    public sealed class FishParcel
    {
        public int X, Z;
        public bool Finished;
        public double Wait;
    }

    public sealed class DesignState
    {
        internal double[] Ground, Fill;
        internal bool[] Rocks;
        internal List<DamSegment> Segments;
        internal int Budget, NextId;
        internal double Mud;
    }

    public sealed class LevelRule
    {
        public string Name, Brief;
        public int Budget, AnimalCount, FishGoal, CrossRow;
        public double PondGoal, Duration, Source, AnimalMass;
        public bool Fork, Surge;
        public LevelRule(string name, string brief, int budget, int animals, int fish, int row, double pond, double source, double mass, bool fork = false, bool surge = false)
        {
            Name = name;
            Brief = brief;
            Budget = budget;
            AnimalCount = animals;
            FishGoal = fish;
            CrossRow = row;
            PondGoal = pond;
            Source = source;
            AnimalMass = mass;
            Fork = fork;
            Surge = surge;
            Duration = surge ? 360 : 190;
        }
    }

    public sealed class WorksModel
    {
        public const int W = 24, H = 36;
        public const double Dt = 1.0 / 30;
        static readonly int[] fishDX =
        {
            -1,
            1,
            0,
            0
        }, fishDZ =
        {
            0,
            0,
            -1,
            1
        };
        readonly double[] fishFlows = new double[4];
        static readonly double[] digResistance =
        {
            1.0,
            1.5,
            1.1,
            1.3,
            3.0,
            999.0
        }, wearThreshold =
        {
            2.0,
            4.0,
            1.2,
            .7,
            12.0,
            double.MaxValue
        }, wearRate =
        {
            .00010,
            .00007,
            .00014,
            .00018,
            .000025,
            0.0
        };
        public static readonly MaterialRule[] Materials =
        {
            new MaterialRule("Brushwood", 1, .75, .075, 3.2, .045, false),
            new MaterialRule("Timber", 3, .90, .012, 16, .12, true),
            new MaterialRule("Packed mud", 2, .80, .003, 6, .35, false),
            new MaterialRule("Stone core", 5, 1.05, .008, 34, .7, true),
            new MaterialRule("Fish-pass weave", 4, .60, .65, 10, .09, true, true)
        };
        public static readonly LevelRule[] Levels =
        {
            new LevelRule("Tutorial · First pond", "Draw two 3-unit TIMBER segments across the gold line. Test water; one rabbit crosses the dry crest.", 90, 1, 0, 23, .35, 3.0, .015),
            new LevelRule("1 · Woodland crossing", "Make a pond and a continuous dry dam crest for two rabbits. Keep long segments short or supported.", 66, 2, 0, 23, .45, 3.4, .025),
            new LevelRule("2 · Nursery fork", "Block the main drain at the gold line; send at least four fish into the marked nursery outlet (screen-left). A rabbit also needs a dry crossing.", 100, 1, 4, 20, .35, 3.6, .025, true),
            new LevelRule("3 · Spring surge", "Route four fish to the marked nursery (maximum three wrong exits) and carry three heavier deer through a spring-flow pulse. Stone and bank reinforcement help resist load and scour.", 138, 3, 4, 20, .45, 4.2, .18, true, true)
        };
        public readonly int Level;
        public LevelRule Rule
        {
            get
            {
                return Levels[Level];
            }
        }

        public double[] Ground = new double[W * H], Fill = new double[W * H], Original = new double[W * H], Bedrock = new double[W * H], Depth = new double[W * H];
        public readonly bool[] Rocks = new bool[W * H], Permanent = new bool[W * H];
        public readonly List<DamSegment> Segments = new List<DamSegment>();
        public readonly List<FishParcel> Fish = new List<FishParcel>();
        public readonly Stack<DesignState> History = new Stack<DesignState>();
        // Signed volume rates in cubic game metres per second, not velocity.
        public readonly double[] QX = new double[(W - 1) * H], QZ = new double[W * (H - 1)], VX = new double[W * H], VZ = new double[W * H];
        public readonly double[] ErosionRate = new double[W * H], ErosionLoss = new double[W * H];
        readonly double[] outScale = new double[W * H], delta = new double[W * H];
        readonly double[] crestX = new double[(W - 1) * H], crestZ = new double[W * (H - 1)], leakX = new double[(W - 1) * H], leakZ = new double[W * (H - 1)];
        readonly bool[] passX = new bool[(W - 1) * H], passZ = new bool[W * (H - 1)];
        int nextId = 1;
        uint rng = 7281;
        double nextFish = 14, animalNext = 72;
        public int Budget;
        public double MudSupply = 40, Time, Added, Drained, Initial, Eroded, GoalHold, AnimalX = 8;
        public int FishCorrect, FishWrong, AnimalsPassed, AnimalsFailed;
        public bool AnimalActive, Won, Ended;
        public bool Erosion = true;
        public string Failure = "";
        // Build one of four sample heightfield levels. Original is the unedited baseline.
        public WorksModel(int level)
        {
            Level = Math.Max(0, Math.Min(3, level));
            Budget = Rule.Budget;
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, z);
                    double slope = (H - 1 - z) * .018;
                    bool main = x >= 9 && x <= 14;
                    bool fork = Rule.Fork && ((x >= 15 && x <= 20 && z >= 12 && z <= 18) || (x >= 18 && x <= 20 && z >= 12));
                    Ground[i] = (main || fork ? slope : 1.65 + slope);
                    Original[i] = Ground[i];
                    Bedrock[i] = Ground[i] - 1.45;
                }

            // In the fork levels, a divider stops fish shortcuts below the junction.
            if (Rule.Fork)
                for (int z = 19; z < H; z++)
                    for (int x = 15; x < 18; x++)
                        Ground[I(x, z)] = Original[I(x, z)] = 1.8 + (H - 1 - z) * .018;
            // Natural boulders on banks are simulation obstacles as well as visual scenery.
            foreach (int i in new[]
            {
                I(7, 15),
                I(16, 25),
                I(6, 29)
            }

            )
            {
                Rocks[i] = Permanent[i] = true;
            }

            SyncEdges();
        }

        public int I(int x, int z)
        {
            return z * W + x;
        }

        public bool Inside(int x, int z)
        {
            return x >= 0 && x < W && z >= 0 && z < H;
        }

        public double Bed(int x, int z)
        {
            int i = I(x, z);
            return Ground[i] + Fill[i] + (Rocks[i] ? 1.15 : 0);
        }

        // Read the height on the same two triangles used by the visible terrain.
        public double Sample(double x, double z)
        {
            x = Math.Max(0, Math.Min(W - 1.001, x));
            z = Math.Max(0, Math.Min(H - 1.001, z));
            int a = (int)x, b = (int)z;
            double u = x - a, v = z - b;
            // Same two triangles as the visible heightfield, not bilinear mismatch.
            double h00 = Bed(a, b), h10 = Bed(a + 1, b), h01 = Bed(a, b + 1), h11 = Bed(a + 1, b + 1);
            return u + v <= 1 ? h00 + u * (h10 - h00) + v * (h01 - h00) : h11 + (1 - u) * (h01 - h11) + (1 - v) * (h10 - h11);
        }

        public Soil Kind(int i)
        {
            if (Fill[i] > .015)
                return Soil.LooseMud;
            double d = Original[i] - Ground[i];
            return d < .20 ? Soil.Topsoil : d < .48 ? Soil.Dirt : d < .73 ? Soil.LooseMud : d < 1.03 ? Soil.SandGravel : d < 1.44 ? Soil.Clay : Soil.Bedrock;
        }

        // Copy the construction state before an edit, so Undo can restore it.
        public DesignState Capture()
        {
            var s = new DesignState
            {
                Ground = (double[])Ground.Clone(),
                Fill = (double[])Fill.Clone(),
                Rocks = (bool[])Rocks.Clone(),
                Budget = Budget,
                Mud = MudSupply,
                NextId = nextId,
                Segments = new List<DamSegment>()
            };
            foreach (var p in Segments)
                s.Segments.Add(p.Copy());
            return s;
        }

        public void Restore(DesignState s)
        {
            Ground = (double[])s.Ground.Clone();
            Fill = (double[])s.Fill.Clone();
            Array.Copy(s.Rocks, Rocks, Rocks.Length);
            Budget = s.Budget;
            MudSupply = s.Mud;
            nextId = s.NextId;
            Segments.Clear();
            foreach (var p in s.Segments)
                Segments.Add(p.Copy());
            SyncEdges();
        }

        public void Commit(DesignState s)
        {
            if (History.Count >= 32)
            {
                var a = History.ToArray();
                History.Clear();
                for (int i = 30; i >= 0; i--)
                    History.Push(a[i]);
            }

            History.Push(s);
        }

        public bool Undo()
        {
            if (History.Count == 0)
                return false;
            Restore(History.Pop());
            return true;
        }

        // Validate length, budget, overlap, rocks and stack height before spending materials.
        public bool CanPlace(DamSegment p, out string why)
        {
            why = "";
            if (p == null || (int)p.Material < 0 || (int)p.Material >= Materials.Length)
            {
                why = "Invalid material";
                return false;
            }

            MaterialRule r = Materials[(int)p.Material];
            if (p.Length < 1 || p.Length > 6)
            {
                why = "Length must be 1–6 units";
                return false;
            }

            if (p.X < 1 || p.Z < 1 || p.X + (p.AlongX ? p.Length : 1) >= W - 1 || p.Z + (p.AlongX ? 1 : p.Length) >= H - 1)
            {
                why = "Outside construction patch";
                return false;
            }

            if (r.Cost * p.Length > Budget)
            {
                why = "Not enough material budget";
                return false;
            }

            p.Layer = 0;
            foreach (var s in Segments)
            {
                if (s.Broken)
                    continue;
                bool same = s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length;
                if (same)
                {
                    p.Layer = Math.Max(p.Layer, s.Layer + 1);
                    continue;
                }

                if (s.AlongX == p.AlongX)
                {
                    bool overlap = p.AlongX ? s.Z == p.Z && p.X < s.X + s.Length && s.X < p.X + p.Length : s.X == p.X && p.Z < s.Z + s.Length && s.Z < p.Z + p.Length;
                    if (overlap)
                    {
                        why = "Partial overlap: use identical stack endpoints";
                        return false;
                    }
                }
                else
                {
                    double px = p.X + (p.AlongX ? p.Length * .5 : 0), pz = p.Z + (p.AlongX ? 0 : p.Length * .5), sx = s.X + (s.AlongX ? s.Length * .5 : 0), sz = s.Z + (s.AlongX ? 0 : s.Length * .5);
                    if (Math.Abs(px - sx) < (p.AlongX ? p.Length * .5 : s.Length * .5) + .18 && Math.Abs(pz - sz) < (p.AlongX ? s.Length * .5 : p.Length * .5) + .18)
                    {
                        why = "Segments cannot cross through each other";
                        return false;
                    }
                }
            }

            if (p.Layer >= 3)
            {
                why = "Maximum three layers";
                return false;
            }

            for (int k = 0; k < p.Length; k++)
                if (Rocks[I(p.X + (p.AlongX ? k : 0), p.Z + (p.AlongX ? 0 : k))])
                {
                    why = "Natural rock blocks this footprint";
                    return false;
                }

            return true;
        }

        public bool Place(DamSegment p)
        {
            string why;
            if (!CanPlace(p, out why))
                return false;
            p.Id = nextId++;
            p.Foundation = Foundation(p);
            Segments.Add(p.Copy());
            Budget -= Materials[(int)p.Material].Cost * p.Length;
            SyncEdges();
            return true;
        }

        public bool Remove(int id)
        {
            var p = Segments.Find(s => s.Id == id);
            if (p == null)
                return false;
            if (Segments.Exists(s => s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer > p.Layer))
                return false;
            Budget += Materials[(int)p.Material].Cost * p.Length;
            Segments.Remove(p);
            SyncEdges();
            return true;
        }

        public double Foundation(DamSegment p)
        {
            double sum = 0;
            for (int k = 0; k < p.Length; k++)
            {
                int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                sum += Math.Max(Bed(x, z), Bed(x - (p.AlongX ? 0 : 1), z - (p.AlongX ? 1 : 0)));
            }

            return sum / p.Length;
        }

        public double Bottom(DamSegment p)
        {
            double y = Foundation(p);
            foreach (var s in Segments)
                if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer < p.Layer)
                    y += Materials[(int)s.Material].Height;
            return y;
        }

        public double Top(DamSegment p)
        {
            return Bottom(p) + Materials[(int)p.Material].Height;
        }

        public double BedAtSegment(int x, int z, bool alongX)
        {
            return Math.Max(Bed(x, z), Bed(x - (alongX ? 0 : 1), z - (alongX ? 1 : 0)));
        }

        public double Brush(double x, double z, bool add, double dt)
        {
            double changed = 0;
            for (int zz = Math.Max(1, (int)z - 2); zz <= Math.Min(H - 2, (int)z + 2); zz++)
                for (int xx = Math.Max(1, (int)x - 2); xx <= Math.Min(W - 2, (int)x + 2); xx++)
                {
                    int i = I(xx, zz);
                    double d = Math.Sqrt((xx - x) * (xx - x) + (zz - z) * (zz - z));
                    if (d > 1.6 || Rocks[i])
                        continue;
                    double amount = (1 - d / 1.6) * dt * .65;
                    if (add)
                    {
                        amount = Math.Min(amount, Math.Min(MudSupply, Math.Max(0, 1.8 - Fill[i])));
                        Fill[i] += amount;
                        MudSupply -= amount;
                    }
                    else
                    {
                        double soft = 1.0 / digResistance[(int)Kind(i)];
                        amount *= soft;
                        double f = Math.Min(Fill[i], amount);
                        Fill[i] -= f;
                        double cut = Math.Min(Math.Max(0, Ground[i] - Bedrock[i]), amount - f);
                        Ground[i] -= cut;
                        amount = f + cut;
                        MudSupply += amount * .5;
                    }

                    changed += amount;
                }

            SyncEdges();
            return changed;
        }

        public bool PlaceRock(int x, int z)
        {
            if (!Inside(x, z) || x == 0 || z == 0 || x >= W - 1 || z >= H - 1 || Rocks[I(x, z)] || Budget < 7)
                return false;
            foreach (var p in Segments)
                for (int k = 0; k < p.Length; k++)
                    if (x == p.X + (p.AlongX ? k : 0) && z == p.Z + (p.AlongX ? 0 : k))
                        return false;
            Rocks[I(x, z)] = true;
            Budget -= 7;
            SyncEdges();
            return true;
        }

        public void SyncEdges()
        {
            Array.Clear(crestX, 0, crestX.Length);
            Array.Clear(crestZ, 0, crestZ.Length);
            for (int i = 0; i < leakX.Length; i++)
            {
                leakX[i] = 1;
                passX[i] = true;
            }

            for (int i = 0; i < leakZ.Length; i++)
            {
                leakZ[i] = 1;
                passZ[i] = true;
            }

            foreach (var p in Segments)
            {
                if (p.Broken)
                    continue;
                var r = Materials[(int)p.Material];
                for (int k = 0; k < p.Length; k++)
                {
                    int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                    int e = p.AlongX ? (z - 1) * W + x : z * (W - 1) + x - 1;
                    if (p.AlongX)
                    {
                        crestZ[e] += r.Height;
                        leakZ[e] = Math.Min(leakZ[e], r.Leak);
                        passZ[e] &= r.Fish;
                    }
                    else
                    {
                        crestX[e] += r.Height;
                        leakX[e] = Math.Min(leakX[e], r.Leak);
                        passX[e] &= r.Fish;
                    }
                }
            }
        }

        public double Volume
        {
            get
            {
                double n = 0;
                foreach (double d in Depth)
                    n += d;
                return n;
            }
        }

        public double MassError
        {
            get
            {
                return Volume - Initial - Added + Drained;
            }
        }

        public double PondDepth
        {
            get
            {
                double s = 0;
                int n = 0;
                for (int z = 10; z < Rule.CrossRow; z++)
                    for (int x = 9; x <= 14; x++)
                    {
                        s += Depth[I(x, z)];
                        n++;
                    }

                return s / n;
            }
        }

        public double MaxLoad
        {
            get
            {
                double s = 0;
                foreach (var p in Segments)
                    if (!p.Broken)
                        s = Math.Max(s, p.Ratio);
                return s;
            }
        }

        public int BrokenCount
        {
            get
            {
                int n = 0;
                foreach (var p in Segments)
                    if (p.Broken)
                        n++;
                return n;
            }
        }

        public void StartTrial()
        {
            Array.Clear(Depth, 0, Depth.Length);
            Array.Clear(QX, 0, QX.Length);
            Array.Clear(QZ, 0, QZ.Length);
            Array.Clear(VX, 0, VX.Length);
            Array.Clear(VZ, 0, VZ.Length);
            Time = Added = Drained = Initial = Eroded = GoalHold = 0;
            AnimalsPassed = AnimalsFailed = FishCorrect = FishWrong = 0;
            AnimalActive = Won = Ended = false;
            Failure = "";
            AnimalX = 8;
            nextFish = 14;
            animalNext = 72;
            rng = 7281;
            Fish.Clear();
            Array.Clear(ErosionRate, 0, ErosionRate.Length);
            Array.Clear(ErosionLoss, 0, ErosionLoss.Length);
            foreach (var p in Segments)
            {
                p.Damage = p.Ratio = p.WaterDemand = p.AnimalDemand = p.EstimatedCapacity = 0;
                p.Broken = false;
            }

            SyncEdges();
        }

        double Proposed(int a, int b, double wall, double leak, double old, double dt)
        {
            double baseSill = Math.Max(Bed(a % W, a / W), Bed(b % W, b / W));
            double ha = Bed(a % W, a / W) + Depth[a], hb = Bed(b % W, b / W) + Depth[b];
            double bare = Math.Max(0, ha - baseSill) - Math.Max(0, hb - baseSill), over = Math.Max(0, ha - baseSill - wall) - Math.Max(0, hb - baseSill - wall);
            double target = 4.5 * (wall > 0 ? leak * bare + (1 - leak) * over : bare);
            // Damped flux memory, a gameplay approximation of inertia, not full SWE momentum.
            double q = old + (target - old) * (1 - Math.Exp(-dt / .12));
            if (q * target < 0 || Math.Abs(target) < 1e-8)
                q = target;
            return q;
        }

        // Transfer water between neighbor columns. Outflow scaling prevents negative water.
        public void WaterStep(double dt, bool open = true)
        {
            if (dt <= 0 || dt > .1 || double.IsNaN(dt))
                throw new ArgumentOutOfRangeException("dt");
            Array.Clear(outScale, 0, outScale.Length);
            Array.Clear(delta, 0, delta.Length);
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W - 1; x++)
                {
                    int a = I(x, z), e = z * (W - 1) + x;
                    QX[e] = Proposed(a, a + 1, crestX[e], leakX[e], QX[e], dt);
                    outScale[QX[e] >= 0 ? a : a + 1] += Math.Abs(QX[e]) * dt;
                }

            for (int z = 0; z < H - 1; z++)
                for (int x = 0; x < W; x++)
                {
                    int a = I(x, z), e = z * W + x;
                    QZ[e] = Proposed(a, a + W, crestZ[e], leakZ[e], QZ[e], dt);
                    outScale[QZ[e] >= 0 ? a : a + W] += Math.Abs(QZ[e]) * dt;
                }

            for (int i = 0; i < outScale.Length; i++)
                outScale[i] = outScale[i] > 0 ? Math.Min(1, Depth[i] / outScale[i]) : 1;
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W - 1; x++)
                {
                    int a = I(x, z), e = z * (W - 1) + x;
                    QX[e] *= outScale[QX[e] >= 0 ? a : a + 1];
                    double d = QX[e] * dt;
                    delta[a] -= d;
                    delta[a + 1] += d;
                }

            for (int z = 0; z < H - 1; z++)
                for (int x = 0; x < W; x++)
                {
                    int a = I(x, z), e = z * W + x;
                    QZ[e] *= outScale[QZ[e] >= 0 ? a : a + W];
                    double d = QZ[e] * dt;
                    delta[a] -= d;
                    delta[a + W] += d;
                }

            for (int i = 0; i < Depth.Length; i++)
                Depth[i] = Math.Max(0, Depth[i] + delta[i]);
            if (open)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, H - 1);
                    double d = Math.Min(Depth[i], 4.5 * Depth[i] * dt);
                    Depth[i] -= d;
                    Drained += d;
                }

            for (int z = 0; z < H; z++)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, z);
                    double vx = (x > 0 ? QX[z * (W - 1) + x - 1] : 0) + (x < W - 1 ? QX[z * (W - 1) + x] : 0), vz = (z > 0 ? QZ[(z - 1) * W + x] : 0) + (z < H - 1 ? QZ[z * W + x] : 0);
                    VX[i] = Math.Max(-3, Math.Min(3, vx / (2 * Math.Max(.08, Depth[i]))));
                    VZ[i] = Math.Max(-3, Math.Min(3, vz / (2 * Math.Max(.08, Depth[i]))));
                }
        }

        public static double PressureKN(double depth, double height)
        {
            double wet = Math.Min(Math.Max(0, depth), height);
            return 9.81 * (Math.Max(0, depth) * wet - wet * wet * .5);
        }

        // Estimate water, stack and animal demand. Sustained overload accumulates damage.
        public void LoadStep(double dt)
        {
            bool changed = false;
            foreach (var p in Segments)
            {
                if (p.Broken)
                    continue;
                var r = Materials[(int)p.Material];
                double foundation = Foundation(p), bottom = Bottom(p), force = 0, velocity = 0;
                for (int k = 0; k < p.Length; k++)
                {
                    int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                    int a = I(x - (p.AlongX ? 0 : 1), z - (p.AlongX ? 1 : 0)), b = I(x, z);
                    double da = Math.Max(0, Bed(a % W, a / W) + Depth[a] - bottom), db = Math.Max(0, Bed(b % W, b / W) + Depth[b] - bottom);
                    force += Math.Abs(PressureKN(da, r.Height) - PressureKN(db, r.Height));
                    velocity += Math.Max(VX[a] * VX[a] + VZ[a] * VZ[a], VX[b] * VX[b] + VZ[b] * VZ[b]);
                }

                force += velocity * .03;
                foreach (var s in Segments)
                    if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer > p.Layer)
                        force += Materials[(int)s.Material].Mass * 9.81 * s.Length * .12;
                int ex = p.X + (p.AlongX ? p.Length : 0), ez = p.Z + (p.AlongX ? 0 : p.Length);
                bool left = Bed(Math.Max(0, p.X - (p.AlongX ? 1 : 0)), Math.Max(0, p.Z - (p.AlongX ? 0 : 1))) > .9;
                bool right = Bed(Math.Min(W - 1, ex), Math.Min(H - 1, ez)) > .9;
                foreach (var s in Segments)
                    if (s != p && !s.Broken && s.AlongX == p.AlongX && s.Layer == p.Layer)
                    {
                        if (p.AlongX && s.Z == p.Z)
                        {
                            left |= s.X + s.Length == p.X;
                            right |= p.X + p.Length == s.X;
                        }

                        if (!p.AlongX && s.X == p.X)
                        {
                            left |= s.Z + s.Length == p.Z;
                            right |= p.Z + p.Length == s.Z;
                        }
                    }

                double support = (left ? 1.22 : 1) * (right ? 1.22 : 1);
                if (foundation < p.Foundation - .2)
                    support *= .55;
                double animal = AnimalActive && p.AlongX && p.Z == Rule.CrossRow && AnimalX >= p.X && AnimalX <= p.X + p.Length ? Rule.AnimalMass * 9.81 : 0;
                // Weight contributes simplified frictional resistance; span and scour reduce capacity.
                double capacity = (r.Capacity + r.Mass * 9.81 * .4) * p.Length * support / (1 + .12 * Math.Max(0, p.Length - 2) * Math.Max(0, p.Length - 2));
                p.WaterDemand = force;
                p.AnimalDemand = animal * 3;
                p.EstimatedCapacity = capacity;
                p.Ratio = (force + animal * 3) / Math.Max(.1, capacity);
                p.Damage = Math.Max(0, p.Damage + dt * (p.Ratio > 1 ? (p.Ratio - 1) * .11 : -.025));
                if (p.Damage >= 1)
                {
                    p.Broken = true;
                    changed = true;
                }
            }

            // A failed supporting layer cannot leave upper bundles hovering intact.
            if (changed)
            {
                foreach (var p in Segments)
                    if (!p.Broken && Segments.Exists(s => s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer < p.Layer))
                        p.Broken = true;
                SyncEdges();
            }
        }

        // Remove eligible wet ground according to velocity and soil resistance; no sediment transport.
        public void ErodeStep(double dt)
        {
            Array.Clear(ErosionRate, 0, ErosionRate.Length);
            for (int z = 1; z < H - 1; z++)
                for (int x = 1; x < W - 1; x++)
                {
                    int i = I(x, z);
                    if (Rocks[i] || Depth[i] < .035)
                        continue;
                    int kind = (int)Kind(i);
                    double speed2 = VX[i] * VX[i] + VZ[i] * VZ[i];
                    double stress = 6 * speed2;
                    double excess = Math.Max(0, stress - wearThreshold[kind]);
                    double wear = Math.Min(.006, dt * wearRate[kind] * excess);
                    double f = Math.Min(Fill[i], wear);
                    Fill[i] -= f;
                    double cut = Math.Min(Math.Max(0, Ground[i] - Bedrock[i]), wear - f);
                    Ground[i] -= cut;
                    Eroded += f + cut;
                    ErosionLoss[i] += f + cut;
                    ErosionRate[i] = dt > 0 ? (f + cut) / dt : 0;
                }
        }

        double Random()
        {
            rng ^= rng << 13;
            rng ^= rng >> 17;
            rng ^= rng << 5;
            return rng / (double)uint.MaxValue;
        }

        // Only allow adjacent wet-cell moves through an opening or above an overtopped crest.
        public bool FishEdge(int x, int z, int nx, int nz)
        {
            if (!Inside(x, z) || !Inside(nx, nz) || Math.Abs(nx - x) + Math.Abs(nz - z) != 1 || Depth[I(x, z)] < .035 || Depth[I(nx, nz)] < .035)
                return false;
            bool alongX = z != nz;
            int e = alongX ? Math.Min(z, nz) * W + x : z * (W - 1) + Math.Min(x, nx);
            double crest = alongX ? crestZ[e] : crestX[e];
            bool pass = alongX ? passZ[e] : passX[e];
            if (crest == 0 || pass)
                return true;
            double sill = Math.Max(Bed(x, z), Bed(nx, nz)) + crest;
            return Math.Min(Bed(x, z) + Depth[I(x, z)], Bed(nx, nz) + Depth[I(nx, nz)]) > sill + .12;
        }

        public void FishStep(double dt)
        {
            if (Time >= nextFish && Fish.Count < 12)
            {
                nextFish += 8;
                Fish.Add(new FishParcel { X = 11 + (Fish.Count % 2), Z = 2 });
            }

            foreach (var f in Fish)
            {
                if (f.Finished)
                    continue;
                if (f.Z >= H - 2)
                {
                    f.Finished = true;
                    if (Rule.Fork && f.X >= 18)
                        FishCorrect++;
                    else if (Rule.FishGoal > 0)
                        FishWrong++;
                    continue;
                }

                int x = f.X, z = f.Z, i = I(x, z);
                double[] q = fishFlows;
                q[0] = x > 0 ? -QX[z * (W - 1) + x - 1] : 0;
                q[1] = x < W - 1 ? QX[z * (W - 1) + x] : 0;
                q[2] = z > 0 ? -QZ[(z - 1) * W + x] : 0;
                q[3] = z < H - 1 ? QZ[z * W + x] : 0;
                int[] dx = fishDX, dz = fishDZ;
                double total = 0;
                for (int j = 0; j < 4; j++)
                {
                    if (q[j] < 0 || !FishEdge(x, z, x + dx[j], z + dz[j]))
                        q[j] = 0;
                    total += q[j];
                }

                // Passive flux-weighted parcels; no goal seeking or teleportation to nursery.
                if (total > 0 && Random() < Math.Min(.8, total * dt / Math.Max(.04, Depth[i])))
                {
                    double pick = Random() * total;
                    for (int j = 0; j < 4; j++)
                    {
                        pick -= q[j];
                        if (pick <= 0 && q[j] > 0)
                        {
                            f.X += dx[j];
                            f.Z += dz[j];
                            break;
                        }
                    }
                }
            }
        }

        public double WalkHeight(double x, int row)
        {
            int cell = Math.Max(0, Math.Min(W - 1, (int)x));
            double ground = Sample(x, row), height = double.NegativeInfinity;
            foreach (var p in Segments)
                if (!p.Broken && p.AlongX && p.Z == row && x >= p.X && x <= p.X + p.Length && Materials[(int)p.Material].Walkable)
                {
                    double top = Foundation(p);
                    foreach (var s in Segments)
                        if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer <= p.Layer)
                            top += Materials[(int)s.Material].Height;
                    height = Math.Max(height, top);
                }

            if (ground > .9 && Depth[I(cell, row)] < .04)
                return ground + .12;
            // Short bank-to-crest access ramps across the one-cell sloped shoreline.
            if (x >= 8 && x < 9 && Segments.Exists(p => !p.Broken && p.AlongX && p.Z == row && p.X == 9 && Materials[(int)p.Material].Walkable))
                return Sample(8, row) + .12;
            if (x >= 15 && x < 16 && Segments.Exists(p => !p.Broken && p.AlongX && p.Z == row && p.X + p.Length == 15 && Materials[(int)p.Material].Walkable))
                return Sample(16, row) + .12;
            double surface = Bed(cell, row) + Depth[I(cell, row)];
            return height > surface + .08 ? height : double.NaN;
        }

        void AnimalStep(double dt)
        {
            if (!AnimalActive && AnimalsPassed + AnimalsFailed < Rule.AnimalCount && Time >= animalNext)
            {
                AnimalActive = true;
                AnimalX = 8;
            }

            if (!AnimalActive)
                return;
            if (double.IsNaN(WalkHeight(AnimalX, Rule.CrossRow)))
            {
                Failure = "Animal lost footing at x=" + AnimalX.ToString("F2") + " time=" + Time.ToString("F1");
                AnimalActive = false;
                AnimalsFailed++;
                animalNext = Time + 12;
                return;
            }

            AnimalX += dt * .7;
            if (AnimalX >= 15.5)
            {
                AnimalActive = false;
                AnimalsPassed++;
                animalNext = Time + 12;
            }
        }

        // One fixed simulation step: supply water, flow, erode, load structures, move fish/animals, score.
        public void Tick(double dt = Dt)
        {
            if (dt <= 0 || dt > .1 || double.IsNaN(dt))
                throw new ArgumentOutOfRangeException("dt");
            if (Won || Ended)
                return;
            Time += dt;
            double source = Rule.Source * (Rule.Surge && Time >= 85 && Time < 115 ? 1.6 : 1);
            for (int x = 9; x <= 14; x++)
            {
                double volume = source * dt / 6;
                Depth[I(x, 0)] += volume;
                Added += volume;
            }

            WaterStep(dt);
            if (Erosion)
                ErodeStep(dt);
            else
                Array.Clear(ErosionRate, 0, ErosionRate.Length);
            LoadStep(dt);
            FishStep(dt);
            AnimalStep(dt);
            bool goals = PondDepth >= Rule.PondGoal && AnimalsPassed >= Rule.AnimalCount && FishCorrect >= Rule.FishGoal && FishWrong <= (Level == 3 ? 3 : 0) && AnimalsFailed == 0 && BrokenCount == 0;
            GoalHold = goals ? GoalHold + dt : 0;
            if (GoalHold >= 3)
                Won = true;
            if (Time >= Rule.Duration)
            {
                Ended = true;
                if (!Won && Failure == "")
                    Failure = "Trial ended: revise depth, crest continuity, material load or fish route.";
            }
        }

        // Construct a checked teaching solution; this does not auto-complete tutorial actions.
        public void ExampleDesign()
        {
            DamMaterial material = Level == 3 ? DamMaterial.Stone : DamMaterial.Timber;
            Place(new DamSegment { X = 9, Z = Rule.CrossRow, Length = 3, Material = material });
            Place(new DamSegment { X = 12, Z = Rule.CrossRow, Length = 3, Material = material });
            if (Level == 3)
            {
                for (int layer = 1; layer < 3; layer++)
                {
                    Place(new DamSegment { X = 9, Z = Rule.CrossRow, Length = 3, Material = material });
                    Place(new DamSegment { X = 12, Z = Rule.CrossRow, Length = 3, Material = material });
                }
            }
        }

        public void ClearDesign(bool clearHistory = true)
        {
            Segments.Clear();
            Array.Copy(Original, Ground, Ground.Length);
            Array.Clear(Fill, 0, Fill.Length);
            Array.Copy(Permanent, Rocks, Rocks.Length);
            Budget = Rule.Budget;
            MudSupply = 40;
            if (clearHistory)
                History.Clear();
            nextId = 1;
            StartTrial();
        }

        public bool RemoveRock(int x, int z)
        {
            if (!Inside(x, z) || !Rocks[I(x, z)] || Permanent[I(x, z)])
                return false;
            Rocks[I(x, z)] = false;
            Budget += 7;
            SyncEdges();
            return true;
        }
    }
}
