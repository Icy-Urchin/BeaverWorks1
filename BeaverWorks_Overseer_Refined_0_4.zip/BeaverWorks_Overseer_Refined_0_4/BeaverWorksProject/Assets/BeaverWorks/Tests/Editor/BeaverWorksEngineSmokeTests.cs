using System;
using System.Collections;
using System.Reflection;
using BeaverWorksV3;
using NUnit.Framework;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;

/// <summary>
/// Run in EditMode Test Runner AFTER project setup. This test enters Play mode.
/// It uses reflection only because the runtime scripts use Unity's default Assembly-CSharp.
/// This file has NOT been executed in the authoring sandbox: Unity is required.
/// </summary>
public sealed class BeaverWorksEngineSmokeTests
{
    [UnityTest]
    public IEnumerator StartupAndMouseDragPlacement()
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        yield return new EnterPlayMode();
        Type type = Type.GetType("BeaverWorksV3.WorksGame, Assembly-CSharp");
        Assert.IsNotNull(type, "Runtime script did not compile into Assembly-CSharp.");
        var root = new GameObject("Smoke Test Controller");
        Component game = root.AddComponent(type);
        type.GetField("SurfaceShader").SetValue(game, Shader.Find("BeaverWorksV3/Surface"));
        yield return null;
        yield return null;
        var model = (WorksModel)type.GetProperty("Model").GetValue(game);
        var camera = (Camera)type.GetProperty("StageCamera").GetValue(game);
        Assert.IsNotNull(model);
        Assert.IsNotNull(camera);
        Assert.IsTrue(camera.orthographic);
        Assert.IsTrue(root.GetComponentsInChildren<Canvas>().Length == 1);
        Assert.IsTrue(root.GetComponentsInChildren<Button>().Length > 10);
        Assert.IsTrue(root.GetComponentsInChildren<Slider>().Length == 1);
        Vector3 a = camera.WorldToScreenPoint(new Vector3(12, (float)model.Sample(12, 23), 23));
        Vector3 b = camera.WorldToScreenPoint(new Vector3(15, (float)model.Sample(15, 23), 23));
        type.GetMethod("PointerDown").Invoke(game, new object[] { -1, new Vector2(a.x, a.y) });
        type.GetMethod("PointerDrag").Invoke(game, new object[] { -1, new Vector2(b.x, b.y) });
        type.GetMethod("PointerUp").Invoke(game, new object[] { -1, new Vector2(b.x, b.y) });
        Assert.AreEqual(1, model.Segments.Count, "World picking, viewport or UI hit test rejected this drag.");
        Assert.AreEqual(3, model.Segments[0].Length);
        type.GetMethod("Undo", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(game, null);
        Assert.AreEqual(0, model.Segments.Count);
        UnityEngine.Object.Destroy(root);
        yield return null;
        yield return new ExitPlayMode();
    }
}
