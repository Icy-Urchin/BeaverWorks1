// Sources: Unity's documented URP unlit/color pattern, adapted with vertex colors.
// This is not Poly Bridge code. Real water physics is in WorksModel.cs.
Shader "BeaverWorksV3/Surface"
{
    Properties { [MainColor] _BaseColor("Base Color", Color) = (1,1,1,1) }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
        Pass
        {
            Name "BeaverUnlit"
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Off
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                half4 color : COLOR;
            };
            struct Varyings
            {
                float4 positionHCS : SV_POSITION;
                half4 color : COLOR;
                half light : TEXCOORD0;
            };
            CBUFFER_START(UnityPerMaterial)
                half4 _BaseColor;
            CBUFFER_END
            Varyings Vert(Attributes input)
            {
                Varyings output;
                output.positionHCS = TransformObjectToHClip(input.positionOS.xyz);
                half4 vertexColor = input.color;
                if (dot(vertexColor.rgb, vertexColor.rgb) < .00001) vertexColor = half4(1,1,1,1);
                output.color = vertexColor * _BaseColor;
                float3 worldNormal = TransformObjectToWorldNormal(input.normalOS);
                worldNormal = dot(worldNormal,worldNormal) > .00001 ? normalize(worldNormal) : float3(0,1,0);
                output.light = .7 + .3 * saturate(dot(worldNormal, normalize(float3(-.3,.8,-.5))));
                return output;
            }
            half4 Frag(Varyings input) : SV_Target { return half4(input.color.rgb * input.light, 1); }
            ENDHLSL
        }
    }
}
