using BeaverWorksV3;
using NUnit.Framework;

/// <summary>Unity EditMode wrappers for the same source checks run outside Unity.</summary>
public sealed class BeaverWorksModelTests
{
    [Test]
    public void OriginalModelAndFourLevelSolutions()
    {
        StringAssert.Contains("38 actual C#", WorksChecks.Run());
    }

    [Test]
    public void SnapshotReplayAndDiagnosticFields()
    {
        StringAssert.Contains("26 replay/diagnostic", WorksReplayChecks.Run());
    }

    [Test]
    public void FishQueriesRejectInvalidAndNonAdjacentCells()
    {
        var m = new WorksModel(2);
        Assert.IsFalse(m.FishEdge(-1, 1, 0, 1));
        Assert.IsFalse(m.FishEdge(1, 1, 3, 1));
        Assert.IsFalse(m.FishEdge(1, 1, 1, 1));
    }

    [Test]
    public void ExampleLoadCanBeUndoneWithoutDeletingEarlierHistory()
    {
        var m = new WorksModel(0);
        var old = m.Capture();
        m.Place(new DamSegment { X = 9, Z = 23, Length = 2, Material = DamMaterial.Timber });
        m.Commit(old);
        var beforeExample = m.Capture();
        m.ClearDesign(false);
        m.ExampleDesign();
        m.Commit(beforeExample);
        Assert.IsTrue(m.Undo());
        Assert.AreEqual(1, m.Segments.Count);
        Assert.AreEqual(2, m.Segments[0].Length);
        Assert.IsTrue(m.Undo());
        Assert.AreEqual(0, m.Segments.Count);
    }
}
