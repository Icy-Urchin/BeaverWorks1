// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        double Random()
        {
            rng ^= rng << 13;
            rng ^= rng >> 17;
            rng ^= rng << 5;
            return rng / (double)uint.MaxValue;
        }

        public bool FishEdge(int x, int z, int nx, int nz)
        {
            if (!Inside(x, z) || !Inside(nx, nz) || Math.Abs(nx - x) + Math.Abs(nz - z) != 1 || Depth[I(x, z)] < .035 || Depth[I(nx, nz)] < .035)
                return false;
            bool alongX = z != nz;
            int e = alongX ? Math.Min(z, nz) * W + x : z * (W - 1) + Math.Min(x, nx);
            double crest = alongX ? crestZ[e] : crestX[e];
            bool pass = alongX ? passZ[e] : passX[e];
            if (crest == 0 || pass)
                return true;
            double sill = Math.Max(Bed(x, z), Bed(nx, nz)) + crest;
            return Math.Min(Bed(x, z) + Depth[I(x, z)], Bed(nx, nz) + Depth[I(nx, nz)]) > sill + .12;
        }

        public void FishStep(double dt)
        {
            if (Time >= nextFish && Fish.Count < 12)
            {
                nextFish += 8;
                Fish.Add(new FishParcel { X = 11 + (Fish.Count % 2), Z = 2 });
            }

            foreach (var f in Fish)
            {
                if (f.Finished)
                    continue;
                if (f.Z >= H - 2)
                {
                    f.Finished = true;
                    if (Rule.Fork && f.X >= 18)
                        FishCorrect++;
                    else if (Rule.FishGoal > 0)
                        FishWrong++;
                    continue;
                }

                int x = f.X, z = f.Z, i = I(x, z);
                double[] q = fishFlows;
                q[0] = x > 0 ? -QX[z * (W - 1) + x - 1] : 0;
                q[1] = x < W - 1 ? QX[z * (W - 1) + x] : 0;
                q[2] = z > 0 ? -QZ[(z - 1) * W + x] : 0;
                q[3] = z < H - 1 ? QZ[z * W + x] : 0;
                int[] dx = fishDX, dz = fishDZ;
                double total = 0;
                for (int j = 0; j < 4; j++)
                {
                    if (q[j] < 0 || !FishEdge(x, z, x + dx[j], z + dz[j]))
                        q[j] = 0;
                    total += q[j];
                }

                // Passive flux-weighted parcels; no goal seeking or teleportation to nursery.
                if (total > 0 && Random() < Math.Min(.8, total * dt / Math.Max(.04, Depth[i])))
                {
                    double pick = Random() * total;
                    for (int j = 0; j < 4; j++)
                    {
                        pick -= q[j];
                        if (pick <= 0 && q[j] > 0)
                        {
                            f.X += dx[j];
                            f.Z += dz[j];
                            break;
                        }
                    }
                }
            }
        }

        public double WalkHeight(double x, int row)
        {
            int cell = Math.Max(0, Math.Min(W - 1, (int)x));
            double ground = Sample(x, row), height = double.NegativeInfinity;
            foreach (var p in Segments)
                if (!p.Broken && p.AlongX && p.Z == row && x >= p.X && x <= p.X + p.Length && Materials[(int)p.Material].Walkable)
                {
                    double top = Foundation(p);
                    foreach (var s in Segments)
                        if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer <= p.Layer)
                            top += Materials[(int)s.Material].Height;
                    height = Math.Max(height, top);
                }

            if (ground > .9 && Depth[I(cell, row)] < .04)
                return ground + .12;
            // Short bank-to-crest access ramps across the one-cell sloped shoreline.
            if (x >= 8 && x < 9 && Segments.Exists(p => !p.Broken && p.AlongX && p.Z == row && p.X == 9 && Materials[(int)p.Material].Walkable))
                return Sample(8, row) + .12;
            if (x >= 15 && x < 16 && Segments.Exists(p => !p.Broken && p.AlongX && p.Z == row && p.X + p.Length == 15 && Materials[(int)p.Material].Walkable))
                return Sample(16, row) + .12;
            double surface = Bed(cell, row) + Depth[I(cell, row)];
            return height > surface + .08 ? height : double.NaN;
        }

        void AnimalStep(double dt)
        {
            if (!AnimalActive && AnimalsPassed + AnimalsFailed < Rule.AnimalCount && Time >= animalNext)
            {
                AnimalActive = true;
                AnimalX = 8;
            }

            if (!AnimalActive)
                return;
            if (double.IsNaN(WalkHeight(AnimalX, Rule.CrossRow)))
            {
                Failure = "Animal lost footing at x=" + AnimalX.ToString("F2") + " time=" + Time.ToString("F1");
                AnimalActive = false;
                AnimalsFailed++;
                animalNext = Time + 12;
                return;
            }

            AnimalX += dt * .7;
            if (AnimalX >= 15.5)
            {
                AnimalActive = false;
                AnimalsPassed++;
                animalNext = Time + 12;
            }
        }
    }
}
