// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        public bool CanPlace(DamSegment p, out string why)
        {
            why = "";
            if (p == null || (int)p.Material < 0 || (int)p.Material >= Materials.Length)
            {
                why = "Invalid material";
                return false;
            }

            MaterialRule r = Materials[(int)p.Material];
            if (p.Length < 1 || p.Length > 6)
            {
                why = "Length must be 1–6 units";
                return false;
            }

            if (p.X < 1 || p.Z < 1 || p.X + (p.AlongX ? p.Length : 1) >= W - 1 || p.Z + (p.AlongX ? 1 : p.Length) >= H - 1)
            {
                why = "Outside construction patch";
                return false;
            }

            if (r.Cost * p.Length > Budget)
            {
                why = "Not enough material budget";
                return false;
            }

            p.Layer = 0;
            foreach (var s in Segments)
            {
                if (s.Broken)
                    continue;
                bool same = s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length;
                if (same)
                {
                    p.Layer = Math.Max(p.Layer, s.Layer + 1);
                    continue;
                }

                if (s.AlongX == p.AlongX)
                {
                    bool overlap = p.AlongX ? s.Z == p.Z && p.X < s.X + s.Length && s.X < p.X + p.Length : s.X == p.X && p.Z < s.Z + s.Length && s.Z < p.Z + p.Length;
                    if (overlap)
                    {
                        why = "Partial overlap: use identical stack endpoints";
                        return false;
                    }
                }
                else
                {
                    double px = p.X + (p.AlongX ? p.Length * .5 : 0), pz = p.Z + (p.AlongX ? 0 : p.Length * .5), sx = s.X + (s.AlongX ? s.Length * .5 : 0), sz = s.Z + (s.AlongX ? 0 : s.Length * .5);
                    if (Math.Abs(px - sx) < (p.AlongX ? p.Length * .5 : s.Length * .5) + .18 && Math.Abs(pz - sz) < (p.AlongX ? s.Length * .5 : p.Length * .5) + .18)
                    {
                        why = "Segments cannot cross through each other";
                        return false;
                    }
                }
            }

            if (p.Layer >= 3)
            {
                why = "Maximum three layers";
                return false;
            }

            for (int k = 0; k < p.Length; k++)
                if (Rocks[I(p.X + (p.AlongX ? k : 0), p.Z + (p.AlongX ? 0 : k))])
                {
                    why = "Natural rock blocks this footprint";
                    return false;
                }

            return true;
        }

        public bool Place(DamSegment p)
        {
            string why;
            if (!CanPlace(p, out why))
                return false;
            p.Id = nextId++;
            p.Foundation = Foundation(p);
            Segments.Add(p.Copy());
            Budget -= Materials[(int)p.Material].Cost * p.Length;
            SyncEdges();
            return true;
        }

        public bool Remove(int id)
        {
            var p = Segments.Find(s => s.Id == id);
            if (p == null)
                return false;
            if (Segments.Exists(s => s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer > p.Layer))
                return false;
            Budget += Materials[(int)p.Material].Cost * p.Length;
            Segments.Remove(p);
            SyncEdges();
            return true;
        }

        public double Foundation(DamSegment p)
        {
            double sum = 0;
            for (int k = 0; k < p.Length; k++)
            {
                int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                sum += Math.Max(Bed(x, z), Bed(x - (p.AlongX ? 0 : 1), z - (p.AlongX ? 1 : 0)));
            }

            return sum / p.Length;
        }

        public double Bottom(DamSegment p)
        {
            double y = Foundation(p);
            foreach (var s in Segments)
                if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer < p.Layer)
                    y += Materials[(int)s.Material].Height;
            return y;
        }

        public double Top(DamSegment p)
        {
            return Bottom(p) + Materials[(int)p.Material].Height;
        }

        public double BedAtSegment(int x, int z, bool alongX)
        {
            return Math.Max(Bed(x, z), Bed(x - (alongX ? 0 : 1), z - (alongX ? 1 : 0)));
        }

        public void SyncEdges()
        {
            Array.Clear(crestX, 0, crestX.Length);
            Array.Clear(crestZ, 0, crestZ.Length);
            for (int i = 0; i < leakX.Length; i++)
            {
                leakX[i] = 1;
                passX[i] = true;
            }

            for (int i = 0; i < leakZ.Length; i++)
            {
                leakZ[i] = 1;
                passZ[i] = true;
            }

            foreach (var p in Segments)
            {
                if (p.Broken)
                    continue;
                var r = Materials[(int)p.Material];
                for (int k = 0; k < p.Length; k++)
                {
                    int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                    int e = p.AlongX ? (z - 1) * W + x : z * (W - 1) + x - 1;
                    if (p.AlongX)
                    {
                        crestZ[e] += r.Height;
                        leakZ[e] = Math.Min(leakZ[e], r.Leak);
                        passZ[e] &= r.Fish;
                    }
                    else
                    {
                        crestX[e] += r.Height;
                        leakX[e] = Math.Min(leakX[e], r.Leak);
                        passX[e] &= r.Fish;
                    }
                }
            }
        }

        public void ExampleDesign()
        {
            DamMaterial material = Level == 3 ? DamMaterial.Stone : DamMaterial.Timber;
            Place(new DamSegment { X = 9, Z = Rule.CrossRow, Length = 3, Material = material });
            Place(new DamSegment { X = 12, Z = Rule.CrossRow, Length = 3, Material = material });
            if (Level == 3)
            {
                for (int layer = 1; layer < 3; layer++)
                {
                    Place(new DamSegment { X = 9, Z = Rule.CrossRow, Length = 3, Material = material });
                    Place(new DamSegment { X = 12, Z = Rule.CrossRow, Length = 3, Material = material });
                }
            }
        }

        public void ClearDesign(bool clearHistory = true)
        {
            Segments.Clear();
            Array.Copy(Original, Ground, Ground.Length);
            Array.Clear(Fill, 0, Fill.Length);
            Array.Copy(Permanent, Rocks, Rocks.Length);
            Budget = Rule.Budget;
            MudSupply = 40;
            if (clearHistory)
                History.Clear();
            nextId = 1;
            StartTrial();
        }
    }
}
