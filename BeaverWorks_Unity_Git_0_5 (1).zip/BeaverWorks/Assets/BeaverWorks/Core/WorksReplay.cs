// Original snapshot replay. Playback is deliberately read-only: it never calls Tick.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed class ReplayEvent
    {
        public double Time;
        public string Label;
        public bool Warning;
    }

    public sealed class ReplayFrame
    {
        public double Time, Added, Drained, Initial, Eroded, Hold, AnimalX;
        public int FishCorrect, FishWrong, AnimalsPassed, AnimalsFailed;
        public bool AnimalActive, Won, Ended, Erosion;
        public string Failure;
        public float[] Ground, Fill, Depth, VX, VZ, Wear, Loss;
        public DamSegment[] Segments;
        public FishParcel[] Fish;
        public float BuddyX, BuddyY, BuddyZ, BuddyYaw;
        public double MaxPressure, MaxLoad;
        static float[] Compact(double[] source)
        {
            var a = new float[source.Length];
            for (int i = 0; i < a.Length; i++)
                a[i] = (float)source[i];
            return a;
        }

        static void Expand(float[] source, double[] target)
        {
            for (int i = 0; i < source.Length; i++)
                target[i] = source[i];
        }

        public static ReplayFrame Capture(WorksModel m, float bx = 0, float by = 0, float bz = 0, float yaw = 0)
        {
            var f = new ReplayFrame
            {
                Time = m.Time,
                Added = m.Added,
                Drained = m.Drained,
                Initial = m.Initial,
                Eroded = m.Eroded,
                Hold = m.GoalHold,
                AnimalX = m.AnimalX,
                FishCorrect = m.FishCorrect,
                FishWrong = m.FishWrong,
                AnimalsPassed = m.AnimalsPassed,
                AnimalsFailed = m.AnimalsFailed,
                AnimalActive = m.AnimalActive,
                Won = m.Won,
                Ended = m.Ended,
                Erosion = m.Erosion,
                Failure = m.Failure,
                Ground = Compact(m.Ground),
                Fill = Compact(m.Fill),
                Depth = Compact(m.Depth),
                VX = Compact(m.VX),
                VZ = Compact(m.VZ),
                Wear = Compact(m.ErosionRate),
                Loss = Compact(m.ErosionLoss),
                Segments = new DamSegment[m.Segments.Count],
                Fish = new FishParcel[m.Fish.Count],
                BuddyX = bx,
                BuddyY = by,
                BuddyZ = bz,
                BuddyYaw = yaw,
                MaxLoad = m.MaxLoad
            };
            for (int i = 0; i < f.Segments.Length; i++)
                f.Segments[i] = m.Segments[i].Copy();
            for (int i = 0; i < f.Fish.Length; i++)
            {
                var p = m.Fish[i];
                f.Fish[i] = new FishParcel
                {
                    X = p.X,
                    Z = p.Z,
                    Finished = p.Finished,
                    Wait = p.Wait
                };
            }

            foreach (double depth in m.Depth)
                f.MaxPressure = Math.Max(f.MaxPressure, 9.81 * depth);
            return f;
        }

        public void Apply(WorksModel target)
        {
            Expand(Ground, target.Ground);
            Expand(Fill, target.Fill);
            Expand(Depth, target.Depth);
            Expand(VX, target.VX);
            Expand(VZ, target.VZ);
            Expand(Wear, target.ErosionRate);
            Expand(Loss, target.ErosionLoss);
            target.Segments.Clear();
            foreach (var p in Segments)
                target.Segments.Add(p.Copy());
            target.Fish.Clear();
            foreach (var p in Fish)
                target.Fish.Add(new FishParcel { X = p.X, Z = p.Z, Finished = p.Finished, Wait = p.Wait });
            target.Time = Time;
            target.Added = Added;
            target.Drained = Drained;
            target.Initial = Initial;
            target.Eroded = Eroded;
            target.GoalHold = Hold;
            target.AnimalX = AnimalX;
            target.FishCorrect = FishCorrect;
            target.FishWrong = FishWrong;
            target.AnimalsPassed = AnimalsPassed;
            target.AnimalsFailed = AnimalsFailed;
            target.AnimalActive = AnimalActive;
            target.Won = Won;
            target.Ended = Ended;
            target.Erosion = Erosion;
            target.Failure = Failure;
            target.SyncEdges();
        }
    }

    public sealed class WorksReplay
    {
        public const double Interval = .25; // four snapshots/second, plus exact event-time frames
        public const int FrameLimit = 1800;
        public const long ByteLimit = 48L * 1024 * 1024;
        readonly List<ReplayFrame> frames = new List<ReplayFrame>();
        readonly List<ReplayEvent> events = new List<ReplayEvent>();
        DesignState baseline;
        int level, broken, wrong, correct, passed, failed;
        bool active, won, ended, surge;
        double nextSample;
        bool full;
        public IList<ReplayFrame> Frames
        {
            get
            {
                return frames.AsReadOnly();
            }
        }

        public IList<ReplayEvent> Events
        {
            get
            {
                return events.AsReadOnly();
            }
        }

        public int Count
        {
            get
            {
                return frames.Count;
            }
        }

        public bool Full
        {
            get
            {
                return full;
            }
        }

        public long ApproximateBytes { get; private set; }

        public double Duration
        {
            get
            {
                return frames.Count == 0 ? 0 : frames[frames.Count - 1].Time;
            }
        }

        public double PeakPressure { get; private set; }
        public double PeakLoad { get; private set; }

        public void Begin(WorksModel model)
        {
            frames.Clear();
            events.Clear();
            baseline = model.Capture();
            level = model.Level;
            nextSample = 0;
            full = false;
            ApproximateBytes = 0;
            PeakPressure = PeakLoad = 0;
            broken = wrong = correct = passed = failed = 0;
            active = won = ended = surge = false;
            events.Add(new ReplayEvent { Time = model.Time, Label = "TEST START" });
        }

        public void Record(WorksModel m, float bx = 0, float by = 0, float bz = 0, float yaw = 0, bool force = false)
        {
            if (baseline == null)
                throw new InvalidOperationException("Begin before recording");
            bool eventFrame = false;
            bool nowSurge = m.Rule.Surge && m.Time >= 85 && m.Time < 115;
            Action<string, bool> add = (label, warning) =>
            {
                if (events.Count < 512)
                    events.Add(new ReplayEvent { Time = m.Time, Label = label, Warning = warning });
                eventFrame = true;
            };
            if (nowSurge != surge)
                add(nowSurge ? "SPRING SURGE BEGINS" : "SPRING SURGE ENDS", false);
            if (m.AnimalActive && !active)
                add("ANIMAL ENTERS CROSSING", false);
            if (m.BrokenCount > broken)
                add("DAM BREACH: " + m.BrokenCount + " broken segment(s)", true);
            if (m.FishWrong > wrong)
                add("FISH WRONG OUTLET: " + m.FishWrong, true);
            if (m.FishCorrect > correct)
                add("FISH REACHES NURSERY: " + m.FishCorrect, false);
            if (m.AnimalsFailed > failed)
                add("ANIMAL LOST FOOTING", true);
            if (m.AnimalsPassed > passed)
                add("ANIMAL CROSSING COMPLETE: " + m.AnimalsPassed, false);
            if (m.Won && !won)
                add("HABITAT COMPLETE", false);
            if (m.Ended && !ended)
                add("TEST ENDED: " + m.Failure, !m.Won);
            broken = m.BrokenCount;
            wrong = m.FishWrong;
            correct = m.FishCorrect;
            passed = m.AnimalsPassed;
            failed = m.AnimalsFailed;
            active = m.AnimalActive;
            won = m.Won;
            ended = m.Ended;
            surge = nowSurge;
            foreach (double d in m.Depth)
                PeakPressure = Math.Max(PeakPressure, 9.81 * d);
            foreach (var p in m.Segments)
                PeakLoad = Math.Max(PeakLoad, p.Ratio);
            if (full || (!force && !eventFrame && m.Time + 1e-8 < nextSample))
                return;
            var f = ReplayFrame.Capture(m, bx, by, bz, yaw);
            long bytes = (long)WorksModel.W * WorksModel.H * 7 * 4 + f.Segments.Length * 160 + f.Fish.Length * 40 + 256;
            bool replace = frames.Count > 0 && Math.Abs(frames[frames.Count - 1].Time - m.Time) < 1e-8;
            if (!replace && (frames.Count >= FrameLimit || ApproximateBytes + bytes > ByteLimit))
            {
                full = true;
                events.Add(new ReplayEvent { Time = m.Time, Label = "REPLAY CAP REACHED: later time is not recorded", Warning = true });
                return;
            }

            if (replace)
                frames[frames.Count - 1] = f;
            else
            {
                frames.Add(f);
                ApproximateBytes += bytes;
            }

            nextSample = Math.Floor(m.Time / Interval + 1) * Interval;
        }

        public WorksModel CreateViewer()
        {
            if (baseline == null)
                throw new InvalidOperationException("No recording");
            var m = new WorksModel(level);
            m.Restore(baseline);
            return m;
        }

        public int IndexAt(double time)
        {
            if (frames.Count == 0)
                return -1;
            int lo = 0, hi = frames.Count - 1;
            while (lo < hi)
            {
                int mid = (lo + hi + 1) / 2;
                if (frames[mid].Time <= time)
                    lo = mid;
                else
                    hi = mid - 1;
            }

            return lo;
        }

        public ReplayFrame Seek(WorksModel viewer, double time)
        {
            int index = IndexAt(time);
            if (index < 0)
                return null;
            var f = frames[index];
            f.Apply(viewer);
            return f;
        }

        public double EventTime(double time, bool next, bool warningOnly = false)
        {
            if (next)
            {
                foreach (var e in events)
                    if (e.Time > time + 1e-5 && (!warningOnly || e.Warning))
                        return Math.Min(Duration, e.Time);
                return Duration;
            }

            for (int i = events.Count - 1; i >= 0; i--)
                if (events[i].Time < time - 1e-5 && (!warningOnly || events[i].Warning))
                    return Math.Min(Duration, events[i].Time);
            return 0;
        }

        public double FirstWarning
        {
            get
            {
                foreach (var e in events)
                    if (e.Warning)
                        return Math.Min(Duration, e.Time);
                return 0;
            }
        }

        public string EventLabel(double time)
        {
            string text = "TEST START";
            foreach (var e in events)
            {
                if (e.Time > time + 1e-5)
                    break;
                text = e.Label;
            }

            return text;
        }
    }
}
