// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        public void StartTrial()
        {
            Array.Clear(Depth, 0, Depth.Length);
            Array.Clear(QX, 0, QX.Length);
            Array.Clear(QZ, 0, QZ.Length);
            Array.Clear(VX, 0, VX.Length);
            Array.Clear(VZ, 0, VZ.Length);
            Time = Added = Drained = Initial = Eroded = GoalHold = 0;
            AnimalsPassed = AnimalsFailed = FishCorrect = FishWrong = 0;
            AnimalActive = Won = Ended = false;
            Failure = "";
            AnimalX = 8;
            nextFish = 14;
            animalNext = 72;
            rng = 7281;
            Fish.Clear();
            Array.Clear(ErosionRate, 0, ErosionRate.Length);
            Array.Clear(ErosionLoss, 0, ErosionLoss.Length);
            foreach (var p in Segments)
            {
                p.Damage = p.Ratio = p.WaterDemand = p.AnimalDemand = p.EstimatedCapacity = 0;
                p.Broken = false;
            }

            SyncEdges();
        }

        double Proposed(int a, int b, double wall, double leak, double old, double dt)
        {
            double baseSill = Math.Max(Bed(a % W, a / W), Bed(b % W, b / W));
            double ha = Bed(a % W, a / W) + Depth[a], hb = Bed(b % W, b / W) + Depth[b];
            double bare = Math.Max(0, ha - baseSill) - Math.Max(0, hb - baseSill), over = Math.Max(0, ha - baseSill - wall) - Math.Max(0, hb - baseSill - wall);
            double target = 4.5 * (wall > 0 ? leak * bare + (1 - leak) * over : bare);
            // Damped flux memory, a gameplay approximation of inertia, not full SWE momentum.
            double q = old + (target - old) * (1 - Math.Exp(-dt / .12));
            if (q * target < 0 || Math.Abs(target) < 1e-8)
                q = target;
            return q;
        }

        public void WaterStep(double dt, bool open = true)
        {
            if (dt <= 0 || dt > .1 || double.IsNaN(dt))
                throw new ArgumentOutOfRangeException("dt");
            Array.Clear(outScale, 0, outScale.Length);
            Array.Clear(delta, 0, delta.Length);
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W - 1; x++)
                {
                    int a = I(x, z), e = z * (W - 1) + x;
                    QX[e] = Proposed(a, a + 1, crestX[e], leakX[e], QX[e], dt);
                    outScale[QX[e] >= 0 ? a : a + 1] += Math.Abs(QX[e]) * dt;
                }

            for (int z = 0; z < H - 1; z++)
                for (int x = 0; x < W; x++)
                {
                    int a = I(x, z), e = z * W + x;
                    QZ[e] = Proposed(a, a + W, crestZ[e], leakZ[e], QZ[e], dt);
                    outScale[QZ[e] >= 0 ? a : a + W] += Math.Abs(QZ[e]) * dt;
                }

            for (int i = 0; i < outScale.Length; i++)
                outScale[i] = outScale[i] > 0 ? Math.Min(1, Depth[i] / outScale[i]) : 1;
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W - 1; x++)
                {
                    int a = I(x, z), e = z * (W - 1) + x;
                    QX[e] *= outScale[QX[e] >= 0 ? a : a + 1];
                    double d = QX[e] * dt;
                    delta[a] -= d;
                    delta[a + 1] += d;
                }

            for (int z = 0; z < H - 1; z++)
                for (int x = 0; x < W; x++)
                {
                    int a = I(x, z), e = z * W + x;
                    QZ[e] *= outScale[QZ[e] >= 0 ? a : a + W];
                    double d = QZ[e] * dt;
                    delta[a] -= d;
                    delta[a + W] += d;
                }

            for (int i = 0; i < Depth.Length; i++)
                Depth[i] = Math.Max(0, Depth[i] + delta[i]);
            if (open)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, H - 1);
                    double d = Math.Min(Depth[i], 4.5 * Depth[i] * dt);
                    Depth[i] -= d;
                    Drained += d;
                }

            for (int z = 0; z < H; z++)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, z);
                    double vx = (x > 0 ? QX[z * (W - 1) + x - 1] : 0) + (x < W - 1 ? QX[z * (W - 1) + x] : 0), vz = (z > 0 ? QZ[(z - 1) * W + x] : 0) + (z < H - 1 ? QZ[z * W + x] : 0);
                    VX[i] = Math.Max(-3, Math.Min(3, vx / (2 * Math.Max(.08, Depth[i]))));
                    VZ[i] = Math.Max(-3, Math.Min(3, vz / (2 * Math.Max(.08, Depth[i]))));
                }
        }
    }
}
