// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        public double Sample(double x, double z)
        {
            x = Math.Max(0, Math.Min(W - 1.001, x));
            z = Math.Max(0, Math.Min(H - 1.001, z));
            int a = (int)x, b = (int)z;
            double u = x - a, v = z - b;
            // Same two triangles as the visible heightfield, not bilinear mismatch.
            double h00 = Bed(a, b), h10 = Bed(a + 1, b), h01 = Bed(a, b + 1), h11 = Bed(a + 1, b + 1);
            return u + v <= 1 ? h00 + u * (h10 - h00) + v * (h01 - h00) : h11 + (1 - u) * (h01 - h11) + (1 - v) * (h10 - h11);
        }

        public Soil Kind(int i)
        {
            if (Fill[i] > .015)
                return Soil.LooseMud;
            double d = Original[i] - Ground[i];
            return d < .20 ? Soil.Topsoil : d < .48 ? Soil.Dirt : d < .73 ? Soil.LooseMud : d < 1.03 ? Soil.SandGravel : d < 1.44 ? Soil.Clay : Soil.Bedrock;
        }

        public double Brush(double x, double z, bool add, double dt)
        {
            double changed = 0;
            for (int zz = Math.Max(1, (int)z - 2); zz <= Math.Min(H - 2, (int)z + 2); zz++)
                for (int xx = Math.Max(1, (int)x - 2); xx <= Math.Min(W - 2, (int)x + 2); xx++)
                {
                    int i = I(xx, zz);
                    double d = Math.Sqrt((xx - x) * (xx - x) + (zz - z) * (zz - z));
                    if (d > 1.6 || Rocks[i])
                        continue;
                    double amount = (1 - d / 1.6) * dt * .65;
                    if (add)
                    {
                        amount = Math.Min(amount, Math.Min(MudSupply, Math.Max(0, 1.8 - Fill[i])));
                        Fill[i] += amount;
                        MudSupply -= amount;
                    }
                    else
                    {
                        double soft = 1.0 / digResistance[(int)Kind(i)];
                        amount *= soft;
                        double f = Math.Min(Fill[i], amount);
                        Fill[i] -= f;
                        double cut = Math.Min(Math.Max(0, Ground[i] - Bedrock[i]), amount - f);
                        Ground[i] -= cut;
                        amount = f + cut;
                        MudSupply += amount * .5;
                    }

                    changed += amount;
                }

            SyncEdges();
            return changed;
        }

        public bool PlaceRock(int x, int z)
        {
            if (!Inside(x, z) || x == 0 || z == 0 || x >= W - 1 || z >= H - 1 || Rocks[I(x, z)] || Budget < 7)
                return false;
            foreach (var p in Segments)
                for (int k = 0; k < p.Length; k++)
                    if (x == p.X + (p.AlongX ? k : 0) && z == p.Z + (p.AlongX ? 0 : k))
                        return false;
            Rocks[I(x, z)] = true;
            Budget -= 7;
            SyncEdges();
            return true;
        }

        public bool RemoveRock(int x, int z)
        {
            if (!Inside(x, z) || !Rocks[I(x, z)] || Permanent[I(x, z)])
                return false;
            Rocks[I(x, z)] = false;
            Budget += 7;
            SyncEdges();
            return true;
        }

        public void ErodeStep(double dt)
        {
            Array.Clear(ErosionRate, 0, ErosionRate.Length);
            for (int z = 1; z < H - 1; z++)
                for (int x = 1; x < W - 1; x++)
                {
                    int i = I(x, z);
                    if (Rocks[i] || Depth[i] < .035)
                        continue;
                    int kind = (int)Kind(i);
                    double speed2 = VX[i] * VX[i] + VZ[i] * VZ[i];
                    double stress = 6 * speed2;
                    double excess = Math.Max(0, stress - wearThreshold[kind]);
                    double wear = Math.Min(.006, dt * wearRate[kind] * excess);
                    double f = Math.Min(Fill[i], wear);
                    Fill[i] -= f;
                    double cut = Math.Min(Math.Max(0, Ground[i] - Bedrock[i]), wear - f);
                    Ground[i] -= cut;
                    Eroded += f + cut;
                    ErosionLoss[i] += f + cut;
                    ErosionRate[i] = dt > 0 ? (f + cut) / dt : 0;
                }
        }
    }
}
