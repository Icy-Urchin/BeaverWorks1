// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        public static double PressureKN(double depth, double height)
        {
            double wet = Math.Min(Math.Max(0, depth), height);
            return 9.81 * (Math.Max(0, depth) * wet - wet * wet * .5);
        }

        public void LoadStep(double dt)
        {
            bool changed = false;
            foreach (var p in Segments)
            {
                if (p.Broken)
                    continue;
                var r = Materials[(int)p.Material];
                double foundation = Foundation(p), bottom = Bottom(p), force = 0, velocity = 0;
                for (int k = 0; k < p.Length; k++)
                {
                    int x = p.X + (p.AlongX ? k : 0), z = p.Z + (p.AlongX ? 0 : k);
                    int a = I(x - (p.AlongX ? 0 : 1), z - (p.AlongX ? 1 : 0)), b = I(x, z);
                    double da = Math.Max(0, Bed(a % W, a / W) + Depth[a] - bottom), db = Math.Max(0, Bed(b % W, b / W) + Depth[b] - bottom);
                    force += Math.Abs(PressureKN(da, r.Height) - PressureKN(db, r.Height));
                    velocity += Math.Max(VX[a] * VX[a] + VZ[a] * VZ[a], VX[b] * VX[b] + VZ[b] * VZ[b]);
                }

                force += velocity * .03;
                foreach (var s in Segments)
                    if (!s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer > p.Layer)
                        force += Materials[(int)s.Material].Mass * 9.81 * s.Length * .12;
                int ex = p.X + (p.AlongX ? p.Length : 0), ez = p.Z + (p.AlongX ? 0 : p.Length);
                bool left = Bed(Math.Max(0, p.X - (p.AlongX ? 1 : 0)), Math.Max(0, p.Z - (p.AlongX ? 0 : 1))) > .9;
                bool right = Bed(Math.Min(W - 1, ex), Math.Min(H - 1, ez)) > .9;
                foreach (var s in Segments)
                    if (s != p && !s.Broken && s.AlongX == p.AlongX && s.Layer == p.Layer)
                    {
                        if (p.AlongX && s.Z == p.Z)
                        {
                            left |= s.X + s.Length == p.X;
                            right |= p.X + p.Length == s.X;
                        }

                        if (!p.AlongX && s.X == p.X)
                        {
                            left |= s.Z + s.Length == p.Z;
                            right |= p.Z + p.Length == s.Z;
                        }
                    }

                double support = (left ? 1.22 : 1) * (right ? 1.22 : 1);
                if (foundation < p.Foundation - .2)
                    support *= .55;
                double animal = AnimalActive && p.AlongX && p.Z == Rule.CrossRow && AnimalX >= p.X && AnimalX <= p.X + p.Length ? Rule.AnimalMass * 9.81 : 0;
                // Weight contributes simplified frictional resistance; span and scour reduce capacity.
                double capacity = (r.Capacity + r.Mass * 9.81 * .4) * p.Length * support / (1 + .12 * Math.Max(0, p.Length - 2) * Math.Max(0, p.Length - 2));
                p.WaterDemand = force;
                p.AnimalDemand = animal * 3;
                p.EstimatedCapacity = capacity;
                p.Ratio = (force + animal * 3) / Math.Max(.1, capacity);
                p.Damage = Math.Max(0, p.Damage + dt * (p.Ratio > 1 ? (p.Ratio - 1) * .11 : -.025));
                if (p.Damage >= 1)
                {
                    p.Broken = true;
                    changed = true;
                }
            }

            // A failed supporting layer cannot leave upper bundles hovering intact.
            if (changed)
            {
                foreach (var p in Segments)
                    if (!p.Broken && Segments.Exists(s => s.Broken && s.AlongX == p.AlongX && s.X == p.X && s.Z == p.Z && s.Length == p.Length && s.Layer < p.Layer))
                        p.Broken = true;
                SyncEdges();
            }
        }
    }
}
