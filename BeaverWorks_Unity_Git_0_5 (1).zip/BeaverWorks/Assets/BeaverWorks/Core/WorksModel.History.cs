// Same authoritative WorksModel class, split by responsibility. No Unity dependency.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public sealed partial class WorksModel
    {
        public DesignState Capture()
        {
            var s = new DesignState
            {
                Ground = (double[])Ground.Clone(),
                Fill = (double[])Fill.Clone(),
                Rocks = (bool[])Rocks.Clone(),
                Budget = Budget,
                Mud = MudSupply,
                NextId = nextId,
                Segments = new List<DamSegment>()
            };
            foreach (var p in Segments)
                s.Segments.Add(p.Copy());
            return s;
        }

        public void Restore(DesignState s)
        {
            Ground = (double[])s.Ground.Clone();
            Fill = (double[])s.Fill.Clone();
            Array.Copy(s.Rocks, Rocks, Rocks.Length);
            Budget = s.Budget;
            MudSupply = s.Mud;
            nextId = s.NextId;
            Segments.Clear();
            foreach (var p in s.Segments)
                Segments.Add(p.Copy());
            SyncEdges();
        }

        public void Commit(DesignState s)
        {
            if (History.Count >= 32)
            {
                var a = History.ToArray();
                History.Clear();
                for (int i = 30; i >= 0; i--)
                    History.Push(a[i]);
            }

            History.Push(s);
        }

        public bool Undo()
        {
            if (History.Count == 0)
                return false;
            Restore(History.Pop());
            return true;
        }
    }
}
