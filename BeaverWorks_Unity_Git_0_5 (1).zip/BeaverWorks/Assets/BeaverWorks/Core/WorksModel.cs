// Original educational prototype, not engineering or ecological prediction.
// Unity-independent model: one unit cell area, fixed timesteps, deterministic trials.
using System;
using System.Collections.Generic;

namespace BeaverWorksV3
{
    public enum DamMaterial
    {
        Brushwood,
        Timber,
        PackedMud,
        Stone,
        FishPass
    }

    public enum Soil
    {
        Topsoil,
        Dirt,
        LooseMud,
        SandGravel,
        Clay,
        Bedrock
    }

    public sealed class MaterialRule
    {
        public string Name;
        public int Cost;
        public double Height, Leak, Capacity, Mass;
        public bool Walkable, Fish;
        public MaterialRule(string n, int c, double h, double leak, double cap, double mass, bool walk, bool fish = false)
        {
            Name = n;
            Cost = c;
            Height = h;
            Leak = leak;
            Capacity = cap;
            Mass = mass;
            Walkable = walk;
            Fish = fish;
        }
    }

    public sealed class DamSegment
    {
        public int Id, X, Z, Length, Layer;
        public bool AlongX = true;
        public DamMaterial Material;
        public double Foundation, Damage, Ratio, WaterDemand, AnimalDemand, EstimatedCapacity;
        public bool Broken;
        public DamSegment Copy()
        {
            return (DamSegment)MemberwiseClone();
        }
    }

    public sealed class FishParcel
    {
        public int X, Z;
        public bool Finished;
        public double Wait;
    }

    public sealed class DesignState
    {
        internal double[] Ground, Fill;
        internal bool[] Rocks;
        internal List<DamSegment> Segments;
        internal int Budget, NextId;
        internal double Mud;
    }

    public sealed class LevelRule
    {
        public string Name, Brief;
        public int Budget, AnimalCount, FishGoal, CrossRow;
        public double PondGoal, Duration, Source, AnimalMass;
        public bool Fork, Surge;
        public LevelRule(string name, string brief, int budget, int animals, int fish, int row, double pond, double source, double mass, bool fork = false, bool surge = false)
        {
            Name = name;
            Brief = brief;
            Budget = budget;
            AnimalCount = animals;
            FishGoal = fish;
            CrossRow = row;
            PondGoal = pond;
            Source = source;
            AnimalMass = mass;
            Fork = fork;
            Surge = surge;
            Duration = surge ? 360 : 190;
        }
    }

    public sealed partial class WorksModel
    {
        public const int W = 24, H = 36;
        public const double Dt = 1.0 / 30;
        static readonly int[] fishDX =
        {
            -1,
            1,
            0,
            0
        }, fishDZ =
        {
            0,
            0,
            -1,
            1
        };
        readonly double[] fishFlows = new double[4];
        static readonly double[] digResistance =
        {
            1.0,
            1.5,
            1.1,
            1.3,
            3.0,
            999.0
        }, wearThreshold =
        {
            2.0,
            4.0,
            1.2,
            .7,
            12.0,
            double.MaxValue
        }, wearRate =
        {
            .00010,
            .00007,
            .00014,
            .00018,
            .000025,
            0.0
        };
        public static readonly MaterialRule[] Materials =
        {
            new MaterialRule("Brushwood", 1, .75, .075, 3.2, .045, false),
            new MaterialRule("Timber", 3, .90, .012, 16, .12, true),
            new MaterialRule("Packed mud", 2, .80, .003, 6, .35, false),
            new MaterialRule("Stone core", 5, 1.05, .008, 34, .7, true),
            new MaterialRule("Fish-pass weave", 4, .60, .65, 10, .09, true, true)
        };
        public static readonly LevelRule[] Levels =
        {
            new LevelRule("Tutorial · First pond", "Draw two 3-unit TIMBER segments across the gold line. Test water; one rabbit crosses the dry crest.", 90, 1, 0, 23, .35, 3.0, .015),
            new LevelRule("1 · Woodland crossing", "Make a pond and a continuous dry dam crest for two rabbits. Keep long segments short or supported.", 66, 2, 0, 23, .45, 3.4, .025),
            new LevelRule("2 · Nursery fork", "Block the main drain at the gold line; send at least four fish into the marked nursery outlet (screen-left). A rabbit also needs a dry crossing.", 100, 1, 4, 20, .35, 3.6, .025, true),
            new LevelRule("3 · Spring surge", "Route four fish to the marked nursery (maximum three wrong exits) and carry three heavier deer through a spring-flow pulse. Stone and bank reinforcement help resist load and scour.", 138, 3, 4, 20, .45, 4.2, .18, true, true)
        };
        public readonly int Level;
        public LevelRule Rule
        {
            get
            {
                return Levels[Level];
            }
        }

        public double[] Ground = new double[W * H], Fill = new double[W * H], Original = new double[W * H], Bedrock = new double[W * H], Depth = new double[W * H];
        public readonly bool[] Rocks = new bool[W * H], Permanent = new bool[W * H];
        public readonly List<DamSegment> Segments = new List<DamSegment>();
        public readonly List<FishParcel> Fish = new List<FishParcel>();
        public readonly Stack<DesignState> History = new Stack<DesignState>();
        // Signed volume rates in cubic game metres per second, not velocity.
        public readonly double[] QX = new double[(W - 1) * H], QZ = new double[W * (H - 1)], VX = new double[W * H], VZ = new double[W * H];
        public readonly double[] ErosionRate = new double[W * H], ErosionLoss = new double[W * H];
        readonly double[] outScale = new double[W * H], delta = new double[W * H];
        readonly double[] crestX = new double[(W - 1) * H], crestZ = new double[W * (H - 1)], leakX = new double[(W - 1) * H], leakZ = new double[W * (H - 1)];
        readonly bool[] passX = new bool[(W - 1) * H], passZ = new bool[W * (H - 1)];
        int nextId = 1;
        uint rng = 7281;
        double nextFish = 14, animalNext = 72;
        public int Budget;
        public double MudSupply = 40, Time, Added, Drained, Initial, Eroded, GoalHold, AnimalX = 8;
        public int FishCorrect, FishWrong, AnimalsPassed, AnimalsFailed;
        public bool AnimalActive, Won, Ended;
        public bool Erosion = true;
        public string Failure = "";
        // Build one of four sample heightfield levels. Original is the unedited baseline.
        public WorksModel(int level)
        {
            Level = Math.Max(0, Math.Min(3, level));
            Budget = Rule.Budget;
            for (int z = 0; z < H; z++)
                for (int x = 0; x < W; x++)
                {
                    int i = I(x, z);
                    double slope = (H - 1 - z) * .018;
                    bool main = x >= 9 && x <= 14;
                    bool fork = Rule.Fork && ((x >= 15 && x <= 20 && z >= 12 && z <= 18) || (x >= 18 && x <= 20 && z >= 12));
                    Ground[i] = (main || fork ? slope : 1.65 + slope);
                    Original[i] = Ground[i];
                    Bedrock[i] = Ground[i] - 1.45;
                }

            // In the fork levels, a divider stops fish shortcuts below the junction.
            if (Rule.Fork)
                for (int z = 19; z < H; z++)
                    for (int x = 15; x < 18; x++)
                        Ground[I(x, z)] = Original[I(x, z)] = 1.8 + (H - 1 - z) * .018;
            // Natural boulders on banks are simulation obstacles as well as visual scenery.
            foreach (int i in new[]
            {
                I(7, 15),
                I(16, 25),
                I(6, 29)
            }

            )
            {
                Rocks[i] = Permanent[i] = true;
            }

            SyncEdges();
        }

        public int I(int x, int z)
        {
            return z * W + x;
        }

        public bool Inside(int x, int z)
        {
            return x >= 0 && x < W && z >= 0 && z < H;
        }

        public double Bed(int x, int z)
        {
            int i = I(x, z);
            return Ground[i] + Fill[i] + (Rocks[i] ? 1.15 : 0);
        }

        // Read the height on the same two triangles used by the visible terrain.
        // Copy the construction state before an edit, so Undo can restore it.
        // Validate length, budget, overlap, rocks and stack height before spending materials.
        public double Volume
        {
            get
            {
                double n = 0;
                foreach (double d in Depth)
                    n += d;
                return n;
            }
        }

        public double MassError
        {
            get
            {
                return Volume - Initial - Added + Drained;
            }
        }

        public double PondDepth
        {
            get
            {
                double s = 0;
                int n = 0;
                for (int z = 10; z < Rule.CrossRow; z++)
                    for (int x = 9; x <= 14; x++)
                    {
                        s += Depth[I(x, z)];
                        n++;
                    }

                return s / n;
            }
        }

        public double MaxLoad
        {
            get
            {
                double s = 0;
                foreach (var p in Segments)
                    if (!p.Broken)
                        s = Math.Max(s, p.Ratio);
                return s;
            }
        }

        public int BrokenCount
        {
            get
            {
                int n = 0;
                foreach (var p in Segments)
                    if (p.Broken)
                        n++;
                return n;
            }
        }

        // Transfer water between neighbor columns. Outflow scaling prevents negative water.
        // Estimate water, stack and animal demand. Sustained overload accumulates damage.
        // Remove eligible wet ground according to velocity and soil resistance; no sediment transport.
        // Only allow adjacent wet-cell moves through an opening or above an overtopped crest.
        // One fixed simulation step: supply water, flow, erode, load structures, move fish/animals, score.
        public void Tick(double dt = Dt)
        {
            if (dt <= 0 || dt > .1 || double.IsNaN(dt))
                throw new ArgumentOutOfRangeException("dt");
            if (Won || Ended)
                return;
            Time += dt;
            double source = Rule.Source * (Rule.Surge && Time >= 85 && Time < 115 ? 1.6 : 1);
            for (int x = 9; x <= 14; x++)
            {
                double volume = source * dt / 6;
                Depth[I(x, 0)] += volume;
                Added += volume;
            }

            WaterStep(dt);
            if (Erosion)
                ErodeStep(dt);
            else
                Array.Clear(ErosionRate, 0, ErosionRate.Length);
            LoadStep(dt);
            FishStep(dt);
            AnimalStep(dt);
            bool goals = PondDepth >= Rule.PondGoal && AnimalsPassed >= Rule.AnimalCount && FishCorrect >= Rule.FishGoal && FishWrong <= (Level == 3 ? 3 : 0) && AnimalsFailed == 0 && BrokenCount == 0;
            GoalHold = goals ? GoalHold + dt : 0;
            if (GoalHold >= 3)
                Won = true;
            if (Time >= Rule.Duration)
            {
                Ended = true;
                if (!Won && Failure == "")
                    Failure = "Trial ended: revise depth, crest continuity, material load or fish route.";
            }
        }
    // Construct a checked teaching solution; this does not auto-complete tutorial actions.
    }
}
