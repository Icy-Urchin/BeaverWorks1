using System;
using System.Text;

namespace BeaverWorksV3
{
    public static class WorksChecks
    {
        public static string Run()
        {
            int count = 0;
            var b = new StringBuilder();
            Action<bool, string> check = (ok, name) =>
            {
                if (!ok)
                    throw new Exception("FAIL: " + name);
                count++;
                b.AppendLine("PASS: " + name);
            };
            var m = new WorksModel(0);
            double budget = m.Budget;
            var before = m.Capture();
            check(m.Place(new DamSegment { X = 9, Z = 23, Length = 3, Material = DamMaterial.Timber }), "3-unit timber segment placed");
            check(m.Budget == budget - 9, "Budget based on length and material");
            m.Commit(before);
            check(m.Undo() && m.Segments.Count == 0 && m.Budget == budget, "Undo restores segment and budget");
            string why;
            check(!m.CanPlace(new DamSegment { X = 9, Z = 23, Length = 7 }, out why), "Overlength segment rejected");
            check(!m.CanPlace(new DamSegment { X = -1, Z = 23, Length = 3 }, out why), "Out-of-bounds segment rejected");
            m.ExampleDesign();
            check(m.Segments.Count == 2, "Tutorial uses two adjoining segments");
            check(!m.Place(new DamSegment { X = 10, Z = 23, Length = 3 }), "Partial overlapping segment rejected");
            check(m.Place(new DamSegment { X = 9, Z = 23, Length = 3, Material = DamMaterial.Timber }), "Identical endpoints stack");
            check(!m.Remove(m.Segments[0].Id), "Supporting layer cannot be removed");
            m = new WorksModel(0);
            int node = m.I(5, 10);
            double g = m.Ground[node];
            before = m.Capture();
            check(m.Brush(5, 10, true, .3) > 0 && m.Fill[node] > 0, "Mud brush raises height");
            m.Restore(before);
            check(m.Fill[node] == 0, "Cancelled stroke restores fill");
            m.Brush(5, 10, false, .5);
            check(m.Ground[node] < g, "Dig changes terrain");
            for (int j = 0; j < 400; j++)
                m.Brush(5, 10, false, .5);
            check(m.Ground[node] >= m.Bedrock[node] - 1e-9, "Dig stops at bedrock");
            check(m.PlaceRock(5, 11), "Rock placement succeeds");
            check(!m.PlaceRock(5, 11), "Duplicate rock rejected");
            m = new WorksModel(0);
            for (int i = 0; i < m.Depth.Length; i++)
                m.Depth[i] = .2 + (i % 5) * .05;
            m.Initial = m.Volume;
            for (int j = 0; j < 300; j++)
                m.WaterStep(WorksModel.Dt, false);
            check(Math.Abs(m.MassError) < 1e-8, "Closed water volume conserved");
            bool nonnegative = true;
            foreach (var d in m.Depth)
                nonnegative &= d >= 0 && !double.IsNaN(d) && !double.IsInfinity(d);
            check(nonnegative, "Water finite and nonnegative");
            check(Math.Abs(WorksModel.PressureKN(1, 1) - 4.905) < 1e-8, "Integrated hydrostatic force reference");
            check(WorksModel.PressureKN(2, 2) > WorksModel.PressureKN(1, 1) * 3.99, "Pressure load grows with squared depth");
            for (int level = 0; level < 4; level++)
            {
                m = new WorksModel(level);
                m.ExampleDesign();
                m.StartTrial();
                while (!m.Won && !m.Ended)
                    m.Tick();
                b.AppendLine("TRIAL " + level + ": win=" + m.Won + " time=" + m.Time.ToString("F1") + " pond=" + m.PondDepth.ToString("F3") + " fish=" + m.FishCorrect + " wrong=" + m.FishWrong + " animals=" + m.AnimalsPassed + " failed=" + m.AnimalsFailed + " broken=" + m.BrokenCount + " maxLoad=" + m.MaxLoad.ToString("F2") + " eroded=" + m.Eroded.ToString("F3"));
                Console.WriteLine("Trial " + level + ": " + m.Won + " fish=" + m.FishCorrect + " animals=" + m.AnimalsPassed + " failure=" + m.Failure);
                check(Math.Abs(m.MassError) < 1e-7, "Trial " + level + " volume ledger");
                check(m.Won, "Example solution level " + level + " / " + m.Failure);
            }

            m = new WorksModel(1);
            m.StartTrial();
            while (!m.Ended && !m.Won)
                m.Tick();
            check(!m.Won && m.AnimalsFailed > 0, "Empty dam cannot pass animal challenge");
            m = new WorksModel(2);
            m.Place(new DamSegment { X = 9, Z = 4, Length = 6, Material = DamMaterial.Timber });
            m.Depth[m.I(10, 3)] = m.Depth[m.I(10, 4)] = .3;
            check(!m.FishEdge(10, 3, 10, 4), "Solid submerged dam blocks fish passage");
            m = new WorksModel(2);
            m.Place(new DamSegment { X = 9, Z = 4, Length = 6, Material = DamMaterial.FishPass });
            m.Depth[m.I(10, 3)] = m.Depth[m.I(10, 4)] = .3;
            check(m.FishEdge(10, 3, 10, 4), "Fish weave admits wet fish passage");
            m = new WorksModel(0);
            m.Place(new DamSegment { X = 9, Z = 23, Length = 6, Material = DamMaterial.Brushwood });
            for (int z = 0; z < 23; z++)
                for (int x = 9; x <= 14; x++)
                    m.Depth[m.I(x, z)] = 3;
            for (int i = 0; i < 3000; i++)
                m.LoadStep(WorksModel.Dt);
            check(m.BrokenCount > 0, "Overloaded weak long segment breaks");
            m = new WorksModel(0);
            int a = m.I(10, 10), c = m.I(11, 10);
            m.Ground[a] = m.Original[a] - .8;
            m.Ground[c] = m.Original[c] - 1.2;
            m.Depth[a] = m.Depth[c] = .5;
            m.VX[a] = m.VX[c] = 1;
            double ga = m.Ground[a], gc = m.Ground[c];
            m.ErodeStep(1);
            check(m.Ground[a] < ga && m.Ground[c] == gc, "Fast water wears sand while clay resists below threshold");
            m = new WorksModel(0);
            m.PlaceRock(5, 5);
            check(m.RemoveRock(5, 5) && m.Budget == m.Rule.Budget, "Player rock removal refunds budget");
            check(!m.RemoveRock(7, 15), "Natural boulder cannot be removed");
            m.ExampleDesign();
            m.Segments[0].Damage = 1.1;
            m.StartTrial();
            check(m.Segments[0].Damage == 0 && !m.Segments[0].Broken, "Trial reset clears damage");
            m = new WorksModel(3);
            m.Place(new DamSegment { X = 9, Z = 20, Length = 3, Material = DamMaterial.Stone });
            m.Place(new DamSegment { X = 9, Z = 20, Length = 3, Material = DamMaterial.Stone });
            check(m.Bottom(m.Segments[1]) > m.Bottom(m.Segments[0]), "Stack load uses different vertical heights");
            m = new WorksModel(0);
            m.MudSupply = 0;
            check(m.Brush(5, 5, true, .3) == 0, "Empty mud inventory cannot create terrain");
            bool rejected = false;
            try
            {
                m.WaterStep(.5);
            }
            catch (ArgumentOutOfRangeException)
            {
                rejected = true;
            }

            check(rejected, "Oversized water timestep rejected");
            b.AppendLine("TOTAL: " + count + " actual C# checks. Unity runtime and device NOT tested.");
            return b.ToString();
        }
    }
}
