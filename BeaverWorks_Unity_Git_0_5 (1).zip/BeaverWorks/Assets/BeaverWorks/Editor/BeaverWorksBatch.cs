using System;
using System.IO;
using BeaverWorksV3;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

// Local automation only. Unity must be installed and properly licensed.
public static class BeaverWorksBatch
{
    public static void RunCoreChecks()
    {
        Directory.CreateDirectory("Verification/Local");
        string report = WorksChecks.Run() + Environment.NewLine + WorksReplayChecks.Run();
        File.WriteAllText("Verification/Local/unity-core-report.txt", report);
        Debug.Log(report);
    }

    public static void BuildWindows()
    {
        const string scene = "Assets/BeaverWorks/Scenes/OverseerTutorial.unity";
        if (!File.Exists(scene))
            throw new InvalidOperationException("Run interactive project setup and save the scene first.");
        Directory.CreateDirectory("Builds/Windows");
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { scene }, locationPathName = "Builds/Windows/BeaverWorks.exe", target = BuildTarget.StandaloneWindows64, options = BuildOptions.Development });
        if (report.summary.result != BuildResult.Succeeded)
            throw new InvalidOperationException("Windows build failed: " + report.summary.result);
        Debug.Log("WINDOWS BUILD SUCCEEDED. Native iPad build remains a separate check.");
    }
}
