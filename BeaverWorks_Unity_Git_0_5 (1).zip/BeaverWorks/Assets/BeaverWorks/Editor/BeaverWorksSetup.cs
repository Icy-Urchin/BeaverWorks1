using System;
using System.IO;
using BeaverWorksV3;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

/// <summary>Editor-only setup. Never attach this script to an object.</summary>
public static class BeaverWorksSetup
{
    public const string EditorVersion = "6000.3.26f1";
    private const string ScenePath = "Assets/BeaverWorks/Scenes/OverseerTutorial.unity";
    [MenuItem("Beaver Works/1 - Configure Project and Create Tutorial")]
    public static void ConfigureAndCreate()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            return;
        // Changes apply only to the project currently open. Use the supplied fresh project.
        PlayerSettings.companyName = "SchoolProject";
        EditorSettings.serializationMode = SerializationMode.ForceText;
        PlayerSettings.productName = "Beaver Works";
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
#if !ENABLE_INPUT_SYSTEM
        Debug.LogWarning("Set Edit > Project Settings > Player > Active Input Handling to Input System Package (New), then restart the Editor. Setup does not use unsupported settings APIs.");
#endif
        Directory.CreateDirectory("Assets/BeaverWorks/Settings");
        Directory.CreateDirectory("Assets/BeaverWorks/Scenes");
        AssetDatabase.Refresh();
        // Use documented URP editor factory, not hand-authored serialized pipeline YAML.
        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/BeaverWorks/Settings/BeaverPipeline.asset");
        if (pipeline == null)
        {
            var renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
            AssetDatabase.CreateAsset(renderer, "Assets/BeaverWorks/Settings/BeaverRenderer.asset");
            pipeline = UniversalRenderPipelineAsset.Create(renderer);
            pipeline.supportsHDR = false;
            pipeline.msaaSampleCount = 2;
            pipeline.renderScale = 1;
            AssetDatabase.CreateAsset(pipeline, "Assets/BeaverWorks/Settings/BeaverPipeline.asset");
        }

        GraphicsSettings.defaultRenderPipeline = pipeline;
        QualitySettings.renderPipeline = pipeline;
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var root = new GameObject("Beaver Works - Overseer Controller");
        var game = root.AddComponent<WorksGame>();
        game.SurfaceShader = Shader.Find("BeaverWorksV3/Surface");
        game.StartingLevel = 0;
        game.ErosionEnabled = true;
        game.TestSpeed = 3;
        if (game.SurfaceShader == null)
            throw new InvalidOperationException("Surface shader failed to import. Open Console and fix its FIRST error.");
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), ScenePath);
        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(ScenePath, true)
        };
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = root;
        Debug.Log("Setup finished. Run Beaver Works > 2 - Model and Replay Checks. Then Play in GAME view.");
    }

    [MenuItem("Beaver Works/2 - Model and Replay Checks")]
    public static void Check()
    {
        try
        {
            Debug.Log(WorksChecks.Run());
            Debug.Log(WorksReplayChecks.Run());
        }
        catch (Exception error)
        {
            Debug.LogException(error);
        }
    }

    [MenuItem("Beaver Works/3 - Environment Report")]
    public static void EnvironmentReport()
    {
        string report = "Beaver Works environment\nEditor: " + Application.unityVersion + " (target " + EditorVersion + ")\n";
        report += "Pipeline: " + (GraphicsSettings.defaultRenderPipeline == null ? "NONE - run setup" : GraphicsSettings.defaultRenderPipeline.name) + "\n";
        report += "Game scripts: Assets/BeaverWorks/Scripts\nDocs: outside Assets, in Documentation\n";
#if ENABLE_INPUT_SYSTEM
        report += "Input System backend: ENABLED\n";
#else
        report += "Input System backend: DISABLED - set Player > Active Input Handling to New and restart\n";
#endif
        foreach (var package in UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages())
            if (package.name == "com.unity.inputsystem" || package.name == "com.unity.ugui" || package.name == "com.unity.render-pipelines.universal" || package.name == "com.unity.test-framework")
                report += package.name + " = " + package.version + "\n";
        Debug.Log(report);
    }
}
