using UnityEngine;
using UnityEngine.EventSystems;

namespace BeaverWorksV3
{
    public sealed class WorksPointer : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler, IInitializePotentialDragHandler
    {
        public WorksGame Game;
        public void OnInitializePotentialDrag(PointerEventData e)
        {
            e.useDragThreshold = false;
        }

        public void OnPointerDown(PointerEventData e)
        {
            if (e.button == PointerEventData.InputButton.Left && Game != null)
                Game.PointerDown(e.pointerId, e.position);
        }

        public void OnDrag(PointerEventData e)
        {
            if (Game != null)
                Game.PointerDrag(e.pointerId, e.position);
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (Game != null)
                Game.PointerUp(e.pointerId, e.position);
        }
    }
}
