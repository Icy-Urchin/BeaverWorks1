using System.Collections.Generic;
using UnityEngine;

namespace BeaverWorksV3
{
    public sealed class WorksView : MonoBehaviour
    {
        public WorksModel Model;
        public Material SurfaceMaterial;
        Mesh land, water, section;
        readonly List<Vector3> v = new List<Vector3>();
        readonly List<int> t = new List<int>();
        readonly List<Color> c = new List<Color>();
        GameObject landObject, waterObject;
        public Transform GridRoot;
        public bool PressureVisible, ErosionVisible;
        Mesh erosionOverlay;
        readonly List<LineRenderer> gridLines = new List<LineRenderer>();
        readonly Vector3[] gridColumn = new Vector3[WorksModel.H], gridRow = new Vector3[WorksModel.W], gridTick = new Vector3[2];
        static readonly Color[] soilColors =
        {
            new Color(.38f, .49f, .23f),
            new Color(.55f, .36f, .21f),
            new Color(.32f, .24f, .17f),
            new Color(.75f, .65f, .43f),
            new Color(.52f, .35f, .27f),
            new Color(.37f, .40f, .42f)
        };
        public static Color SoilColor(Soil s)
        {
            return soilColors[(int)s];
        }

        GameObject MeshObject(string name, out Mesh mesh)
        {
            var go = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
            go.transform.SetParent(transform, false);
            mesh = new Mesh
            {
                name = name
            };
            mesh.MarkDynamic();
            go.GetComponent<MeshFilter>().sharedMesh = mesh;
            go.GetComponent<MeshRenderer>().sharedMaterial = SurfaceMaterial;
            go.GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return go;
        }

        public void Initialize(WorksModel m, Material material)
        {
            Model = m;
            SurfaceMaterial = material;
            landObject = MeshObject("Editable layered ground", out land);
            waterObject = MeshObject("Water volume surface", out water);
            MeshObject("Exposed soil cutaway", out section);
            MeshObject("Actual erosion diagnostic", out erosionOverlay);
            RefreshGround();
            RefreshWater();
        }

        void Tri(Vector3 a, Vector3 b, Vector3 d, Color color)
        {
            int i = v.Count;
            v.Add(a);
            v.Add(b);
            v.Add(d);
            c.Add(color);
            c.Add(color);
            c.Add(color);
            t.Add(i);
            t.Add(i + 1);
            t.Add(i + 2);
        }

        void Apply(Mesh mesh)
        {
            mesh.Clear();
            mesh.SetVertices(v);
            mesh.SetTriangles(t, 0);
            mesh.SetColors(c);
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
        }

        Vector3 P(int x, int z)
        {
            return new Vector3(x, (float)Model.Bed(x, z), z);
        }

        public void RefreshGround()
        {
            v.Clear();
            t.Clear();
            c.Clear();
            for (int z = 0; z < WorksModel.H - 1; z++)
                for (int x = 0; x < WorksModel.W - 1; x++)
                {
                    Color color = SoilColor(Model.Kind(Model.I(x, z)));
                    if (Model.Rocks[Model.I(x, z)])
                        color = SoilColor(Soil.Bedrock);
                    color *= ((x * 7 + z * 13) % 6) * .012f + .94f;
                    if (ErosionVisible)
                        color = Color.Lerp(new Color(.30f, .37f, .30f), new Color(1f, .32f, .08f), Mathf.Clamp01((float)Model.ErosionRate[Model.I(x, z)] / .01f));
                    Tri(P(x, z), P(x, z + 1), P(x + 1, z), color);
                    Tri(P(x + 1, z), P(x, z + 1), P(x + 1, z + 1), color);
                }

            Apply(land);
            v.Clear();
            t.Clear();
            c.Clear();
            for (int x = 0; x < WorksModel.W - 1; x++)
                for (int k = 0; k < 6; k++)
                {
                    float top = (float)Model.Original[Model.I(x, WorksModel.H - 1)] - k * .29f, bottom = top - .29f;
                    float surface = (float)Model.Bed(x, WorksModel.H - 1);
                    top = Mathf.Min(top, surface);
                    if (top <= bottom)
                        continue;
                    Color color = SoilColor((Soil)k);
                    Tri(new Vector3(x, top, WorksModel.H - 1), new Vector3(x + 1, top, WorksModel.H - 1), new Vector3(x, bottom, WorksModel.H - 1), color);
                    Tri(new Vector3(x + 1, top, WorksModel.H - 1), new Vector3(x + 1, bottom, WorksModel.H - 1), new Vector3(x, bottom, WorksModel.H - 1), color);
                }

            Apply(section);
        }

        // Draw depth-dependent water and diagnostics. This does not compute the water physics.
        public void RefreshWater()
        {
            v.Clear();
            t.Clear();
            c.Clear();
            for (int z = 0; z < WorksModel.H - 1; z++)
                for (int x = 0; x < WorksModel.W - 1; x++)
                {
                    int i = Model.I(x, z);
                    double depth = Model.Depth[i];
                    if (depth < .014)
                        continue;
                    float speed = (float)System.Math.Sqrt(Model.VX[i] * Model.VX[i] + Model.VZ[i] * Model.VZ[i]);
                    Color color = Color.Lerp(new Color(.22f, .65f, .63f), new Color(.09f, .35f, .48f), Mathf.Clamp01((float)depth / 1.8f));
                    color = Color.Lerp(color, new Color(.72f, .53f, .32f), Mathf.Clamp01((float)Model.Eroded / 70) * .5f);
                    color = Color.Lerp(color, new Color(.62f, .83f, .74f), speed * .055f);
                    if (PressureVisible)
                    {
                        float ratio = Mathf.Clamp01((float)(9.81 * depth) / 30f);
                        color = ratio < .5f ? Color.Lerp(new Color(.14f, .42f, .85f), new Color(.98f, .87f, .23f), ratio * 2) : Color.Lerp(new Color(.98f, .87f, .23f), new Color(.91f, .12f, .09f), (ratio - .5f) * 2);
                    }

                    Vector3 a = new Vector3(x, (float)(Model.Bed(x, z) + depth) + .025f, z), b = new Vector3(x, (float)(Model.Bed(x, z + 1) + Model.Depth[i + WorksModel.W]) + .025f, z + 1), d = new Vector3(x + 1, (float)(Model.Bed(x + 1, z) + Model.Depth[i + 1]) + .025f, z), e = new Vector3(x + 1, (float)(Model.Bed(x + 1, z + 1) + Model.Depth[i + WorksModel.W + 1]) + .025f, z + 1);
                    Tri(a, b, d, color);
                    Tri(d, b, e, color);
                    if (speed > .025f && (x + z) % 3 == 0)
                    {
                        Vector3 mid = (a + e) * .5f;
                        mid.y += .045f;
                        Vector3 direction = new Vector3((float)Model.VX[i], 0, (float)Model.VZ[i]).normalized;
                        Vector3 side = Vector3.Cross(Vector3.up, direction) * .07f;
                        Tri(mid + direction * .28f, mid - direction * .13f + side, mid - direction * .13f - side, new Color(.78f, .90f, .82f));
                    }
                }

            Apply(water);
            RefreshWearOverlay();
        }

        void RefreshWearOverlay()
        {
            v.Clear();
            t.Clear();
            c.Clear();
            if (ErosionVisible)
                for (int z = 0; z < WorksModel.H - 1; z++)
                    for (int x = 0; x < WorksModel.W - 1; x++)
                    {
                        int i = Model.I(x, z);
                        float rate = (float)Model.ErosionRate[i], loss = (float)Model.ErosionLoss[i];
                        if (rate <= .000001f && loss <= .001f)
                            continue;
                        // The diagnostic sits just above water so submerged scour remains visible.
                        float y = Mathf.Max((float)Model.Bed(x, z), (float)(Model.Bed(x, z) + Model.Depth[i])) + .09f;
                        Color color = Color.Lerp(new Color(.55f, .66f, .48f), new Color(1, .25f, .06f), Mathf.Clamp01(rate / .01f));
                        Vector3 mid = new Vector3(x + .5f, y, z + .5f);
                        float radius = .13f + .22f * Mathf.Clamp01(rate / .01f);
                        Tri(mid + Vector3.forward * radius, mid + Vector3.left * radius, mid + Vector3.right * radius, color);
                        if (loss > .001f)
                        {
                            float h = Mathf.Min(.8f, loss * 5);
                            Vector3 a = mid + Vector3.right * .26f;
                            Tri(a, a + Vector3.up * h, a + Vector3.right * .045f, new Color(.95f, .76f, .29f));
                        }
                    }

            Apply(erosionOverlay);
        }

        // No dynamic MeshCollider cooking: pointer intersections query this same heightfield.
        // Find the pointer/terrain intersection by height sampling, avoiding dynamic collider rebuilding.
        public bool Pick(Camera camera, Vector2 screen, out Vector3 point)
        {
            Ray ray = camera.ScreenPointToRay(screen);
            Vector3 last = ray.origin;
            float lastDifference = last.y - (float)Model.Sample(last.x, last.z);
            for (float distance = .5f; distance < 160; distance += .35f)
            {
                Vector3 p = ray.GetPoint(distance);
                if (p.x < 0 || p.x > WorksModel.W - 1 || p.z < 0 || p.z > WorksModel.H - 1)
                {
                    last = p;
                    lastDifference = p.y - (float)Model.Sample(p.x, p.z);
                    continue;
                }

                float difference = p.y - (float)Model.Sample(p.x, p.z);
                if (difference <= 0 && lastDifference > 0)
                {
                    float lo = distance - .35f, hi = distance;
                    for (int k = 0; k < 12; k++)
                    {
                        float mid = (lo + hi) * .5f;
                        Vector3 q = ray.GetPoint(mid);
                        if (q.y > Model.Sample(q.x, q.z))
                            lo = mid;
                        else
                            hi = mid;
                    }

                    point = ray.GetPoint((lo + hi) * .5f);
                    return true;
                }

                last = p;
                lastDifference = difference;
            }

            point = Vector3.zero;
            return false;
        }

        public void BuildGrid(Material lineMaterial, bool visible)
        {
            if (GridRoot == null)
            {
                GridRoot = new GameObject("Optional 3D placement grid").transform;
                GridRoot.SetParent(transform, false);
                for (int i = 0; i < WorksModel.W + WorksModel.H + 12; i++)
                    gridLines.Add(Line(GridRoot, new Vector3[2], lineMaterial, i < WorksModel.W + WorksModel.H ? .017f : .024f));
            }

            GridRoot.gameObject.SetActive(visible);
            int index = 0;
            for (int x = 0; x < WorksModel.W; x++)
            {
                for (int z = 0; z < WorksModel.H; z++)
                    gridColumn[z] = new Vector3(x, (float)Model.Bed(x, z) + .04f, z);
                gridLines[index].positionCount = gridColumn.Length;
                gridLines[index++].SetPositions(gridColumn);
            }

            for (int z = 0; z < WorksModel.H; z++)
            {
                for (int x = 0; x < WorksModel.W; x++)
                    gridRow[x] = new Vector3(x, (float)Model.Bed(x, z) + .04f, z);
                gridLines[index].positionCount = gridRow.Length;
                gridLines[index++].SetPositions(gridRow);
            }

            for (int x = 9; x <= 15; x += 3)
            {
                float y = (float)Model.Sample(x, Model.Rule.CrossRow);
                gridTick[0] = new Vector3(x, y, Model.Rule.CrossRow);
                gridTick[1] = new Vector3(x, y + 2.7f, Model.Rule.CrossRow);
                gridLines[index++].SetPositions(gridTick);
                for (int k = 1; k <= 3; k++)
                {
                    gridTick[0] = new Vector3(x - .12f, y + k * .9f, Model.Rule.CrossRow);
                    gridTick[1] = new Vector3(x + .12f, y + k * .9f, Model.Rule.CrossRow);
                    gridLines[index++].SetPositions(gridTick);
                }
            }
        }

        public static LineRenderer Line(Transform parent, Vector3[] points, Material material, float width)
        {
            GameObject go = new GameObject("Guide", typeof(LineRenderer));
            go.transform.SetParent(parent, false);
            var line = go.GetComponent<LineRenderer>();
            line.useWorldSpace = false;
            line.sharedMaterial = material;
            line.startWidth = line.endWidth = width;
            line.positionCount = points.Length;
            line.SetPositions(points);
            return line;
        }

        void OnDestroy()
        {
            if (land != null)
                Destroy(land);
            if (water != null)
                Destroy(water);
            if (section != null)
                Destroy(section);
            if (erosionOverlay != null)
                Destroy(erosionOverlay);
        }
    }
}
