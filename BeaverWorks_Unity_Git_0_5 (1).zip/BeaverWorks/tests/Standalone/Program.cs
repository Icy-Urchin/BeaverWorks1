using System;
using BeaverWorksV3;

public static class Program
{
    public static int Main()
    {
        try
        {
            Console.WriteLine(WorksChecks.Run());
            Console.WriteLine(WorksReplayChecks.Run());
            Console.WriteLine(RegressionChecks.Run());
            Console.WriteLine("CORE CHECKS PASSED. This is not Unity compilation, Play Mode, or an iPad build.");
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error);
            return 1;
        }
    }
}
