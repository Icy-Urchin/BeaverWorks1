using System;
using System.Text;
using BeaverWorksV3;

public static class RegressionChecks
{
    public static string Run()
    {
        int count = 0;
        var output = new StringBuilder();
        Action<bool, string> check = (ok, name) =>
        {
            if (!ok)
                throw new Exception("FAIL: " + name);
            count++;
            output.AppendLine("PASS: " + name);
        };
        var m = new WorksModel(0);
        check(!m.FishEdge(-1, 0, 0, 0), "Invalid fish source rejected");
        m.Depth[m.I(10, 10)] = m.Depth[m.I(11, 10)] = 1;
        check(m.FishEdge(10, 10, 11, 10), "Wet adjacent fish route accepted");
        check(!m.FishEdge(10, 10, 10, 10), "Same-cell fish query rejected");
        check(!m.FishEdge(10, 10, 12, 10), "Nonadjacent fish query rejected");
        m.Depth[m.I(10, 10)] = 0;
        check(!m.FishEdge(10, 10, 11, 10), "Dry source rejected");
        var before = m.Capture();
        m.Place(new DamSegment { X = 9, Z = 23, Length = 3, Material = DamMaterial.Timber });
        m.Commit(before);
        before = m.Capture();
        m.ClearDesign(false);
        m.ExampleDesign();
        m.Commit(before);
        check(m.Undo() && m.Segments.Count == 1, "Example undo restores prior design");
        check(m.Undo() && m.Segments.Count == 0, "Earlier undo history preserved");
        foreach (double dt in new[]
        {
            0.0,
            -0.01,
            double.NaN,
            double.PositiveInfinity
        }

        )
        {
            bool rejected = false;
            try
            {
                m.WaterStep(dt, false);
            }
            catch (ArgumentOutOfRangeException)
            {
                rejected = true;
            }

            check(rejected, "Invalid timestep rejected: " + dt);
        }

        m = new WorksModel(0);
        var rng = new Random(2026);
        for (int i = 0; i < m.Depth.Length; i++)
            m.Depth[i] = rng.NextDouble();
        double initial = m.Volume;
        for (int step = 0; step < 600; step++)
            m.WaterStep(WorksModel.Dt, false);
        check(Math.Abs(m.Volume - initial) < 1e-8, "Random closed-grid water conserved");
        bool finite = true;
        foreach (double depth in m.Depth)
            finite &= depth >= 0 && !double.IsNaN(depth) && !double.IsInfinity(depth);
        check(finite, "Random water stays finite and nonnegative");
        m.StartTrial();
        m.Place(new DamSegment { X = 9, Z = 23, Length = 3, Material = DamMaterial.Timber });
        var tape = new WorksReplay();
        tape.Begin(m);
        tape.Record(m, force: true);
        m.Segments[0].Damage = 0.8;
        var viewer = tape.CreateViewer();
        tape.Seek(viewer, 0);
        check(viewer.Segments[0].Damage == 0, "Replay cannot inherit later live damage");
        output.AppendLine("TOTAL: " + count + " repository regression checks. No Unity runtime exercised.");
        return output.ToString();
    }
}
