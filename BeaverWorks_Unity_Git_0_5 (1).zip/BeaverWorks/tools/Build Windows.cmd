@echo off
setlocal
set "UNITY=%~1"
if "%UNITY%"=="" set "UNITY=C:\Program Files\Unity\Hub\Editor\6000.3.26f1\Editor\Unity.exe"
if not exist "%UNITY%" exit /b 2
pushd "%~dp0.."
if not exist "Verification\Local" mkdir "Verification\Local"
"%UNITY%" -batchmode -quit -projectPath "%CD%" -executeMethod BeaverWorksBatch.BuildWindows -logFile "%CD%\Verification\Local\windows-build.log"
set "RESULT=%ERRORLEVEL%"
popd
exit /b %RESULT%
