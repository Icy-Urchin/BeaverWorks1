"""Standard-library-only transfer check. Does NOT compile Unity or prove gameplay."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "Verification" / "release_manifest.json"

def normalized_bytes(path):
    data = path.read_bytes()
    if path.suffix.lower() in {".cs", ".shader", ".hlsl", ".json", ".asmdef", ".csproj", ".meta", ".unity", ".prefab", ".asset", ".md", ".txt", ".py", ".yml", ".yaml", ".cmd"} or path.name in {".gitignore", ".gitattributes", ".editorconfig"}:
        data = data.replace(b"\r\n", b"\n")
    return data

def main():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    errors = []
    for relative, expected in manifest["files"].items():
        path = ROOT / relative
        if not path.is_file():
            errors.append("MISSING: " + relative)
        elif hashlib.sha256(normalized_bytes(path)).hexdigest() != expected:
            errors.append("CHANGED: " + relative)
    for folder in ["Assets", "Packages", "ProjectSettings"]:
        if not (ROOT / folder).is_dir(): errors.append("WRONG ROOT: " + folder)
    for path in (ROOT / "Assets").rglob("*.cs.txt"):
        errors.append("BAD SCRIPT EXTENSION: " + str(path.relative_to(ROOT)))
    if errors:
        print("\n".join(errors))
        print("A legitimate partner edit also changes its hash. Review the diff; do not overwrite blindly.")
        return 1
    print("TRANSFER INTEGRITY PASS: " + str(len(manifest["files"])) + " release files match (LF/CRLF normalized).")
    print("This is NOT Unity compilation, Play Mode, rendering, or an iPad test.")
    return 0

if __name__ == "__main__": sys.exit(main())
