@echo off
setlocal
set "UNITY=%~1"
if "%UNITY%"=="" set "UNITY=C:\Program Files\Unity\Hub\Editor\6000.3.26f1\Editor\Unity.exe"
if not exist "%UNITY%" (
  echo Unity not found. Pass its full path as the first argument.
  exit /b 2
)
pushd "%~dp0.."
if not exist "Verification\Local" mkdir "Verification\Local"
echo Close this project in the Unity Editor before using batch tests.
"%UNITY%" -batchmode -projectPath "%CD%" -runTests -testPlatform EditMode -testResults "%CD%\Verification\Local\editmode-results.xml" -logFile "%CD%\Verification\Local\editmode.log"
set "RESULT=%ERRORLEVEL%"
echo Process exit code: %RESULT%. Inspect the XML for actual pass/fail counts.
popd
exit /b %RESULT%
