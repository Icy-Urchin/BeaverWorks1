# Beaver Works — Overseer repository candidate 0.5

**Open THIS root folder in Unity Hub.** The same root is suitable for Git/GitHub.

The intended third-version game has not been successfully imported by its owner. This is a repaired candidate, not a verified Unity player release.

## Why a script opens in Notepad

C# source is ordinary text. `WorksGame.cs` opening in Notepad is normal. Its name must truly end in `.cs`, not `.cs.txt`. Git does not require a second scripting language: it tracks the same C# files Unity compiles.

## Folder layout

```text
BeaverWorks/
  Assets/BeaverWorks/       actual Unity C# source, shader, tests, .meta files
  Packages/manifest.json   direct Unity package versions
  ProjectSettings/         Editor version; Unity creates further settings locally
  Documentation/          beginner guides, simulation contract, source catalog
  tests/Standalone/       authored .NET 8 project linking the SAME Core/*.cs
  tools/                  transfer verification and local Unity test/build launchers
  Verification/           checks performed here and release file hashes
  .gitignore
  .gitattributes
  .editorconfig
  README.md
```

There is one source tree. No extra `BeaverWorksProject` folder, no code-in-notes installation, no hidden native library, no duplicate active script copies, and no GitHub account required for local Unity work.

## Exact target

- Unity 6.3 LTS **6000.3.26f1** (Windows authoring).
- Input System **1.17.0**.
- Universal Render Pipeline **17.3.0**.
- Unity UI/uGUI **2.0.0**.
- Test Framework **1.6.0**.
- Optional GLB import: Unity glTFast **6.20.0**, not a base requirement.
- Optional partner standalone review: .NET **8 SDK**. Unity gameplay does not need a separate .NET SDK install.

Direct versions are pinned; the first successful Unity resolution generates `Packages/packages-lock.json`. Commit that generated lockfile after checking it. It is not fabricated in this delivery, so transitive package resolution is not yet fully locked.

## First run: no Git required

1. Extract the whole ZIP. Enable File Explorer > View > Show > File name extensions.
2. Unity Hub > Add project from disk > choose this root (the folder containing `Assets`, `Packages`, `ProjectSettings`).
3. Open with 6000.3.26f1. Let Package Manager download dependencies.
4. Enable Player > Other Settings > Active Input Handling > Input System Package (New); restart if requested.
5. Menu **Beaver Works > 1 - Configure Project and Create Tutorial**. This changes only this project and creates scene/URP assets using Unity itself.
6. Menu **Beaver Works > 2 - Model and Replay Checks**. Expect 38 original and 26 replay checks.
7. Game view > landscape > Play. Draw a timber segment by holding mouse/finger, dragging between endpoints, and releasing.
8. Run Test Runner EditMode tests, then a Windows build, then test iPad separately. See `Documentation/VERIFY_LOCALLY.md`.

The scene and pipeline are deliberately generated locally, not supplied as invented serialized assets. A clean clone needs setup once; after a real Unity save, commit generated scene/pipeline/settings and their .meta files.

## Partner handoff

Read `Documentation/GIT_HANDOFF.md`. A GitHub upload is not a build test. Clone locally, verify file hashes, compile, test, and record results. Do not put purchased/private asset files in a public repository without permission.

```bash
python tools/verify_transfer.py
# Optional; partner's .NET 8 SDK required:
dotnet run --project tests/Standalone/BeaverWorks.CoreChecks.csproj
```

The transfer checker tolerates LF/CRLF differences but flags missing or changed release files. Partner edits legitimately change hashes: inspect Git diffs and review them instead of blindly replacing edits.

## Gameplay retained

Tutorial + three challenges; optional grid; 1–6-unit segments and three-layer stacks; five materials; terrain dig/mud/rocks; differing stylized erosion; light column water; pressure/load failure; animal crossing; fish outlets; undo; recorded read-only stress replay; pressure/wear/load displays; NPC beaver. Motion comes from the custom model/controller, not independent Unity physics.

## What was actually verified

- Actual split Core C# compiled with Roslyn and executed: **78 assertions** (38 original + 26 replay + 14 repository regressions).
- All source files parsed; repository layout/meta/extension checks and a local Git commit/clone transfer were checked (see current evidence files).
- **NOT executed:** Unity API compilation, package resolution, rendering, event-system input, engine tests, Windows launcher execution, Windows player build, native iPad build or performance.
- SDK `dotnet run` is supplied for your partner; the SDK command itself was not executed here. The same linked source was compiled and tested using the available Roslyn runtime.

No future test result is assumed. This is a school-game approximation, not a predictive hydraulic, geotechnical, ecological or structural engineering model.
