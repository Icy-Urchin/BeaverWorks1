# Final active source index

| Source path | Named functions and starting lines |
|---|---|
| Assets/BeaverWorks/Core/WorksChecks.cs | Run:8 |
| Assets/BeaverWorks/Core/WorksModel.Construction.cs | CanPlace:9, Place:85, Remove:98, Foundation:111, Bottom:123, Top:132, BedAtSegment:137, SyncEdges:142, ExampleDesign:183, ClearDesign:198 |
| Assets/BeaverWorks/Core/WorksModel.Ecology.cs | Random:9, FishEdge:17, FishStep:31, WalkHeight:86, AnimalStep:111 |
| Assets/BeaverWorks/Core/WorksModel.History.cs | Capture:9, Restore:26, Commit:40, Undo:53 |
| Assets/BeaverWorks/Core/WorksModel.Structure.cs | PressureKN:9, LoadStep:15 |
| Assets/BeaverWorks/Core/WorksModel.Terrain.cs | Sample:9, Kind:20, Brush:28, PlaceRock:64, RemoveRock:78, ErodeStep:88 |
| Assets/BeaverWorks/Core/WorksModel.Water.cs | StartTrial:9, Proposed:36, WaterStep:49 |
| Assets/BeaverWorks/Core/WorksModel.cs | MaterialRule:33, Copy:53, LevelRule:81, MaterialRule:147, LevelRule:154, WorksModel:186, I:212, I:223, Inside:228, Bed:233, Tick:307 |
| Assets/BeaverWorks/Core/WorksReplay.cs | Compact:25, Expand:33, Capture:39, Apply:93, Begin:185, Record:200, CreateViewer:266, IndexAt:275, Seek:292, EventTime:302, EventLabel:329 |
| Assets/BeaverWorks/Core/WorksReplayChecks.cs | Run:8, checkOrderDummy:144 |
| Assets/BeaverWorks/Editor/BeaverWorksBatch.cs | RunCoreChecks:11, BuildWindows:19 |
| Assets/BeaverWorks/Editor/BeaverWorksSetup.cs | ConfigureAndCreate:16, EditorBuildSettingsScene:62, Check:70, EnvironmentReport:84 |
| Assets/BeaverWorks/Scripts/WorksGame.cs | Start:79, Mat:118, LoadLevel:126, Spawn:178, DisableColliders:210, Primitive:229, Block:247, MaterialColor:254, Color:262, SegmentPrefab:266, ClearChildren:278, RefreshSegments:288, RefreshProps:362, BuildMarkers:407, RefreshMarkers:425, PointerDown:441, PickSegment:495, Candidate:508, PointerDrag:524, OverUI:558, PointerUp:574, Preview:613, Cancel:624, ChooseTool:636, Undo:650, ToggleTest:668, RefreshAll:699, Visit:721, Buddy:730, BuddyHeight:757, Actors:771, Update:799, CameraUpdate:876, TutorialReady:886, Advance:909, ToggleGrid:931, Say:939, RefreshUI:946, Panel:963, Label:978, Button:997, BuildUI:1008, SafeArea:1128, Suspend:1138, OnApplicationFocus:1150, OnApplicationPause:1156, OnDestroy:1162, RecordTrial:1191, ResetReplayForLevel:1197, EnterReplay:1207, ExitReplay:1242, TogglePause:1270, SeekReplay:1289, JumpEvent:1302, ShowReplay:1312, UpdateReplay:1341, TogglePressure:1352, ToggleWear:1358, ApplyDiagnosticViews:1364, InspectAt:1376, RefreshDiagnosticUI:1383, BuildDiagnosticUI:1409 |
| Assets/BeaverWorks/Scripts/WorksPointer.cs | OnInitializePotentialDrag:9, OnPointerDown:14, OnDrag:20, OnPointerUp:26 |
| Assets/BeaverWorks/Scripts/WorksView.cs | Color:27, SoilColor:29, MeshObject:34, Initialize:49, Tri:61, Apply:75, P:85, RefreshGround:90, RefreshWater:129, RefreshWearOverlay:168, Pick:200, BuildGrid:241, Line:284, OnDestroy:297 |
| Assets/BeaverWorks/Tests/Editor/BeaverWorksEngineSmokeTests.cs | StartupAndMouseDragPlacement:19 |
| Assets/BeaverWorks/Tests/Editor/BeaverWorksModelTests.cs | OriginalModelAndFourLevelSolutions:8, SnapshotReplayAndDiagnosticFields:14, FishQueriesRejectInvalidAndNonAdjacentCells:20, ExampleLoadCanBeUndoneWithoutDeletingEarlierHistory:29 |
