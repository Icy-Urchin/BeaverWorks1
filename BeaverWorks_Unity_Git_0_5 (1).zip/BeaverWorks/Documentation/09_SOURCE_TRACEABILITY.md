> Repository 0.5 update: use README.md, GIT_HANDOFF.md and SIMULATION_CONTRACT.md as current authority. Prior copy/paste installation paths are superseded; the only active source is under Assets.

# 09 — Source traceability: retained, adapted, original

## No hidden Poly Bridge source

This package does NOT include or claim access to Poly Bridge's proprietary source, its structural solver, or its asset library. The build → test → diagnose → revise loop and material choice are design inspiration. They are not a port of Poly Bridge physics.

The direct parent is the earlier supplied **BeaverWorks_Unity6_v0_3_1_Replay.zip**. That package was re-read for this revision. Core game rules are retained and tested; Unity-facing setup/formatting and specified validation fixes are revised. The older V2 playable-beaver package is NOT merged into this overseer version.

| Function family | Current location | Provenance and change |
|---|---|---|
| Terrain grid/levels/soils | Core/WorksModel.cs, constructor, Kind, Sample | Retained original V3 code; educational data, not a geological data import |
| Variable-length construction/undo | WorksModel.CanPlace/Place/Capture/Restore; WorksGame.Pointer* | Retained V3 with corrected example-history behavior and viewport guard |
| Water volume/flux/velocity | WorksModel.Proposed/WaterStep/Tick | Original V3 head-driven neighbor transfer; inspired by column/virtual-pipe methods, not copied from a research/GitHub implementation |
| Pressure/load damage | WorksModel.PressureKN/LoadStep | Original game-capacity/support/damage code; hydrostatic integration follows public physics equations |
| Erosion | WorksModel.ErodeStep | Original tunable velocity threshold/rate model. Research informs qualitative cohesive-material resistance; no empirical calibration |
| Fish routing | WorksModel.FishEdge/FishStep | Original passive flux-weighted parcel logic; now validates source/neighbor adjacency and uses reusable scratch arrays |
| Animal crossing | WorksModel.WalkHeight/AnimalStep | Original designated-row checking. Not Unity NavMesh AI or Poly Bridge vehicles |
| NPC companion | WorksGame.Buddy/Visit/BuddyHeight | Original visual animation/transform code; height resampled during movement |
| Recorded replay | Core/WorksReplay.cs; WorksGame replay methods | Retained V3.1 snapshot implementation. Not copied from Input System event replay or a purchased replay asset |
| Touch/mouse relay | WorksPointer.cs / Unity InputSystemUIInputModule | Original event relay implementing documented Unity interfaces |
| Grid/mesh/diagnostics | WorksView.cs | Original generated meshes/lines and numeric model display |
| Rendering shader | WorksSurfaceURP.shader | Rewritten using Unity's documented URP unlit color/vertex transformation/CBUFFER pattern; original vertex-color and safe-normal adaptation |
| Native setup | Editor/BeaverWorksSetup.cs | New setup with Unity's documented URP asset factory, Editor scene APIs and package report; no handwritten scene/prefab reliance |
| Validation | WorksChecks, WorksReplayChecks, Tests/Editor, Validation | Original tests plus new source/refinement and Unity-side acceptance wrappers |

## Public references consulted

These references are documentation/data, not redistributed libraries in this ZIP:

1. Exact Unity target release: https://unity.com/releases/editor/whats-new/6000.3.26f1
2. Earlier baseline issues: https://unity.com/releases/editor/whats-new/6000.3.2f1
3. Input System 1.17 install/enable: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.17/manual/Installation.html
4. uGUI Editor-aligned package: https://docs.unity3d.com/6000.3/Documentation/Manual/com.unity.ugui.html
5. URP 17.3 API / asset factory: https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.3/api/UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset.html
6. URP color shader pattern: https://docs.unity3d.com/6000.3/Documentation/Manual/urp/writing-shaders-urp-unlit-color.html
7. Unity tests: https://docs.unity3d.com/6000.3/Documentation/Manual/test-framework/running-tests.html
8. Optional GLB editor import: https://docs.unity3d.com/Packages/com.unity.cloud.gltfast@6.20/manual/ImportEditor.html
9. Unity Remote: https://docs.unity3d.com/6000.3/Documentation/Manual/UnityRemote5.html
10. iOS final build: https://docs.unity3d.com/6000.3/Documentation/Manual/ios-environment-setup.html
11. Column/virtual-pipe assumptions: https://github.com/lisyarus/webgpu-shallow-water
12. Hydrostatic depth relationship: https://openstax.org/books/college-physics-2e/pages/11-4-variation-of-pressure-with-depth-in-a-fluid
13. Cohesive sediment erosion: https://www.usgs.gov/publications/erosion-properties-cohesive-sediments-colorado-river-grand-canyon
14. Beaver/fish habitat context: https://www.fisheries.noaa.gov/feature-story/working-natures-engineers-build-coho-salmon-habitat

## Important interpretation

- No CFD solver, finite-element bridge solver, NOAA ecological forecast or Unity water package is being translated here.
- Approximate structural utilization is not a verified bending-stress calculation or approved dam design.
- Fish particles are game logic, not a validated salmon movement model.
- Procedural terrain is not automatic conversion of your GLB geometry.
- Documentation includes both retained behavior and known exclusions. Only test evidence explicitly marked executed is a verified execution claim.
- Namespace V3 indicates the retained baseline; revision 0.4 is the refined delivery, not a new disconnected game design.
