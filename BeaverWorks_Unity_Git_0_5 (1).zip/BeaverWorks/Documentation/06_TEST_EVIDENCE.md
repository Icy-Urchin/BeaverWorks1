# Current verification scope

Compiled actual split Core C# and executed 78 assertions: 38 model, 26 replay, 14 repository regression. See Verification/actual-core-checks.txt. Local Git transfer and structural checks are separate evidence. Unity API compilation, package resolution, engine tests, Windows batch launchers/player build, hardware gestures and iPad native performance remain NOT EXECUTED. The .NET 8 SDK csproj command is supplied but was not invoked here; Roslyn compiled the same linked sources.

Follow VERIFY_LOCALLY.md for gates. The intended third version is NOT treated as a proven working baseline.
