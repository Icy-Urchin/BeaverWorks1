# Simulation contract — authoritative ownership and approximations

## Source modules

`Assets/BeaverWorks/Core/WorksModel.cs` owns state, material tables, levels and Tick. The SAME partial class is split into Terrain, Construction, Water, Structure, Ecology and History .cs files for review. Every part must compile together. A partial class is a source-organization tool, not a second model or duplicated owner.

`WorksReplay.cs` records snapshots; viewer Apply/Seek does not call Tick. `Scripts/WorksGame.cs` coordinates build/test/replay and actor presentation. `WorksView.cs` renders generated meshes and translates screen rays into placement. `WorksPointer.cs` forwards mouse/touch UI events. Only Unity-facing components attach to objects; Core files never attach.

## Units and state

- Grid: 24 by 36, 1 game metre cell width and 1 square game metre area.
- Ground/Original/Bedrock/Fill/Depth: game metres. Original is baseline; Ground is mutable; Fill is added mud; Bed includes a rock-height proxy.
- Water volume: sum depth because cell area is 1. Added/Drained/Initial record volume in cubic game metres.
- QX/QZ: signed neighboring volume rates, not velocities.
- VX/VZ: approximate flux-derived game metres/second, regularized with a 0.08 depth floor and clamped to +/-3.
- PressureKN: integrated hydrostatic horizontal force for a 1 m-wide face, in kN for nominal water density 1000 kg/m3 and g=9.81 m/s2. Structural capacity values and secondary loads are game tuning, not validated capacities.
- ErosionRate: terrain depth removed per second. ErosionLoss: accumulated depth; Eroded: removed volume under unit-cell area.
- Fixed step: Dt=1/30 second. WaterStep accepts only 0<dt<=0.1 and rejects NaN/infinity via validation. This is not a universal stability guarantee.

## Fixed-step update order

1. Tick checks finished state and advances simulated time.
2. Source adds water at upstream cells (including surge schedule), updates Added.
3. WaterStep computes head/sill transfers using crest/leak lookup, limits outgoing volume to what the donor holds, applies equal/opposite neighbor transfers, drains downstream, updates approximate velocities.
4. ErodeStep removes eligible wet ground based on velocity proxy and soil thresholds; no suspended sediment/deposition. Rock cells and bedrock resist removal.
5. LoadStep integrates pressure difference on each face, adds heuristic dynamic/stack/animal terms, estimates support/capacity, advances bounded damage; broken layers update edge pass/crest state.
6. FishStep chooses a wet passable outflow neighbor; AnimalStep uses dry walkable crest height. These are gameplay movement rules.
7. Goals and terminal outcome update. Replay records afterward; visuals refresh at lower cadence.

A structure breaks AFTER the current water transfer. Its changed permeability affects the next water step. Animal motion follows the load calculation, so the load uses the current/pre-move position for that step.

## Ownership: no competing physics

- Water, erosion, dam damage, fish route cells, and animal crossing position: WorksModel only.
- Beaver buddy transform: WorksGame visual animation only; it does not change physics by walking.
- Dam visuals: read-only model presentation, not free rigid bodies; cosmetic tilt after breakage.
- Imported visual prefabs: colliders disabled, Rigidbodies kinematic, root motion disabled; scripts disabled as a safety measure. Awake can already run on Instantiate, so use model-only wrappers.
- No PBD/XPBD/PhysX joint solver has been implemented in this candidate. Never bolt Unity joints onto the same moving objects without explicitly replacing this contract.

## Water and volume ledger

The present model is a damped head-driven column transfer scheme, not HLL/Roe/GeoClaw, full SWE momentum, FLIP, SPH or incompressible 3D CFD. Target transfer uses head above the maximum neighboring bed and wall crest; permeability blends leakage and overtopping. Outflow scaling prevents a source cell sending more water than exists.

Expected ledger: current volume + drained - initial - added near zero. Clamp-to-zero can discard tiny roundoff negatives; tests measure the resulting error. Terrain removal leaves water depth unchanged at that instant: surface moves with the bed, and water re-equilibrates on later steps. This is not two-way volume displacement by moving solids.

Uniform shallow water over arbitrary terrain is not assumed to be lake-at-rest. A future well-balanced full-SWE solver must handle bed source terms and dry states, not just divide momentum by depth. Clawpack's basic Python HLL example divides by depth and is not a drop-in dry-river solution.

## Dam, erosion and soil limits

Brushwood, Timber, PackedMud, Stone and FishPass have invented length cost/height/leak/mass/capacity and walkability values. Supports are endpoint flags/neighbor topology, not solved bending constraints. LoadStep sums estimated demand and applies sustained-overload damage. No real stress tensor, bending mode, buoyancy, contact friction, elastic rod or geotechnical slope failure is solved.

Soil sequence is a teaching/game abstraction: topsoil, dirt, loose mud, sand/gravel, clay, bedrock. Wear threshold and rate values are tunable. Erosion stress=6*speedSquared is a proxy, not calibrated shear stress. No sediment mass conservation/deposition, caves, undercuts or roots network. Trees are surface-supported cosmetics.

## Replay and determinism

Recorded float snapshots at nominal 0.25s plus event frames; not input-only re-simulation. Snapshot viewer is read-only. A test remains double state, so replay copies have expected float precision differences. Memory/frame cap is explicit; recordings are in-memory and not portable files. Model tests use fixed inputs; no cross-platform bitwise or Unity physics determinism is promised.

## Future joint reference boundary

Ten Minute Physics episode 25 and PBD v2.2.0 JointDemo/XPBD/rigid-body joint routines are specifically reviewed for possible connections between dam segments. They are NOT runtime dependencies or translated implementations here. Small Steps supports studying substeps for XPBD; it is not a proof of stability for this unrelated water scheme. Any future addition needs new authoritative motion, load-to-joint coupling and failure tests first.
