# Unity and Git use the SAME source files

## No account needed for you

Unity needs an extracted local folder, not a GitHub account. Give the complete repository ZIP to your partner. Your partner can initialize a local Git repository and publish it in their account only after checking licenses/access. We do not create a remote, push files, or assume permissions.

## Initial local repository

From this repository root (not inside Assets):

```bash
git init -b main
git add .
git status
git diff --cached --check
git commit -m "Import Beaver Works overseer candidate"
```

Git requires the person's configured name/email for a commit. Configure your OWN identity, not credentials supplied by the assistant. No account/token is needed for a local commit.

For an existing partner repository, copy these root contents into an agreed project branch; avoid a second nested Unity project. Do not delete the partner's existing project without backup. If using GitHub Desktop, add an existing local repository and select this root; Publish is the partner's action after license review.

## What to track

- Assets and every corresponding .meta; moving an asset requires moving its .meta.
- Packages/manifest.json and the first VERIFIED generated packages-lock.json.
- ProjectSettings; generate/save real settings through Unity, then commit them.
- Authored tests/Standalone/*.csproj (this is NOT a generated Unity csproj).
- Source/doc/tools/verification.

Do NOT track Library, Temp, Obj, Logs, UserSettings, bin/obj, Build/Builds, personal IDE files, private credentials, signing certificates, license files or unlicensed asset-store content. The supplied ignore rules keep the custom standalone csproj while ignoring root-generated IDE projects.

## Review process

1. Clone or extract into a new location.
2. `python tools/verify_transfer.py` proves the release files transferred, not that gameplay works.
3. Read `SIMULATION_CONTRACT.md`; inspect Core responsibilities and original/source statuses.
4. `dotnet run --project tests/Standalone/BeaverWorks.CoreChecks.csproj` with .NET 8 SDK.
5. Open Unity 6000.3.26f1, resolve packages, enable New input, run setup.
6. Run Unity EditMode tests, use actual mouse and actual touch, make a Windows build.
7. Record results in Verification/Local with Editor/package/OS/device version.
8. Commit generated scene, URP settings, ProjectSettings, package lock and all generated metas after success.
9. Open a SECOND clean clone and repeat. This is the meaningful integration-transfer test.

Unity YAML must use Force Text; setup sets this. Smart Merge is optional and requires a configured UnityYamlMerge path; no unconfigured custom merge driver is forced here.

## Line endings and binary art

.cs, .shader, JSON, meta and docs use UTF-8/LF. .cmd uses CRLF. Git attributes preserve those conventions; the transfer verifier normalizes CRLF for text so Windows Git settings do not produce false damage claims.

No Git LFS dependency is silently imposed. Before adding large art, install/configure Git LFS together if appropriate; track binary art patterns deliberately and commit .gitattributes. LFS objects must actually be downloaded on clone; pointer text is not a 3D model. Never place .cs or .meta in LFS just to hide diffs.

## There is no 'Git C script'

The game's C# remains .cs. C++ research code and Python/Fortran water examples are reference links, not required game files. HLSL lives inside the .shader. Review complete files in an IDE or on GitHub; browser/Word source notes are NOT active Unity code.

## Three-pass review for each change

Implementation: did the behavior stay consistent with the overseer baseline? Numerical: finite/nonnegative water, volume ledger, valid timestep, bounded damage/replay? Integration: references, .meta, assemblies, packages, actual Unity compilation, Play Mode, build and device?

Add a regression before changing the solver. Do not let a Rigidbody, root-motion animation or imported movement script take ownership of a model-controlled visual. Joint/XPBD experiments belong on a separate reviewed branch until a full new motion/coupling contract is tested.
