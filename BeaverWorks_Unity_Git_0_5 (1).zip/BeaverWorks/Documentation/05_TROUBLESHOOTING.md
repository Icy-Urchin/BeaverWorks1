> Repository 0.5 update: use README.md, GIT_HANDOFF.md and SIMULATION_CONTRACT.md as current authority. Prior copy/paste installation paths are superseded; the only active source is under Assets.

# 05 — Troubleshooting: start with the FIRST error

## Save the right evidence

1. Stop Play.
2. Window → General → Console. Disable Collapse temporarily if needed.
3. Find the first RED error, not the tenth consequence.
4. Copy its full message and file/line; note which action produced it.
5. Beaver Works → 3 - Environment Report gives exact Editor/packages/input/pipeline.
6. Note whether you opened the fresh supplied project or overlaid an old version, and whether you are using custom assets.
7. Test again in the clean supplied project with all prefab fields EMPTY before blaming your GLB or asset pack.

Do not delete your original project or art. Do not delete random Unity installation/package files.

## Import and compilation

| Symptom | Likely cause | Safe action |
|---|---|---|
| Hub says not a Unity project | Wrong selected folder | Select repository root, containing Assets/Packages/ProjectSettings |
| No Beaver Works menu | Compile error blocks Editor scripts | Fix FIRST Console error; verify Editor/BeaverWorksSetup.cs exists |
| CS0101 / type already defined / CS0111 | Duplicate old V3 or CopyPasteSource inside Assets | Remove duplicate copy from the NEW project; keep one class set |
| CS1513 / CS1002 / unexpected '#' / backticks | Notes, line numbers or truncated pasted code inside .cs | Restore the complete release .cs from the SAME Assets path or Git; no markdown fences |
| Filename is WorksGame.cs.txt | Hidden Windows extensions | File Explorer → View → Show → File name extensions; use actual .cs extension |
| Cannot add script / not a MonoBehaviour | Wrong file or unresolved compilation | Only WorksGame is manually attachable; Core, setup and test classes are not scene components |
| Missing UnityEngine.InputSystem | Package unresolved/missing | Verify manifest Input System 1.17.0, wait for Package Manager; enable New input and restart |
| Missing UnityEngine.UI | uGUI or assembly reference missing | Resolve com.unity.ugui; retain supplied test .asmdef's Unity.ugui reference |
| Missing NUnit/TestTools | Test Framework unresolved or test asmdef misplaced | Resolve Test Framework; keep tests under Tests/Editor with supplied asmdef |
| Missing UniversalRenderPipelineAsset | URP missing or setup outside Editor | Resolve URP 17.3.0; keep setup script in Editor |
| Package resolution error | Network, registry, incompatible pin | Check internet/proxy, manifest JSON, exact Editor; collect full error; do not guess newer versions |
| Editor opens project from ZIP but won't save | Not fully extracted/read-only path | Extract all into short writable local path |
| Very slow import/sync conflict | Library in cloud-synced directory | Use local unsynced project copy for initial testing |

No offline Unity package cache is supplied. First resolution needs network. If Unity requires a different Editor-aligned core package revision, use its matching version after documenting it rather than forcing an incompatible pin.

## Startup and display

| Symptom | Checks |
|---|---|
| No scene/game objects | Run Beaver Works → 1 - Configure Project and Create Tutorial; open generated scene |
| Only Scene gizmos, no game | Click GAME tab and Play, not just Scene view |
| Pink generated terrain/water | Shader compile/pipeline issue. Run setup, inspect WorksSurfaceURP.shader's first error, assign URP asset in Graphics/Quality |
| Black/missing generated shader | Surface Shader should be BeaverWorksV3/Surface; actual shader import must succeed |
| Missing camera / two AudioListeners | Clean scene expected. Do not add extra template camera/listener beside controller |
| Tiny world or clipped toolbar | Use landscape 1280×800 or iPad 4:3, maximize GAME; viewport uses reserved UI space |
| Buttons show no text | Built-in LegacyRuntime.ttf must load; check first error, especially if another script changed Resources/font APIs |
| UI behind world / blocked | Supplied canvas is ScreenSpaceOverlay. Check competing canvas/raycast targets in custom scene |
| Cursor looks offset from grid | Keep controller at world origin, unit scale; don't move generated terrain independently |
| Erosion overlay not visible | WEAR display toggle is separate from EROSION physics; use active flow and inspect numeric rate/loss |
| Pressed replay button but no movie | Run TEST long enough for two frames first; replay is sampled state, not rendered video |

## Mouse and touch

- Enable Input System Package (New); restart when changing backend. A legacy fallback exists but is not the target acceptance path.
- A click/tap is length zero: **press → hold → drag 1–6 units → release**.
- Begin inside the visible river viewport; toolbar presses are not terrain construction.
- Use the gold endpoints first; a partial overlap or overlength member is intentionally rejected.
- Build is locked during TEST and REPLAY; use LIVE then EDIT before changing materials/terrain.
- Release over UI cancels the current action. This prevents accidental toolbar placement.
- A second touch does not own the current construction gesture. Only the claimed pointer may finish it.
- If mouse works but iPad does not: Unity Remote app, data cable, trusted device, Windows Apple support, Editor Remote device setting and New input backend are separate requirements.
- Remote is not a native game build. Its performance is your Windows Editor + stream.

## Replay

- Timeline inactive: no recorded test/two frames yet.
- Playback choppy: four state snapshots per second plus event frames are intentional, not video interpolation.
- LIVE appears frozen: returning from replay deliberately pauses the live model; use RESUME.
- WARNING goes to start: no warning in a successful recording.
- Replay vanished: new TEST, CLEAR/level change or stopping Play clears/replaces it by design.
- Erosion/breach rollback: EDIT restores construction, but the recording retains trial damage for review.
- Small mass/depth rounding: recorded fields compact to float; live solver uses double.
- Custom shader does not tint LOAD: inspect numeric utilization; shader property compatibility varies.

## Game outcomes (not compile errors)

- Pond not deep enough: close gaps, select lower leakage material, raise crest, or avoid digging a new uncontrolled drain.
- Animal lost footing: preserve dry continuous crossing row and bank approach; muddy/porous segments may not be walkable.
- Fish wrong outlet: redirect actual water at fork; fish are passive flux parcels, not player-targeted AI.
- Dam breach: short/support spans, stone, stack choices and scour matter. LOAD >100% accumulates damage; not every failure is instant.
- Tutorial NEXT disabled: finish the exact action requirement. EXAMPLE does not automatically fulfill grid/undo/brush tasks.

## Last-resort clean diagnosis

1. Keep the original project intact.
2. Extract a NEW copy of the refined project to a different folder.
3. Open exact Editor, resolve packages, run setup with no external art.
4. Run model/replay checks and supplied Unity engine smoke test.
5. If the clean baseline fails, capture full FIRST Console error plus Environment Report. Do not keep making unrelated edits until it compiles.

Unity startup/shader/touch acceptance is explicitly not executed by the authoring sandbox. There is no hidden engine-pass claim in the included evidence.
