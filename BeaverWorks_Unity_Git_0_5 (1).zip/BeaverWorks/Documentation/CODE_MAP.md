# Code map: same C# in Unity and Git

A .cs file is plain UTF-8 source text. Its app association with Notepad is normal. .meta files preserve asset identity; .asmdef files group assemblies; .shader files render. Documentation is outside Assets.

Only WorksGame is the scene controller. Setup adds it. It creates WorksView and WorksPointer at runtime. Never attach Core, editor or test files.

Core/WorksModel.cs owns the arrays, materials, levels, ledger and Tick order. The SAME partial class is split into WorksModel.Water, Terrain, Construction, Structure, Ecology and History .cs files. All must compile together. They are not multiple solver objects.

- Water: StartTrial, Proposed, WaterStep; donor-limited water volumes and approximate speed.
- Terrain: Sample, Kind, Brush, ErodeStep, rock operations.
- Construction: CanPlace, Place, Remove, Foundation, Bottom, Top and SyncEdges.
- Structure: PressureKN and LoadStep; simplified demand/capacity, not rigid-body joints.
- Ecology: FishStep/FishEdge and AnimalStep/WalkHeight.
- History: Capture, Commit, Undo and Restore.
- WorksReplay: recorded float snapshots; Apply/Seek never advances Tick.

Runtime/Scripts explicitly reference Core, Unity.ugui and Unity.InputSystem. Editor code configures the scene/pipeline and local tests/builds. Test assemblies are Editor-only.

Mouse/finger down-drag-up flows through WorksPointer into WorksGame; a candidate segment is validated, placed and assigned to the model. SyncEdges changes wall crest/leak fields; the buddy visits it visually. TEST resets transient state then fixed Tick runs source → water → erosion → structural damage → fish → animals → goal outcome. The snapshots record after those results; visuals update separately.

Water is an original lightweight head-transfer scheme, not a port of HLL/Roe/XPBD/FLIP. Formula-based hydrostatic face pressure is mixed with clearly labeled gameplay load coefficients. Imported art must not supply independent motion; use model-only prefab wrappers, kinematic bodies and no root motion.

To copy/edit code, use complete files under Assets. GitHub reads those exact files. No duplicate 'Git scripts' are needed. Do not paste Word formatting, markdown fences or line numbers into .cs source. Save with true .cs extension; keep its .meta. Re-run regression checks before and after edits.

Read SIMULATION_CONTRACT.md for the exact model and SOURCE_CATALOG.md for which references were read, copied as API patterns, or merely considered.
