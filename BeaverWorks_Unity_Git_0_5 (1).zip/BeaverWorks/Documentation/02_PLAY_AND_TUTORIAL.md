> Repository 0.5 update: use README.md, GIT_HANDOFF.md and SIMULATION_CONTRACT.md as current authority. Prior copy/paste installation paths are superseded; the only active source is under Assets.

# 02 — Play and understand the tutorial

## What kind of game this is

You oversee a little river world. The river moves vertically on screen: upstream at the top, downstream at the bottom. The front-centered, tilted orthographic camera is not a diagonal isometric view. The beaver is cosmetic: it follows your work but does not decide where water goes.

The loop is **inspect → draw/build/dig → test → inspect pressure/wear/load → replay → edit/undo → test again**.

Mouse: press and hold left mouse button, drag, release. iPad: press with one finger, drag, lift. No keyboard is required. A tap alone is not a valid log segment because its length is zero.

## Tutorial, exactly

1. **Look:** toggle GRID off and back on; press NEXT STEP. Hiding the drawn grid does not disable snapping.
2. **First bundle:** TIMBER is selected. Press the screen-left gold endpoint, drag toward the center gold marker and release when the preview says **3 units / cost 9**. World coordinates are X12→15, Z23; world +X appears screen-left from this camera.
3. **Join:** drag center to screen-right gold endpoint for another 3-unit timber bundle (world X9→12, Z23). Two adjacent pieces span the six-unit river.
4. **Undo:** press UNDO, then redraw the missing bundle. NEXT unlocks after the undo action and both spans exist.
5. **Terrain:** choose DIG or ADD MUD; hold/drag on a BANK away from the gold crossing, access ramps and rocks. Release. Watch actual height and layer colors change; UNDO restores one complete brush stroke.
6. **Test:** press TEST WATER. Water enters from dry initial conditions. One rabbit attempts to cross after about **72 simulation seconds**. The unchanged example normally completes around 86 simulation seconds (about 29 real seconds at 3×, before overhead).
7. **Inspect/replay:** press PAUSE to freeze live water. Toggle PRESSURE, WEAR and LOAD. Tap terrain/dam to read local values. REPLAY → PLAY or drag the timeline; PREV/NEXT jump events and WARNING jumps the first problem. LIVE returns to the retained live state, paused. RESUME continues it.
8. **Finish:** tutorial succeeds when pond goal, one animal crossing and no broken pieces remain satisfied for 3 simulation seconds. Complete it then use NEXT STEP / NEXT LEVEL. If you changed the wrong terrain and it fails, EDIT/RESET restores pre-test construction; revise and retest.

Gold preview = valid. Red = rejected. Release over a toolbar cancels the edit. Draw 1–6 unit horizontal or vertical segments; diagonal drawing snaps to the dominant axis. Exact matching endpoints stack, maximum three layers. Partial overlap and perpendicular intersections are rejected.

## Four presets

| Preset | Design lesson | Teaching example |
|---|---|---|
| Tutorial | Two 3-unit segments, undo, sculpt, test | Two timber pieces at row Z23 |
| Level 1 — Woodland crossing | Pond plus two rabbits on dry connected crest | Two timber pieces at row Z23 |
| Level 2 — Nursery fork | Block main drain, send four fish to screen-left nursery, rabbit crossing | Two timber pieces at row Z20 |
| Level 3 — Spring surge | Pulse flow, heavier deer, four correct fish; maximum three wrong exits | Two stone pieces at row Z20, three stacked layers |

EXAMPLE is an undoable teaching design, not a tutorial auto-pass. It does not replace the required grid/undo/brush actions. Animals use the designated row only; they are not general AI pathfinders. Fish follow flux-weighted neighboring wet cells, not goal-seeking or teleportation.

## Materials

- **Brushwood:** cheap, porous and weak; not a dry animal walkway.
- **Timber:** useful crest, low leakage, moderate capacity.
- **Packed mud:** low leakage; not walkable in these game rules.
- **Stone core:** heavier, stronger and expensive; useful for surge.
- **Fish-pass weave:** very permeable opening; requires enough wet flow and appropriate placement.
- **Terrain mud / rocks:** change the riverbed and local resistance. These tools are separate from the segment material buttons.

Layer sequence is educational: topsoil → dirt → loose mud → sand/gravel → clay → bedrock. Clay resists low-stress erosion; rocks protect their nodes; bedrock stops digging. Real sediment layering and erosion differ between sites.

## Controls and states

| Control | Action |
|---|---|
| Material buttons | Choose the next segment's material |
| DIG / ADD MUD | Hold/drag a terrain stroke |
| ROCK / REMOVE | Place rock / remove player object; natural rocks are permanent |
| UNDO / Z | Restore the last completed construction action |
| TEST / space | Start trial; during trial EDIT restores the baseline |
| GRID / G | Show or hide grid only |
| CAMERA | Drag to pan; plus/minus or mouse wheel zoom |
| PRESSURE / WEAR / LOAD | Independent display toggles; do not change physics |
| EROSION | Physics setting, only change in build mode |
| REPLAY / LIVE | Enter recorded viewer / restore live trial or design |
| PLAY / PAUSE | Replay playback or live simulation pause/resume |
| SPEED | Live 1/3/6×; replay .25/.5/1/3× |
| START / PREV / NEXT / WARNING | Replay navigation |
| CLEAR | Reset current level; clears current replay |

Replay samples at four snapshots per simulation second plus event frames, not smooth video. It records water, terrain wear, structure damage, fish/animals and beaver pose. It does not run physics during playback. Live water uses double precision; compact recorded fields use floats, so small numeric rounding is expected. Last test is memory-only and replaced by the next TEST; stopping Play loses it.

## Limits you should know

This is not a full volumetric fluid or engineering solver. Water has column volume and approximate velocity, not caves/tunnels/spray. No sediment deposition, save/load, arbitrary bridge graph, free diagonal members, character controls, multiplayer or advanced wildlife navigation are claimed. Stress and material capacity are game approximations. No production iPad performance claim has been made.
