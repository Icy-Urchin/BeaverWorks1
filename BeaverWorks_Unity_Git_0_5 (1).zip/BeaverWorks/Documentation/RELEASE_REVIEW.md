# Three-pass release review — candidate 0.5

## 1. Implementation review

Preserved the third overseer direction and 0.4 behavior; no new controllable character or replacement CFD. Flattened project root for Unity/Git. Core split into seven partial-class responsibility files, one model. Real .cs source, explicit runtime/Core/test assembly references, native Unity scene/pipeline setup. Git rules and standalone test project created. Prefab motion guards tightened; authored arbitrary prefab scripts are disallowed.

No external simulation library code is redistributed. Ten Minute Physics/PBD/Small Steps/Clawpack are focused references, not fictional translations or native dependencies.

## 2. Numerical review

Actual Core source compiled using Roslyn and run in .NET runtime: 78 checks passed. Covers fixed-timestep rejection, nonnegative finite depths, water ledger, four level solutions, overload breach, sand/clay wear ordering, undo, replay preservation/seek/cap and new random-grid conservation tests. Original heuristic coefficients retained. No universal stability proof, physical calibration or cross-platform bitwise guarantee.

## 3. Integration/release review

Source syntax and file structure/meta/assembly tests performed. Local Git commit/clone and normalized hashes checked; release ZIP contents checked. These do NOT prove Unity API compilation or gameplay. Unity, packages-lock generation, URP setup/rendering, hardware input, engine tests, Windows launcher execution/player build and native iPad tests remain unexecuted. Supplied README and VERIFY_LOCALLY explain the gates.

The standalone .NET 8 csproj is authored and links the same sources; SDK command not invoked in the sandbox. Actual same source compilation via Roslyn is not passed off as a dotnet CLI or Unity run.

Generated Unity scene/pipeline assets deliberately do not exist yet. Setup creates them through the local licensed Editor. Commit only actual successful setup outputs + .meta/package lock; do not manufacture serialization or approvals.
