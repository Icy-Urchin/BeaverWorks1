# Complete source for reading and copying

There is ONE authoritative source tree under Assets/BeaverWorks. GitHub displays these exact .cs files. Do not create duplicate runtime scripts from notes. Open a complete source file in VS Code, Visual Studio, Notepad++ or ordinary Notepad; code text is the same. Save as UTF-8 with an actual .cs extension. Keep its .meta when replacing an existing Unity file.

WorksModel is intentionally split into partial-class files by subsystem; all Core/*.cs are required. The class has one state owner, not separate copies. Never paste Word formatting or line numbers into a .cs file. Use Git diffs for changes.
