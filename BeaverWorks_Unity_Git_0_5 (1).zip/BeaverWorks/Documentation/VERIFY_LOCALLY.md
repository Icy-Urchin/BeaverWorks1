# How to know it works after transfer

A correct transfer is necessary but not sufficient. Complete these gates IN ORDER and save evidence. All Unity/device gates are unexecuted by the assistant.

## Gate 1 — files / Git

Enable file extensions. Open the root containing Assets, Packages and ProjectSettings. Run `python tools/verify_transfer.py`. This is standard-library Python only (Python 3.8+); no pip install needed. A changed hash after a legitimate edit means REVIEW, not necessarily corruption.

Commit/clone test: partner commits source locally, clones to a separate folder, repeats transfer check. Track .meta and generated verified settings/package lock. Don't copy Library. The assistant performs a local Git round trip, not a GitHub remote upload.

## Gate 2 — standalone C# core

Optional .NET 8 SDK, installed by partner (not required for normal Unity users):

```bash
dotnet run --project tests/Standalone/BeaverWorks.CoreChecks.csproj
```

Expected 38 original + 26 replay + 14 regression checks, all passed. Exit code 1 is failure. This compiles the same Core/*.cs that Unity compiles, not a translated simulator. The assistant compiled/runs these sources through available Roslyn/.NET runtime, but did not run this SDK command.

## Gate 3 — Unity package resolution and compilation

Open Unity 6000.3.26f1. Resolve the pinned direct packages. Save manifest/actual package versions in the review. Enable New input and restart. First Console error matters most. Run project setup once; creates actual scene/URP assets. Run Environment Report. Commit verified packages-lock.json after resolution; it is not pre-fabricated here.

No red C# or shader errors. Check assembly definitions reference BeaverWorks.Core, BeaverWorks.Runtime, Unity.ugui and Unity.InputSystem. Tests compile only in Editor. The menu setup must exist; docs in root don't compile.

## Gate 4 — engine and actual input

Run Window > General > Test Runner > EditMode > Run All after setup. Included engine test enters Play Mode and calls drag hooks; it does NOT synthesize a real hardware touch. Inspect results XML.

Then manually test mouse down-drag-up on terrain, incorrect/out-of-bounds gestures, budget, undo, mud/dig/rocks, all levels, frame-rate slowdown, warning replay, slider scrubbing, pressure/wear/load visual scales, LIVE rollback, focus loss and changing levels. One buddy, one motion owner; no root-motion or imported movement conflict. Test both 16:10 and 4:3 landscape.

Optional Windows batch launcher: close the project first, run `tools/Run Unity EditMode Tests.cmd`. It defaults to 6000.3.26f1 under Unity Hub. Pass a full different executable path if needed. Scripts have not executed on Windows here. Do NOT use -nographics for rendering validation. Process exit code alone is not enough: inspect NUnit XML and Editor.log for tests actually run/failed.

## Gate 5 — player

After successful saved scene setup, File > Build Profiles > Windows > Build and Run (or supplied Build Windows.cmd). Confirm rendering and drag behavior outside the Editor. A compiled Core DLL does not prove player success.

## Gate 6 — iPad

Unity Remote 5 can send iPad touches to Windows Editor; iTunes/USB trust setup may be needed. Game still runs on Windows. Remote does not measure native iPad performance. Record iPad model/iPadOS, aspect ratio, control readability, gestures, cancellation and replay.

Native iPad final build requires iOS Build Support and Mac/Xcode signing or configured cloud build. Store/account/signing rules are separate. Do not claim native success without installation and device profiling.

## Result record template

- Git commit or release source hashes:
- Unity version:
- Package versions / verified packages-lock:
- OS/GPU:
- Standalone tests count/result:
- Unity compile errors:
- EditMode XML count/pass/fail:
- Manual mouse/touch result:
- Windows player build/run result:
- iPad Remote result:
- Native iPad build/device profiling result:
- Known limits and next issue:

## MCP references

The requested unity-mcp read_console/run_tests pages are documented in the source catalog. No such server is connected to the assistant here. Installing it is optional and does not guarantee tests pass; async run_tests returning a job ID is not a finished result. Do not clear the Console before preserving the first errors and stack traces.
