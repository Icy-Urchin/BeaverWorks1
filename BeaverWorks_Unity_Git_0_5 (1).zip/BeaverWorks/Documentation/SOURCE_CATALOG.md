# Linked source catalog — 47 attributed entries

Status distinguishes actual dependencies/API patterns, conceptual references, inspected but unimplemented methods and pointers. No external simulation library code is bundled. Source line numbers and mapping are in SIMULATION_CONTRACT and current module files.

## S01 — Unity 6000.3.26f1 release notes

- Author: Unity Technologies
- Link: https://unity.com/releases/editor/whats-new/6000.3.26f1
- Status: REQUIRED TOOL
- Local relevance: ProjectSettings/ProjectVersion.txt; exact selected Editor, not an Editor test result.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S02 — Input System installation 1.17

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.17/manual/Installation.html
- Status: REQUIRED DEPENDENCY
- Local relevance: Packages/manifest.json; New input and restart; WorksPointer mouse/touch routes.
- Review: Web page read this turn
- Version: 1.17.0
- License/reuse: Link only; no external source code redistributed

## S03 — Input System uGUI support

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.17/manual/UISupport.html
- Status: API PATTERN USED
- Local relevance: WorksGame.BuildUI and WorksPointer: InputSystemUIInputModule forwards pointer down/drag/up. Not IMGUI.
- Review: Web page read this turn
- Version: 1.17.0
- License/reuse: Link only; no external source code redistributed

## S04 — UniversalRenderPipelineAsset API

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.3/api/UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset.html
- Status: API PATTERN USED
- Local relevance: BeaverWorksSetup uses URP factory/Create and serialized pipeline reference.
- Review: Web page read this turn
- Version: 17.3.0
- License/reuse: Link only; no external source code redistributed

## S05 — Create a URP Asset

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/urp/urp-asset-create.html
- Status: API PATTERN USED
- Local relevance: BeaverWorksSetup generates native assets; fallback menu procedure if factory fails.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S06 — URP unlit shader color input

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/urp/writing-shaders-urp-unlit-color.html
- Status: API PATTERN ADAPTED
- Local relevance: WorksSurfaceURP.shader uses UniversalPipeline tag, Core.hlsl, TransformObjectToHClip and UnityPerMaterial; vertex color/diagnostics original additions.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S07 — uGUI 2.0 manual

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.ugui@2.0/manual/index.html
- Status: REQUIRED DEPENDENCY
- Local relevance: Unity UI 2.0.0; Canvas, Text, Button, Slider, GraphicRaycaster; package referenced in runtime assembly.
- Review: Search-index documentation corroboration; not deep-read this turn
- Version: 2.0.0
- License/reuse: Link only; no external source code redistributed

## S08 — Test Framework 1.6 API

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.test-framework@1.6/manual/index.html
- Status: REQUIRED DEPENDENCY
- Local relevance: Tests/Editor uses NUnit and EnterPlayMode/ExitPlayMode; tests supplied, Unity unexecuted.
- Review: Previously reviewed documentation baseline; retained, not deep-read this turn
- Version: 1.6.0
- License/reuse: Link only; no external source code redistributed

## S09 — Running Unity tests

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/test-framework/running-tests.html
- Status: PROCEDURE USED
- Local relevance: VERIFY_LOCALLY and Editor tests. No remote Unity test run is assumed.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S10 — Unity test command line reference

- Author: Unity Technologies
- Link: https://docs.unity.com/en-us/engine/6000.3/manual/scripting/test-framework-introduction/reference-command-line
- Status: PROCEDURE USED
- Local relevance: Run Unity EditMode Tests.cmd uses -runTests -testPlatform EditMode -testResults; inspect XML, not exit code alone.
- Review: Search-index excerpt read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S11 — Unity Editor CLI reference (user supplied)

- Author: Unity Technologies
- Link: https://docs.unity.com/en-us/engine/6000.0/manual/unity-editor/command-line-arguments/editor
- Status: PROCEDURE USED
- Local relevance: BeaverWorksBatch + .cmd wrappers use batchmode, projectPath, executeMethod and logFile; local Unity/license required.
- Review: Web page read this turn
- Version: 6000.0 supplied URL; target project 6000.3
- License/reuse: Link only; no external source code redistributed

## S12 — Physics overview (user supplied)

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.6/Documentation/Manual/PhysicsSection.html
- Status: REVIEWED, NOT CUSTOM SOLVER IMPLEMENTATION
- Local relevance: Unity PhysX is not the water/erosion/dam solver here. Kinematic visual bodies do not independently move.
- Review: Web page read this turn
- Version: 6000.6 supplied URL; not a project upgrade requirement
- License/reuse: Link only; no external source code redistributed

## S13 — Unity Remote

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/UnityRemote5.html
- Status: PROCEDURE USED
- Local relevance: Touch testing in Windows Editor via Remote/USB; cannot prove native iPad performance.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S14 — iOS environment setup

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/ios-environment-setup.html
- Status: PROCEDURE USED
- Local relevance: iOS Build Support, Mac/Xcode or cloud build, Apple signing; not fulfilled by ZIP.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S15 — glTFast Editor import

- Author: Unity Technologies
- Link: https://docs.unity3d.com/Packages/com.unity.cloud.gltfast@6.20/manual/ImportEditor.html
- Status: OPTIONAL PACKAGE
- Local relevance: 04_ASSETS: GLB/glTF imported into Assets/YourArt; optional 6.20.0, no base dependency.
- Review: Web page read this turn
- Version: 6.20.0
- License/reuse: Link only; no external source code redistributed

## S16 — Mesh.MarkDynamic

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/ScriptReference/Mesh.MarkDynamic.html
- Status: API PATTERN USED
- Local relevance: WorksView dynamic terrain/water meshes; a performance hint, not proof of mobile performance.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S17 — MeshCollider introduction

- Author: Unity Technologies
- Link: https://docs.unity3d.com/6000.3/Documentation/Manual/mesh-colliders-introduction.html
- Status: REVIEWED DESIGN LIMIT
- Local relevance: Current overseer uses analytic terrain picking, not deforming MeshCollider physics; recooking cost warns against adding it casually.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S18 — Ten Minute Physics index (user supplied)

- Author: Matthias Müller
- Link: https://matthias-research.github.io/pages/tenMinutePhysics/
- Status: REVIEWED, NO CODE PORT
- Local relevance: Episodes 25 joints, 20 heightfield water, 8 picking, 9 XPBD; not the source of a complete translated game.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S19 — Episode 25: joint source

- Author: Matthias Müller
- Link: https://github.com/matthias-research/pages/blob/bfc4b63667c7e3ef683a7d6491c26f13c7e0d831/tenMinutePhysics/25-joints.html
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: RigidBody.applyCorrection and Joint.solvePosition reviewed for future dam connections only; no JS-to-C# port.
- Review: Focused source downloaded from raw GitHub and inspected; web source page read
- Version: bfc4b63667c7e3ef683a7d6491c26f13c7e0d831
- License/reuse: License not independently established for this tutorial file; link/reference only, no copied code

## S20 — Episode 20: heightfield water source

- Author: Matthias Müller
- Link: https://github.com/matthias-research/pages/blob/bfc4b63667c7e3ef683a7d6491c26f13c7e0d831/tenMinutePhysics/20-heightFieldWater.html
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: WaterSurface.simulateSurface/simulateCoupling inspected. Wave/displacement model differs from present head-flow routing; not translated.
- Review: Focused source downloaded and inspected
- Version: bfc4b63667c7e3ef683a7d6491c26f13c7e0d831
- License/reuse: Tutorial-file reuse license not established; no copied code

## S21 — Episode 20 water notes

- Author: Matthias Müller
- Link: https://matthias-research.github.io/pages/tenMinutePhysics/20-heightFieldWater.pdf
- Status: READING SUPPORT
- Local relevance: Array-of-columns/water-to-object concepts; no volumetric particle solver added.
- Review: Search-index notes excerpt reviewed
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S22 — PositionBasedDynamics repository (user supplied)

- Author: Jan Bender and PositionBasedDynamics contributors
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics
- Status: REVIEWED, NOT DEPENDENCY
- Local relevance: Joint/rod/stretch/XPBD capability review only. No CMake/Eigen/native DLL dependency in Unity.
- Review: Web page read this turn
- Version: Focused inspection: tag 2.2.0, aa62c44f0d43956452e1f960a40333ec2d6d3ea5
- License/reuse: MIT confirmed from repository LICENSE; no library code redistributed

## S23 — PBD JointDemo

- Author: PositionBasedDynamics contributors
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics/blob/aa62c44f0d43956452e1f960a40333ec2d6d3ea5/Demos/RigidBodyDemos/JointDemo.cpp
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: BuildModel/timeStep structure reviewed; candidates for future flexible connections only.
- Review: Tag clone inspected locally; immutable commit verified by git
- Version: 2.2.0 / aa62c44f0d43956452e1f960a40333ec2d6d3ea5
- License/reuse: MIT; code not redistributed

## S24 — PBD rigid-body joint kernels

- Author: PositionBasedDynamics contributors
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics/blob/aa62c44f0d43956452e1f960a40333ec2d6d3ea5/PositionBasedDynamics/PositionBasedRigidBodyDynamics.cpp
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: init/update/solve_BallJoint, DistanceJoint and DamperJoint inspected by file/function location; not ported.
- Review: Tag clone inspected locally; immutable commit verified by git
- Version: 2.2.0 / aa62c44f0d43956452e1f960a40333ec2d6d3ea5
- License/reuse: MIT; code not redistributed

## S25 — PBD XPBD distance constraint

- Author: PositionBasedDynamics contributors
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics/blob/aa62c44f0d43956452e1f960a40333ec2d6d3ea5/PositionBasedDynamics/XPBD.cpp
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: solve_DistanceConstraint inspected: compliance/dt-squared, accumulated lambda and zero-distance guards; not implemented.
- Review: Tag clone inspected locally; immutable commit verified by git
- Version: 2.2.0 / aa62c44f0d43956452e1f960a40333ec2d6d3ea5
- License/reuse: MIT; code not redistributed

## S26 — PBD MIT license

- Author: PositionBasedDynamics contributors
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics/blob/aa62c44f0d43956452e1f960a40333ec2d6d3ea5/LICENSE
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: Keep original copyright/license for any future actual copy or substantive port. Links only in this release.
- Review: Tag clone inspected locally; immutable commit verified by git
- Version: 2.2.0 / aa62c44f0d43956452e1f960a40333ec2d6d3ea5
- License/reuse: MIT; code not redistributed

## S27 — Small Steps in Physics Simulation (user supplied)

- Author: Miles Macklin, Kier Storey, Michelle Lu, Pierre Terdiman, Nuttapong Chentanez, Stefan Jeschke, Matthias Müller
- Link: https://mmacklin.com/smallsteps.pdf
- Status: REVIEWED, NOT XPBD IMPLEMENTATION
- Local relevance: Small XPBD substeps can outperform large-step iterations for studied systems. Not a stability proof for present unrelated water scheme.
- Review: Web page read this turn
- Version: 2019; DOI 10.1145/3309486.3340247
- License/reuse: Paper publication rights/classroom notice; link only, no redistributed PDF

## S28 — Clawpack shallow-water solver overview (user supplied)

- Author: Clawpack developers
- Link: https://www.clawpack.org/riemann/Shallow_water_Riemann_solvers.html
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: h, hu, hv, bathymetry; distinguish well-balanced and dry-state solvers. Present model stores depth and heuristic flux; not HLL/Roe/GeoClaw.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S29 — Clawpack Python HLL and f-wave source

- Author: Clawpack developers
- Link: https://github.com/clawpack/riemann/blob/3f529f0f5cbfb87343bc289c31e2b48193785687/riemann/shallow_1D_py.py
- Status: REVIEWED, NOT IMPLEMENTED
- Local relevance: shallow_hll_1D inspected: divides momentum by depth. shallow_fwave_1d warns dry states untested. Not safe to paste directly into a dry river.
- Review: v5.13.1 tag downloaded, exact source inspected
- Version: v5.13.1 / 3f529f0f5cbfb87343bc289c31e2b48193785687
- License/reuse: BSD 3-Clause verified from LICENSE; no source copied

## S30 — Clawpack license

- Author: Clawpack developers
- Link: https://github.com/clawpack/riemann/blob/3f529f0f5cbfb87343bc289c31e2b48193785687/LICENSE
- Status: REFERENCE LICENSE REVIEW
- Local relevance: BSD notice/redistribution conditions must accompany future copied code.
- Review: Local tag LICENSE read
- Version: 3f529f0f5cbfb87343bc289c31e2b48193785687
- License/reuse: BSD 3-Clause

## S31 — Hydrostatic reconstruction for shallow water

- Author: Emmanuel Audusse, François Bouchut, Marie-Odile Bristeau, Rupert Klein, Benoît Perthame
- Link: https://doi.org/10.1137/S1064827503431090
- Status: FUTURE METHOD, NOT IMPLEMENTED
- Local relevance: Well-balanced/positivity research reference. No theorem claimed for current transfer model.
- Review: Search-index abstract reviewed; no full-paper implementation
- Version: SIAM J. Scientific Computing, 2004
- License/reuse: Link only; no external source code redistributed

## S32 — Virtual-pipes WebGPU reference

- Author: lisyarus
- Link: https://github.com/lisyarus/webgpu-shallow-water/
- Status: CONCEPTUAL REFERENCE USED
- Local relevance: Neighbor columns, head-driven flux and donor outflow scaling match conceptual design; our damping/walls game rules are not literal port.
- Review: Web page read this turn
- Version: d73d987ddb5db03a8c0563b5172d3c330e89fffd
- License/reuse: MIT verified; no copied source

## S33 — Virtual-pipes focused solver source

- Author: lisyarus
- Link: https://github.com/lisyarus/webgpu-shallow-water/blob/d73d987ddb5db03a8c0563b5172d3c330e89fffd/source/simulator.cpp
- Status: REVIEWED, NOT PORTED
- Local relevance: Embedded WGSL solver reviewed at source path; not a Unity compute shader dependency.
- Review: Local focused clone source inspected
- Version: d73d987ddb5db03a8c0563b5172d3c330e89fffd
- License/reuse: MIT

## S34 — UnityTerrainErosionGPU explanation

- Author: bshishov
- Link: https://github.com/bshishov/UnityTerrainErosionGPU
- Status: CONCEPTUAL REFERENCE USED
- Local relevance: Depth/flux/velocity/sediment distinction reviewed. Current CPU model omits deposition/sediment transport; no code copied.
- Review: Web page read this turn
- Version: Source pointer HEAD observed: 0e59f7c42b5ccbc8bc637b7a6435c3af648bc8b6
- License/reuse: Repository marked MIT; no source copied

## S35 — UnityTerrainErosionGPU kernel source pointer

- Author: bshishov
- Link: https://github.com/bshishov/UnityTerrainErosionGPU/blob/0e59f7c42b5ccbc8bc637b7a6435c3af648bc8b6/Assets/Shaders/Erosion.compute
- Status: SOURCE POINTER, NOT LINE-BY-LINE REVIEW
- Local relevance: README points to Erosion.compute kernels and Simulation.cs; partner should verify actual file path/version before a port.
- Review: README reviewed; this exact kernel file not downloaded
- Version: HEAD observed via git ls-remote
- License/reuse: Link only; no external source code redistributed

## S36 — Interactive Terrain Modeling Using Hydraulic Erosion

- Author: Ondřej Štava, Bedřich Beneš, Matthew Brisbin, Jaroslav Křivánek
- Link: https://www.cs.purdue.edu/cgvlab/www/resources/papers/Stava-2008-Interactive_Terrain_Modeling_Using_Hydraulic_Erosion.pdf
- Status: CONCEPTUAL REFERENCE USED
- Local relevance: Layered materials and running-water erosion context; actual multilayer deposition, dissolution, slippage/GPU algorithm not replicated.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S37 — Fast Hydraulic Erosion Simulation and Visualization on GPU

- Author: Xing Mei, Philippe Decaudin, Bao-Gang Hu
- Link: https://doi.org/10.1109/PG.2007.15
- Status: FURTHER READING
- Local relevance: Velocity-driven erosion/deposition/transport full method; current simplified wear is NOT the same implementation.
- Review: Search-index abstract and prior-paper citation reviewed
- Version: 2007
- License/reuse: Link only; no external source code redistributed

## S38 — Erosion properties of cohesive sediments

- Author: R. Akahori, M. W. Schmeeckle, D. J. Topping, T. S. Melis / USGS
- Link: https://www.usgs.gov/publications/erosion-properties-cohesive-sediments-colorado-river-grand-canyon
- Status: CONCEPTUAL REFERENCE USED
- Local relevance: Clay-rich cohesive mud can resist wear. Soil thresholds are invented game parameters, not fitted to this study.
- Review: Web page read this turn
- Version: 2008; DOI 10.1002/rra.1122
- License/reuse: Link only; no external source code redistributed

## S39 — Force on a dam wall

- Author: Royal Academy of Engineering
- Link: https://raeng.org.uk/media/hyjiavu2/7-force-on-a-dam-wall.pdf
- Status: FORMULA REFERENCE USED
- Local relevance: WorksModel.Structure PressureKN integrates depth pressure across a vertical face; capacity/support/breakage coefficients remain original game heuristics.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S40 — Pressure with depth in a fluid

- Author: OpenStax College Physics 2e
- Link: https://openstax.org/books/college-physics-2e/pages/11-4-variation-of-pressure-with-depth-in-a-fluid
- Status: FORMULA REFERENCE USED
- Local relevance: Gauge pressure rho*g*h; UI p=9.81*Depth in nominal kPa, not free-surface pressure or total structural force.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S41 — Unity scene/prefab version control

- Author: Adrian Woods / Unity Technologies
- Link: https://unity.com/blog/author-scenes-and-prefabs-with-verson-control
- Status: PROCEDURE USED
- Local relevance: .meta/GUID preservation, Force Text, shared scenes and assets. Smart Merge/LFS optional and explicitly configured.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S42 — GitHub Unity.gitignore

- Author: GitHub gitignore contributors
- Link: https://github.com/github/gitignore/blob/main/Unity.gitignore
- Status: PATTERN REVIEWED, CUSTOM FILE AUTHORED
- Local relevance: Our root .gitignore excludes caches but retains authored tests/Standalone csproj, unlike a blanket *.csproj rule.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S43 — Git attributes manual

- Author: Git project contributors
- Link: https://git-scm.com/docs/gitattributes
- Status: PROCEDURE USED
- Local relevance: Text LF normalization and binary flags; no hidden LFS filter/merge dependency.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S44 — unity-mcp read_console (user supplied)

- Author: Coplay / unity-mcp contributors
- Link: https://coplaydev.github.io/unity-mcp/reference/tools/core/read_console
- Status: DOCUMENTATION REVIEWED, TOOL NOT CONNECTED
- Local relevance: Can read Console on a connected editor. No such server was invoked; no Unity errors read remotely.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S45 — unity-mcp run_tests (user supplied)

- Author: Coplay / unity-mcp contributors
- Link: https://coplaydev.github.io/unity-mcp/reference/tools/testing/run_tests
- Status: DOCUMENTATION REVIEWED, TOOL NOT CONNECTED
- Local relevance: Asynchronous job ID requires polling. No Unity test run happened through MCP.
- Review: Web page read this turn
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S46 — PositionBasedDynamics discussions

- Author: PositionBasedDynamics community
- Link: https://github.com/InteractiveComputerGraphics/PositionBasedDynamics/discussions
- Status: DISCUSSION ENTRY POINT
- Local relevance: For specific joint integration questions; not consulted for any particular accepted answer.
- Review: Repository README discussion link; individual threads not reviewed
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed

## S47 — Unity Input System forum release

- Author: Unity Input Team
- Link: https://discussions.unity.com/t/release-input-system-1-16-0-1-17-0/1694828
- Status: BASELINE CORROBORATION
- Local relevance: 1.17.0 package availability; no community code imported.
- Review: Previously reviewed release-post excerpt, retained reference
- Version: Live documentation accessed 2026-10-16
- License/reuse: Link only; no external source code redistributed
